"""Read and validate the original publisher CSV and JSON responses."""
from __future__ import annotations
import csv, hashlib, json
from functools import lru_cache
from pathlib import Path
import pandas as pd

AUDIT: dict[str,dict] = {}
COLUMNS = {
 'mid':['startTime','dataProvider','settlementDate','settlementPeriod','price','volume'],
 'dgws':['documentId','documentRevisionNumber','publishTime','processType','psrType','quantity','startTime','settlementDate','settlementPeriod'],
 'windfor':['publishTime','startTime','generation'],
 'fuelhh':['publishTime','startTime','settlementDate','settlementPeriod','fuelType','generation'],
 'system_prices':['settlementDate','settlementPeriod','startTime','createdDateTime','systemSellPrice','systemBuyPrice'],
 'neso_demand':['SETTLEMENT_DATE','SETTLEMENT_PERIOD','TSD','EMBEDDED_WIND_GENERATION','EMBEDDED_WIND_CAPACITY','EMBEDDED_SOLAR_GENERATION','EMBEDDED_SOLAR_CAPACITY'],
 'n2ex':['Date','Delivery Period','Price'],
 'b1610':['dataset','psrType','bmUnit','nationalGridBmUnitId','settlementDate','settlementPeriod','halfHourEndTime','quantityMWh','settlementRunType'],
 'bmu':['bmUnit','asset','capacityMW','technology'],
}

def read_json(path:Path):
    with path.open('r',encoding='utf-8-sig') as f: obj=json.load(f)
    rows=obj if isinstance(obj,list) else obj.get('data')
    if not isinstance(rows,list):raise ValueError(f'Expected publisher record list: {path}')
    return rows

def _hash(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def verify_sources(root:Path)->pd.DataFrame:
    """Verify every retained source payload against its SHA-256 digest."""
    out=[]
    with (root/'source_manifest.csv').open(newline='',encoding='utf-8') as f:
        for row in csv.DictReader(f):
            path=(root/row['path']).resolve()
            if not path.is_relative_to((root/'raw').resolve()):
                raise ValueError('Unsafe source path')
            if not path.is_file():raise FileNotFoundError(path)
            if path.stat().st_size!=int(row['bytes']) or _hash(path)!=row['sha256']:
                raise ValueError(f'Source checksum mismatch: {row["path"]}')
            out.append({'path':row['path'],'sha256':row['sha256'],'verified':True})
    actual={p.relative_to(root).as_posix() for p in (root/'raw').rglob('*') if p.is_file()}
    expected={r['path'] for r in out}
    if len(expected)!=len(out) or actual!=expected:
        raise ValueError('Raw file inventory differs from source_manifest.csv')
    return pd.DataFrame(out)

@lru_cache(maxsize=16)
def load_table(raw:Path, table:str)->pd.DataFrame:
    """Build an in-memory observation table from original files in a fixed order."""
    raw=Path(raw)
    if table not in COLUMNS:raise ValueError(f'Unknown observation family: {table}')
    cols=COLUMNS[table];frames=[];source_rows=0;files=0;selected_rows=0
    if table in ['mid','dgws','windfor','fuelhh','system_prices']:
        family={'system_prices':'SYSTEM_PRICES'}.get(table,table.upper())
        paths=sorted((raw/family).glob('*.json'))
        if not paths:raise FileNotFoundError(f'No {family} download files under {raw}')
        for path in paths:
            records=read_json(path);source_rows+=len(records);files+=1
            if table=='dgws':records=[r for r in records if r.get('processType')=='Day ahead']
            if table=='fuelhh':records=[r for r in records if r.get('fuelType')=='WIND' and '2022-01-01'<=r.get('startTime','')<='2026-10-14T13:30:00Z']
            if table=='windfor':records=[r for r in records if '2022-01-01'<=r.get('startTime','')<'2026-01-01']
            if records:
                part=pd.DataFrame.from_records(records).reindex(columns=cols)
                part['__file']=str(path.relative_to(raw)).replace('\\','/')
                frames.append(part)
        if not frames:raise ValueError(f'No usable publisher observations in {table}')
        data=pd.concat(frames,ignore_index=True);selected_rows=len(data)
        # Remove equal records repeated at inclusive download boundaries. Conflicting
        # observations remain for the stage-specific revision rules in market.py.
        data=data.drop_duplicates(cols,keep='first').reset_index(drop=True)
    elif table=='neso_demand':
        for path in sorted((raw/'NESO_DEMAND').glob('demand_*.csv')):
            part=pd.read_csv(path,encoding='utf-8-sig',low_memory=False);source_rows+=len(part);files+=1
            part=part[cols].copy();part['__file']=path.name;frames.append(part)
        data=pd.concat(frames,ignore_index=True);selected_rows=len(data)
    elif table=='n2ex':
        path=raw/'N2EX/N2EX_GB_Day_Ahead.csv'
        data=pd.read_csv(path,dtype={'Date':str,'Delivery Period':str,'Price':str},encoding='utf-8-sig')
        source_rows=len(data);files=1
        data=data[(data.Date>='2022-01-01')&(data.Date<'2026-01-01')].copy()
        data['__file']='N2EX/N2EX_GB_Day_Ahead.csv';selected_rows=len(data)
    elif table=='b1610':
        path=raw/'B1610/b1610_six_bmus_2023-05-01_to_2025-11-30.csv'
        data=pd.read_csv(path,encoding='utf-8-sig',low_memory=False)
        source_rows=len(data);files=1
        data=data.reindex(columns=cols);data['__file']=path.name;frames=[data]
        for path in sorted((raw/'B1610/boundary').glob('*.json')):
            rec=read_json(path);source_rows+=len(rec);files+=1
            part=pd.DataFrame(rec)
            # The third returned interval overlaps the existing six-unit export.
            part=part[(part.settlementDate=='2023-05-01')&part.settlementPeriod.isin([1,2])].copy()
            # Preserve the original exported quantity convention; do not infer
            # missing meter quantities backwards from daily revenue.
            part=part.rename(columns={'quantity':'quantityMWh'}).reindex(columns=cols)
            part['__file']='boundary/'+path.name;frames.append(part)
        data=pd.concat(frames,ignore_index=True);selected_rows=len(data)
    else:
        data=pd.read_csv(raw/'B1610/bmu_manifest.csv',encoding='utf-8-sig')[cols]
        data['capacityMW']=pd.to_numeric(data.capacityMW)
        source_rows=selected_rows=len(data);files=1
    AUDIT[table]={'download_files_read':files,'rows_in_original_files':source_rows,'rows_selected_before_equal_duplicate_removal':selected_rows,'rows_after_selection':len(data),'raw_files_modified':False}
    return data.reset_index(drop=True)

def clear_cache():load_table.cache_clear()
