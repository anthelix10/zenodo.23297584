"""Raw-source cash reconstruction for the retained BESS paper.
Forecast and LP routines extracted from the deposited reference model.
The past-only preprocessing and forecasting functions are the deposited
paper implementation. Older upload-audit schedules are not substituted.
"""
from __future__ import annotations
import calendar,json,math
from pathlib import Path
from functools import lru_cache
from types import SimpleNamespace
import numpy as np
import pandas as pd
from scipy.optimize import linprog
from scipy.sparse import lil_matrix,csr_matrix
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
CFG=SimpleNamespace(warmup_start="2019-01-01 00:00:00+00:00",
 evaluation_start="2020-01-01 00:00:00+00:00",evaluation_end="2025-12-31 23:30:00+00:00",
 dt_h=.5,bess_power_mw=100.,round_trip_efficiency=.93,purchase_access_mw=60.,
 sale_access_mw=70.,throughput_cost_gbp_mwh=4.,external_trade_fee_gbp_mwh=.25,
 forecast_horizon_days=2,execute_days=1)


def same_period_rolling(series: pd.Series, shift_days: int, window_days: int, min_days: int = 7, statistic: str = "mean") -> pd.Series:
    """Same half-hour rolling statistic, shifted enough to be known 48 h ahead."""
    arr = series.to_numpy().reshape(-1, 48)
    tab = pd.DataFrame(arr, index=pd.date_range(series.index[0].floor("D"), periods=arr.shape[0], freq="D", tz="UTC"))
    shifted = tab.shift(shift_days)
    if statistic == "median":
        rolled = shifted.rolling(window_days, min_periods=min_days).median()
    elif statistic == "std":
        rolled = shifted.rolling(window_days, min_periods=min_days).std()
    else:
        rolled = shifted.rolling(window_days, min_periods=min_days).mean()
    return pd.Series(rolled.to_numpy().reshape(-1), index=series.index)


def make_price_features(df: pd.DataFrame) -> pd.DataFrame:
    idx = df.index
    sp0 = df["sp_utc"].to_numpy() - 1
    hour_angle = 2 * np.pi * sp0 / 48.0
    dow_angle = 2 * np.pi * df["dayofweek"].to_numpy() / 7.0
    doy_angle = 2 * np.pi * (idx.dayofyear.to_numpy() - 1) / 365.25
    X = pd.DataFrame(index=idx)
    X["tod_sin"] = np.sin(hour_angle); X["tod_cos"] = np.cos(hour_angle)
    X["dow_sin"] = np.sin(dow_angle); X["dow_cos"] = np.cos(dow_angle)
    X["doy_sin"] = np.sin(doy_angle); X["doy_cos"] = np.cos(doy_angle)
    p = df["price_gbp_mwh"]
    X["price_lag_96"] = p.shift(96)
    X["price_lag_336"] = p.shift(336)
    X["price_lag_672"] = p.shift(672)
    X["price_same_sp_mean_28d"] = same_period_rolling(p, shift_days=2, window_days=28, statistic="mean")
    X["price_same_sp_std_28d"] = same_period_rolling(p, shift_days=2, window_days=28, statistic="std")
    d = df["neso_transmission_system_demand_mw"]
    X["demand_lag_96"] = d.shift(96)
    X["demand_lag_336"] = d.shift(336)
    X["wind_cf_lag_96"] = df["wind_cf"].shift(96)
    X["solar_cf_lag_96"] = df["solar_cf"].shift(96)
    X["wind_fc_log"] = np.log1p(np.maximum(df["dgws_day_ahead_wind_total_mw"], 0.0))
    X["solar_fc_log"] = np.log1p(np.maximum(df["dgws_day_ahead_solar_total_mw"], 0.0))
    X["trend_years"] = (idx - idx[0]).total_seconds() / (365.25 * 86400)
    X["dgws_imputed"] = df["dgws_imputed"].astype(float)
    return X


def rolling_yearly_price_forecasts(
    df: pd.DataFrame,
    use_gradient_boosting: bool = False,
    clip_predictions: bool = True,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Generate yearly out-of-sample forecasts and a complete accuracy audit.

    Every test year uses at most the preceding 730 days, bounded by the start of
    the packaged warm-up panel. Test-feature gaps are filled only with medians
    estimated from that year's valid training sample. Ridge and optional gradient-
    boosting predictions may be clipped to the 0.1st and 99.9th percentiles of
    the training target; the audit reports the bounds and affected observations.
    """
    X = make_price_features(df)
    y = df["price_gbp_mwh"].copy()
    pred_ridge = pd.Series(index=df.index, dtype=float)
    pred_gb = pd.Series(index=df.index, dtype=float)
    rows: list[dict] = []

    def add_metrics(
        *, year: int | str, model: str, actual: np.ndarray, forecast: np.ndarray,
        train_start: pd.Timestamp | None = None, train_end: pd.Timestamp | None = None,
        training_rows: int | None = None, lo: float | None = None, hi: float | None = None,
        clipped_low: int = 0, clipped_high: int = 0,
    ) -> None:
        err = forecast - actual
        rows.append({
            "year": year,
            "model": model,
            "n": int(len(actual)),
            "mae_gbp_mwh": float(np.mean(np.abs(err))),
            "rmse_gbp_mwh": float(np.sqrt(np.mean(err**2))),
            "correlation": float(np.corrcoef(actual, forecast)[0, 1]),
            "mean_actual": float(np.mean(actual)),
            "mean_forecast": float(np.mean(forecast)),
            "training_start": "" if train_start is None else train_start.isoformat(),
            "training_end_exclusive": "" if train_end is None else train_end.isoformat(),
            "training_history_days": np.nan if train_start is None else int((train_end - train_start).days),
            "training_rows": np.nan if training_rows is None else int(training_rows),
            "clip_predictions": bool(clip_predictions) if model in {"ridge", "gradient_boosting"} else False,
            "clip_lower_gbp_mwh": np.nan if lo is None else float(lo),
            "clip_upper_gbp_mwh": np.nan if hi is None else float(hi),
            "clipped_low_count": int(clipped_low),
            "clipped_high_count": int(clipped_high),
            "clipped_total_count": int(clipped_low + clipped_high),
            "clipped_fraction": float((clipped_low + clipped_high) / len(actual)) if len(actual) else np.nan,
        })

    for year in range(2020, 2026):
        test_mask = df.index.year == year
        train_end = pd.Timestamp(f"{year}-01-01", tz="UTC")
        train_start = max(pd.Timestamp(CFG.warmup_start), train_end - pd.Timedelta(days=730))
        train_mask = (df.index >= train_start) & (df.index < train_end)
        cols = X.columns
        train = X.loc[train_mask, cols].copy()
        target = y.loc[train_mask]
        test = X.loc[test_mask, cols].copy()
        valid_train = train.notna().all(axis=1) & target.notna()
        med = train.loc[valid_train].median()
        train_f = train.loc[valid_train].fillna(med)
        test_f = test.fillna(med)
        if test_f.isna().any(axis=None):
            missing = test_f.columns[test_f.isna().any()].tolist()
            raise RuntimeError(f"Test features remain missing for {year}: {missing}")
        y_t = np.arcsinh(target.loc[valid_train].to_numpy() / 50.0)
        ridge = make_pipeline(StandardScaler(), Ridge(alpha=25.0))
        ridge.fit(train_f, y_t)
        pr_raw = 50.0 * np.sinh(ridge.predict(test_f))
        lo, hi = target.loc[valid_train].quantile([0.001, 0.999])
        lo_f, hi_f = float(lo), float(hi)
        ridge_low = int((pr_raw < lo_f).sum())
        ridge_high = int((pr_raw > hi_f).sum())
        pr = np.clip(pr_raw, lo_f, hi_f) if clip_predictions else pr_raw
        pred_ridge.loc[test_mask] = pr
        actual = y.loc[test_mask].to_numpy()
        add_metrics(
            year=year, model="ridge", actual=actual, forecast=pr,
            train_start=train_start, train_end=train_end,
            training_rows=int(valid_train.sum()), lo=lo_f, hi=hi_f,
            clipped_low=ridge_low, clipped_high=ridge_high,
        )

    naive = df["price_gbp_mwh"].shift(96)
    seasonal = same_period_rolling(
        df["price_gbp_mwh"], shift_days=2, window_days=28, statistic="median"
    )
    pred = pd.DataFrame({"ridge": pred_ridge, "naive_lag_2d": naive, "seasonal_28d": seasonal})
    if use_gradient_boosting:
        pred["gradient_boosting"] = pred_gb
    eval_mask = (df.index >= pd.Timestamp(CFG.evaluation_start)) & (df.index <= pd.Timestamp(CFG.evaluation_end))
    pred.loc[eval_mask] = pred.loc[eval_mask].apply(
        lambda col: col.fillna(pred.loc[eval_mask, "ridge"])
    )
    aa_all = y.loc[eval_mask].to_numpy()
    for name in ["naive_lag_2d", "seasonal_28d"]:
        pp_all = pred.loc[eval_mask, name].to_numpy()
        for year in range(2020, 2026):
            mask_year = df.loc[eval_mask].index.year == year
            add_metrics(
                year=year, model=name,
                actual=aa_all[mask_year], forecast=pp_all[mask_year],
            )

    for name in pred.columns:
        pp_all = pred.loc[eval_mask, name].to_numpy()
        model_rows = [r for r in rows if r["model"] == name and isinstance(r["year"], int)]
        add_metrics(
            year="2020-2025 pooled", model=name,
            actual=aa_all, forecast=pp_all,
            clipped_low=sum(int(r["clipped_low_count"]) for r in model_rows),
            clipped_high=sum(int(r["clipped_high_count"]) for r in model_rows),
        )
    return pred, pd.DataFrame(rows)


@lru_cache(maxsize=None)
def battery_lp_matrices(T: int, energy_mwh: float, purchase_mw: float, sale_mw: float) -> tuple:
    dt = CFG.dt_h
    eta = math.sqrt(CFG.round_trip_efficiency)
    P = CFG.bess_power_mw
    n = 3 * T
    Aeq = lil_matrix((T + 1, n)); beq = np.zeros(T + 1)
    for t in range(T):
        Aeq[t, t] = -eta * dt
        Aeq[t, T + t] = dt / eta
        Aeq[t, 2*T + t] = 1.0
        if t > 0:
            Aeq[t, 2*T + t - 1] = -1.0
    Aeq[T, 3*T - 1] = 1.0
    Aub = lil_matrix((T, n)); bub = np.full(T, P)
    for t in range(T):
        Aub[t, t] = 1.0; Aub[t, T+t] = 1.0
    bounds = [(0.0, purchase_mw)] * T + [(0.0, sale_mw)] * T + [(0.0, energy_mwh)] * T
    return csr_matrix(Aeq), beq, csr_matrix(Aub), bub, bounds


def solve_battery_horizon(price_forecast: np.ndarray, initial_soc: float, energy_mwh: float,
                          purchase_mw: float = CFG.purchase_access_mw, sale_mw: float = CFG.sale_access_mw) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    p = np.asarray(price_forecast, dtype=float)
    T = len(p); dt = CFG.dt_h
    Aeq, beq0, Aub, bub, bounds = battery_lp_matrices(T, float(energy_mwh), float(purchase_mw), float(sale_mw))
    beq = beq0.copy(); beq[0] = initial_soc; beq[T] = initial_soc
    obj = np.r_[
        (p + CFG.throughput_cost_gbp_mwh + CFG.external_trade_fee_gbp_mwh) * dt,
        (-p + CFG.throughput_cost_gbp_mwh + CFG.external_trade_fee_gbp_mwh) * dt,
        np.zeros(T),
    ]
    res = linprog(obj, A_ub=Aub, b_ub=bub, A_eq=Aeq, b_eq=beq, bounds=bounds, method="highs")
    if not res.success:
        raise RuntimeError(res.message)
    x = res.x
    return x[:T], x[T:2*T], x[2*T:]


def rolling_dispatch(df_eval: pd.DataFrame, forecast: pd.Series, duration_h: int,
                     purchase_mw: float = CFG.purchase_access_mw, sale_mw: float = CFG.sale_access_mw) -> pd.DataFrame:
    idx = df_eval.index
    n = len(df_eval); energy = CFG.bess_power_mw * duration_h
    h = CFG.forecast_horizon_days * 48; execute = CFG.execute_days * 48
    charge = np.zeros(n); discharge = np.zeros(n); soc_out = np.zeros(n)
    p_fc = forecast.reindex(idx).to_numpy(dtype=float)
    p_actual = df_eval["price_gbp_mwh"].to_numpy(dtype=float)
    soc0 = 0.5 * energy
    for start in range(0, n, execute):
        stop = min(n, start + h)
        c, d, s = solve_battery_horizon(p_fc[start:stop], soc0, energy, purchase_mw, sale_mw)
        k = min(execute, stop-start)
        charge[start:start+k] = c[:k]
        discharge[start:start+k] = d[:k]
        soc_out[start:start+k] = s[:k]
        soc0 = float(np.clip(s[k-1], 0.0, energy))
    dt = CFG.dt_h
    cash = (p_actual*(discharge-charge) - (CFG.throughput_cost_gbp_mwh+CFG.external_trade_fee_gbp_mwh)*(charge+discharge))*dt
    gross = p_actual*(discharge-charge)*dt
    out = pd.DataFrame(index=idx)
    out["charge_mw"] = charge; out["discharge_mw"] = discharge; out["soc_mwh"] = soc_out
    out["bess_cash_gbp"] = cash; out["bess_gross_cash_gbp"] = gross
    out["throughput_mwh"] = (charge+discharge)*dt
    out["simultaneous_mwh"] = np.minimum(charge,discharge)*dt
    out["net_external_mw"] = discharge-charge
    out["price_forecast_gbp_mwh"] = p_fc; out["price_actual_gbp_mwh"] = p_actual
    out["date"] = idx.floor("D"); out["year"] = idx.year; out["month"] = idx.month
    return out

def raw_table(path: Path, table: str) -> pd.DataFrame:
    # path is the original download directory, not a database or calculated file.
    from source_data import load_table
    return load_table(path, table).copy()

def historical_gap_fill(s: pd.Series, sp: pd.Series) -> pd.Series:
    """Deposited paper policy: previous observation in the same UTC slot,
    followed by the previous observation in the series. No future interpolation.
    """
    s=pd.to_numeric(s,errors='coerce').copy()
    return s.fillna(s.groupby(sp,sort=False).ffill()).ffill()

def battery_inputs(path:Path):
    mid=raw_table(path,'mid');mid['t']=pd.to_datetime(mid.startTime,utc=True)
    mid=mid.drop_duplicates(['t','dataProvider'],keep='last')
    prices=mid.pivot(index='t',columns='dataProvider',values='price')
    volumes=mid.pivot(index='t',columns='dataProvider',values='volume')
    # Original master-panel membership was driven by available MID records.
    raw=pd.DataFrame(index=prices.index)
    raw['mid_combined_price_gbp_mwh']=(prices*volumes).sum(axis=1)/volumes.sum(axis=1)
    sy=raw_table(path,'system_prices');sy['t']=pd.to_datetime(sy.startTime,utc=True)
    sy=sy.drop_duplicates('t',keep='last').set_index('t')
    raw['system_sell_price']=sy.systemSellPrice;raw['system_buy_price']=sy.systemBuyPrice
    dg=raw_table(path,'dgws');dg['t']=pd.to_datetime(dg.startTime,utc=True);dg['pub']=pd.to_datetime(dg.publishTime,utc=True)
    dg=dg[(dg.processType=='Day ahead')&(dg.pub<=dg.t)].sort_values(['t','pub','documentRevisionNumber']).drop_duplicates(['t','psrType'],keep='last')
    dg=dg.pivot(index='t',columns='psrType',values='quantity')
    raw['dgws_day_ahead_wind_total_mw']=dg[['Wind Offshore','Wind Onshore']].sum(axis=1,min_count=1)
    raw['dgws_day_ahead_solar_total_mw']=dg.Solar
    ns=raw_table(path,'neso_demand');ns['t']=pd.to_datetime(ns.SETTLEMENT_DATE,format='mixed').dt.tz_localize('Europe/London').dt.tz_convert('UTC')+pd.to_timedelta((ns.SETTLEMENT_PERIOD-1)*30,unit='min')
    ns=ns.drop_duplicates('t',keep='last').set_index('t')
    raw['neso_transmission_system_demand_mw']=ns.TSD
    raw['neso_embedded_wind_cf']=ns.EMBEDDED_WIND_GENERATION/ns.EMBEDDED_WIND_CAPACITY
    raw['neso_embedded_solar_cf']=ns.EMBEDDED_SOLAR_GENERATION/ns.EMBEDDED_SOLAR_CAPACITY
    grid=pd.date_range(CFG.warmup_start,CFG.evaluation_end,freq='30min',tz='UTC')
    d=raw.reindex(grid);d.index.name='start_time'
    d['sp_utc']=d.index.hour*2+d.index.minute//30+1
    d['date_utc']=d.index.floor('D');d['year']=d.index.year;d['month']=d.index.month;d['dayofweek']=d.index.dayofweek
    d['dgws_imputed']=d[['dgws_day_ahead_wind_total_mw','dgws_day_ahead_solar_total_mw']].isna().any(axis=1)
    p=d.mid_combined_price_gbp_mwh.fillna(d[['system_sell_price','system_buy_price']].mean(axis=1))
    imputed={'price':int(p.isna().sum())}
    d['price_gbp_mwh']=historical_gap_fill(p,d.sp_utc)
    for c in ['neso_transmission_system_demand_mw','neso_embedded_wind_cf','neso_embedded_solar_cf','dgws_day_ahead_wind_total_mw','dgws_day_ahead_solar_total_mw']:
        imputed[c]=int(d[c].isna().sum());d[c]=historical_gap_fill(d[c],d.sp_utc)
    d['wind_cf']=d.neso_embedded_wind_cf.clip(0,1.05);d['solar_cf']=d.neso_embedded_solar_cf.clip(0,1.05)
    return d,{'input_periods':len(d),'gap_fill_counts':imputed,'gap_fill_policy':'Past-only same-UTC-slot forward fill, followed by forward fill.'}

def renewable_cash(path:Path):
    g=raw_table(path,'b1610');caps=raw_table(path,'bmu').set_index('bmUnit').capacityMW
    # Faithful original settlement-key construction: only SP1-48, including on
    # the autumn clock-change day. Raw SP49-50 are preserved in the original raw download files.
    g=g[g.settlementPeriod<=48].drop_duplicates(['bmUnit','settlementDate','settlementPeriod'],keep='last')
    mid=raw_table(path,'mid').drop_duplicates(['settlementDate','settlementPeriod','dataProvider'],keep='last')
    p=mid.pivot(index=['settlementDate','settlementPeriod'],columns='dataProvider',values='price')
    v=mid.pivot(index=['settlementDate','settlementPeriod'],columns='dataProvider',values='volume')
    price=(p*v).sum(axis=1)/v.sum(axis=1)
    prices=price.rename('price').to_frame();prices['price_key_present']=1
    d=g.merge(prices,left_on=['settlementDate','settlementPeriod'],right_index=True,how='left',validate='many_to_one')
    d['cash_per_mw']=d.quantityMWh*d.price/d.bmUnit.map(caps)
    # Pandas sums preserve the historical construction; unavailable price counts
    # are recorded below rather than silently described as observed zeros.
    day=d.groupby(['settlementDate','bmUnit']).agg(cash=('cash_per_mw','sum'),periods=('settlementPeriod','nunique'),priced=('price','count'),matched_keys=('price_key_present','sum')).reset_index()
    q=day.pivot(index='settlementDate',columns='bmUnit',values='cash')
    n=day.pivot(index='settlementDate',columns='bmUnit',values='matched_keys')
    r=pd.DataFrame({'wind_gross':q.drop(columns='T_LARKS-1').mean(axis=1),'solar_gross':q['T_LARKS-1'],'periods':n.min(axis=1)})
    r.index.name='date'
    audit={'raw_generation_records':len(raw_table(path,'b1610')),'missing_price_matches':int(d.price.isna().sum()),'source_dates':len(r),'boundary_periods_present':int(((g.settlementDate=='2023-05-01')&g.settlementPeriod.isin([1,2])).sum()),'benchmark_settlement_period_rule':'SP1-48, as retained in original study; no SP49-50 removal from raw input.'}
    return r.reset_index(),audit

def wind_cash(path:Path):
    ix=pd.date_range('2022-01-01','2025-12-31 23:30',freq='30min',tz='UTC')
    r=pd.DataFrame({'t':ix});r['date']=r.t.dt.tz_convert('Europe/London').dt.strftime('%Y-%m-%d')
    r['utc_date']=r.t.dt.strftime('%Y-%m-%d')
    f=raw_table(path,'windfor');f['t']=pd.to_datetime(f.startTime,utc=True);f['pub']=pd.to_datetime(f.publishTime,utc=True)
    f=f.drop_duplicates(['t','pub'],keep='last');half=f.copy();half['t']+=pd.Timedelta(minutes=30)
    f=pd.concat([f,half],ignore_index=True).sort_values(['pub','t']).rename(columns={'generation':'value'})[['t','pub','value']]
    cutoff=(pd.to_datetime(r.date)-pd.Timedelta(days=1)+pd.Timedelta(hours=9)).dt.tz_localize('Europe/London').dt.tz_convert('UTC')
    for label,co in [('da',cutoff),('h2',r.t-pd.Timedelta(hours=2))]:
        left=r[['t']].copy();left['cut']=co;left['i']=np.arange(len(r))
        out=pd.merge_asof(left.sort_values('cut'),f,left_on='cut',right_on='pub',by='t',direction='backward').sort_values('i')
        r['wind_'+label+'_mw']=out.value.to_numpy();r[label+'_publish_utc']=out.pub.to_numpy()
        assert not ((out.pub>out.cut)&out.pub.notna()).any()
    fu=raw_table(path,'fuelhh');fu['t']=pd.to_datetime(fu.startTime,utc=True);fu['pub']=pd.to_datetime(fu.publishTime,utc=True)
    fu=fu.sort_values(['t','pub']).drop_duplicates('t',keep='last').set_index('t')
    r['wind_actual_mw']=fu.generation.reindex(ix).to_numpy()
    cal=fu[(fu.index>='2025-01-01')&(fu.index<='2026-10-14T13:30:00Z')].generation
    scale=30./cal.mean()
    mid=raw_table(path,'mid');mid=mid[mid.dataProvider=='APXMIDP'].copy();mid['t']=pd.to_datetime(mid.startTime,utc=True)
    mid=mid.drop_duplicates('t',keep='last').set_index('t');r['mid_gbp_mwh']=mid.price.reindex(ix).to_numpy()
    sy=raw_table(path,'system_prices');sy['t']=pd.to_datetime(sy.startTime,utc=True);sy=sy.drop_duplicates('t',keep='last').set_index('t')
    r['cashout_gbp_mwh']=sy.systemSellPrice.reindex(ix).to_numpy()
    nx=raw_table(path,'n2ex');nx['t']=(pd.to_datetime(nx.Date,format='mixed')+pd.to_timedelta(nx['Delivery Period'].str[:5]+':00')).dt.tz_localize('UTC')
    nx=nx.drop_duplicates('t',keep='last').set_index('t');r['da_gbp_mwh']=pd.to_numeric(nx.Price).reindex(ix.floor('h')).to_numpy()
    cols=['da_gbp_mwh','mid_gbp_mwh','cashout_gbp_mwh','wind_da_mw','wind_h2_mw','wind_actual_mw']
    D,I,C,QD,QH,QM=[r[c].to_numpy(float) for c in cols]
    qd,qh,qm=QD*scale*.5,QH*scale*.5,QM*scale*.5
    receipts=qd*D+(qh-qd)*I+(qm-qh)*C
    cost=.5*np.abs(qh-qd);owner=qm*(D-1)
    pnl=receipts-owner-cost
    r['ppa100_fee1']=qm+(qh-qd)*(I-D)+(qm-qh)*(C-D)-cost
    r['ppa100_export']=qm;r['valid']=np.isfinite(r[cols].to_numpy(float)).all(axis=1)
    error=float(np.nanmax(abs(pnl-r.ppa100_fee1)))
    assert error<1e-7
    return r,{'ppa_half_hours':len(r),'valid_half_hours':int(r.valid.sum()),'national_scale_for_100_MW':scale,'calibration_records':len(cal),'calibration_end_utc':'2026-10-14T13:30:00Z','cash_identity_max_error_gbp':error}

def eligible_months(d):
    keys=d.groupby(['year','month']).size()
    ok={k for k,n in keys.items() if n>=calendar.monthrange(*k)[1]-1}
    return d[[tuple(k) in ok for k in d[['year','month']].to_numpy()]].sort_values('date').reset_index(drop=True)

def seasonal_control(path:Path):
    """Rebuild the paper's four-week sensitivity on its original period sample.
    This control used settlement-key prices, Jan 10 2023--Dec 22 2025,
    and the historical zero-volume index convention. It is distinct from
    the canonical 2019--2025 forecast training grid.
    """
    mid=raw_table(path,'mid').drop_duplicates(['settlementDate','settlementPeriod','dataProvider'],keep='last')
    p=mid.pivot(index=['settlementDate','settlementPeriod'],columns='dataProvider',values='price')
    v=mid.pivot(index=['settlementDate','settlementPeriod'],columns='dataProvider',values='volume')
    q=((p*v).sum(axis=1)/v.sum(axis=1)).rename('price').reset_index()
    q=q[(q.settlementDate>='2023-01-10')&(q.settlementDate<='2025-12-22')&(q.settlementPeriod<=48)]
    excluded=['2023-03-26','2023-06-07','2023-07-17','2023-12-29','2024-03-31','2025-03-30']
    q=q[~q.settlementDate.isin(excluded)].sort_values(['settlementDate','settlementPeriod'])
    ix=pd.DatetimeIndex(pd.to_datetime(q.settlementDate)+pd.to_timedelta((q.settlementPeriod-1)*30,unit='min'))
    zero_volume=int(q.price.isna().sum())
    actual=pd.Series(q.price.fillna(0).to_numpy(),index=ix)
    frame=pd.DataFrame({'p':actual,'sp':q.settlementPeriod.to_numpy()},index=ix)
    forecast=pd.Series(index=ix,dtype=float)
    for sp,g in frame.groupby('sp'):
        forecast.loc[g.index]=g.p.shift(2).rolling(28,min_periods=7).median()
    forecast=forecast.fillna(actual.shift(96)).fillna(actual.expanding().mean().shift(1)).fillna(actual.iloc[0])
    r=rolling_dispatch(pd.DataFrame({'price_gbp_mwh':actual},index=ix),forecast,2)
    return r,{'periods':len(r),'dates':r.date.nunique(),'zero_volume_price_convention_count':zero_volume,'sample_start':'2023-01-10','sample_end':'2025-12-22'}

def build(path:Path,work:Path|None=None):
    """Everything below is computed from the original raw download files, never retained cash outputs."""
    d,ba=battery_inputs(path)
    pred,fa=rolling_yearly_price_forecasts(d,use_gradient_boosting=False)
    frame=d[d.index>=pd.Timestamp(CFG.evaluation_start)]
    ridge=rolling_dispatch(frame,pred.ridge,2)
    seasonal,sa=seasonal_control(path)
    print('Raw -> price forecasts -> both battery schedules complete',flush=True)
    ren,ra=renewable_cash(path)
    bd=ridge.groupby('date').bess_cash_gbp.sum();bd.index=bd.index.strftime('%Y-%m-%d')
    sd=seasonal.groupby('date').bess_cash_gbp.sum();sd.index=sd.index.strftime('%Y-%m-%d')
    reference=ren.merge(bd.rename('bess_cash_gbp'),left_on='date',right_index=True).merge(sd.rename('bess_seasonal_gbp'),left_on='date',right_index=True)
    reference=reference[(reference.date>='2023-05-01')&(reference.date<='2025-11-30')&(reference.periods>=48)].copy()
    # Freeze the original study's date eligibility, not its cash values. These two
    # dates were absent from the archived operating panel although the recovered
    # publisher snapshot now contains them. The source observations remain in raw.
    reference=reference[~reference.date.isin(['2023-07-17','2023-12-29'])].copy()
    reference['date']=pd.to_datetime(reference.date);reference['year']=reference.date.dt.year;reference['month']=reference.date.dt.month
    reference=eligible_months(reference)
    wind,wa=wind_cash(path)
    pp=wind.groupby('utc_date').agg(ppa100_fee1=('ppa100_fee1','sum'),ppa100_export=('ppa100_export','sum'),valid=('valid','sum'),intervals=('valid','size')).reset_index().rename(columns={'utc_date':'date'})
    pp=pp[(pp.valid==48)&(pp.intervals==48)].merge(bd.rename('bess_cash_gbp'),left_on='date',right_index=True)
    pp['year']=pd.to_datetime(pp.date).dt.year;pp['month']=pd.to_datetime(pp.date).dt.month;pp=eligible_months(pp)
    # Staged battery cash appears ONLY in the paper's monthly correlation check.
    B=ridge.reindex(pd.DatetimeIndex(wind.t));net=(B.discharge_mw-B.charge_mw).to_numpy()*.5
    da=np.repeat(net.reshape(-1,2).sum(axis=1)/2,2);th=B.throughput_mwh.to_numpy()
    staged=da*wind.da_gbp_mwh.to_numpy()+(net-da)*wind.mid_gbp_mwh.to_numpy()-.5*abs(net-da)-4*th-.25*abs(da)
    wind['bess_staged']=staged;wind['original_bess_cash']=B.bess_cash_gbp.to_numpy()
    daily=wind.groupby('date').agg(wind100=('ppa100_fee1','sum'),export100=('ppa100_export','sum'),bess_staged=('bess_staged','sum'),count=('valid','size'),valid=('valid','sum')).reset_index()
    dates=pd.to_datetime(daily.date)
    expected=((dates+pd.Timedelta(days=1)).dt.tz_localize('Europe/London').dt.tz_convert('UTC')-dates.dt.tz_localize('Europe/London').dt.tz_convert('UTC')).dt.total_seconds()/1800
    daily=daily[(daily['count']==expected)&(daily.valid==expected)].copy();dates=pd.to_datetime(daily.date)
    daily['year']=dates.dt.year;daily['month']=dates.dt.month
    monthly=daily.groupby(['year','month'],as_index=False).agg(wind100=('wind100','sum'),export100=('export100','sum'),bess_staged=('bess_staged','sum'),n_days=('date','size'))
    monthly=monthly[[r.n_days==calendar.monthrange(int(r.year),int(r.month))[1] for r in monthly.itertuples()]].copy()
    monthly['date']=[f'{int(y)}-{int(m):02d}-01' for y,m in monthly[['year','month']].to_numpy()]
    # Original shared UTC-day eligibility and original settlement labels are kept.
    common=reference.copy();common['date']=common.date.dt.strftime('%Y-%m-%d');common=common.merge(pp[['date','ppa100_fee1','ppa100_export']],on='date');common=eligible_months(common)
    print('ROW COUNTS',len(reference),len(pp),len(monthly),len(common),flush=True)
    assert (len(reference),len(pp),len(monthly),len(common))==(940,1267,31,877)
    de=ridge.charge_mw*.5*np.sqrt(.93)-ridge.discharge_mw*.5/np.sqrt(.93)
    assert np.max(abs(np.diff(ridge.soc_mwh)-de.iloc[1:]))<1e-7
    assert min(ridge.soc_mwh)>=-1e-7 and max(ridge.soc_mwh)<=200+1e-7
    audit={'battery':ba,'renewable':ra,'seasonal_control':sa,'PPA':wa,'reference_days':len(reference),'PPA_days':len(pp),'correlation_months':len(monthly),'shared_primary_days':len(common),'dispatch_periods':len(ridge),'forecast_policy':'Yearly Ridge fit with up to 730 preceding days; past-only raw-gap preprocessing.','maximum_simultaneous_charge_discharge_MW':float(np.minimum(ridge.charge_mw,ridge.discharge_mw).max())}
    if work:
        work.mkdir(parents=True,exist_ok=True)
        ridge.to_csv(work/'ridge_dispatch.csv',index=True)
        seasonal.to_csv(work/'seasonal_dispatch.csv',index=True)
        wind.to_csv(work/'ppa_cash.csv',index=False)
        reference.to_csv(work/'reference_daily.csv',index=False);pp.to_csv(work/'ppa_daily.csv',index=False);monthly.to_csv(work/'monthly.csv',index=False)
    return {'input_reference_daily':reference,'input_ppa_daily':pp,'input_monthly_correlation':monthly,'input_common_daily':common},audit,fa
