"""Ten-year PPA parameter search and confirmation from generated cash paths."""
from __future__ import annotations
import time
import numpy as np
import pandas as pd
KS=[0.,500.,1500.,2500.,5000.]
METHODS=['worst5','coverage95']
KEYS=['fee_gbp_mwh','effective_wind_mw','opening_K','wind_K_fraction']

def screen(f,ar,fees,exposures,label,nominal_terms=None):
    engine=f.Engine(ar[:,:,0]);zero=np.zeros_like(ar[:,:,0]);base={};rows=[]
    for k in KS:
        for frac in ([0.] if k==0 else [0.,.5,1.]):
            lim=engine.bounds(zero,k*100*(1-frac))
            base[k,frac]={m:min(f.stat(lim,m),engine.margin_limit(0))/100 for m in METHODS}
    for fee in fees:
        u=ar[:,:,1]+(fee-1)*ar[:,:,2]
        for x in exposures:
            p=x/100*u;cp=np.cumsum(p,axis=1);mp=float(p.mean());margin=engine.margin_limit(mp)
            for k in KS:
                cb=engine.bounds(p,k*100);fc={m:min(f.stat(cb,m),margin)/100 for m in METHODS}
                for frac in ([0.] if k==0 else [0.,.5,1.]):
                    wb=((cp+k*100*frac)/np.arange(1,11)).min(axis=1)
                    for m in METHODS:
                        fw=min(f.stat(wb,m),mp)/100
                        for nominal,share in (nominal_terms[x] if nominal_terms is not None else [(x,1.)]):
                            rows.append(dict(method=m,fee_gbp_mwh=fee,wind_mw=nominal,ppa_share=share,
                                effective_wind_mw=x,opening_K=k,wind_K_fraction=frac,
                                **f.outcome(base[k,frac][m],fw,fc[m])))
        print('PPA selection',label,'fee',fee,flush=True)
    return pd.DataFrame(rows)

def candidates(coarse,dense,fine):
    raw=pd.concat([dense,fine,coarse],ignore_index=True);terms=[]
    for bound in [800.,4000.]:
        t=raw[(raw.wind_mw<=bound)&raw.valid_percentage_base&raw.positive_combined]
        for k in KS:
            for m in METHODS:
                z=t[(t.opening_K==k)&(t.method==m)]
                for g in [z,z[z.fee_gbp_mwh==2.],z[z.wind_standalone_signed>=0],z[z.combined_floor>=z.bess_standalone]]:
                    top=g.drop_duplicates(['fee_gbp_mwh','effective_wind_mw','wind_K_fraction']).sort_values('pooling_percent',ascending=False).head(12)
                    for r in top.to_dict('records'):
                        for shift in [-6.25,0.,6.25]:
                            xx=r['effective_wind_mw']+shift
                            if 0<=xx<=bound:
                                terms.append(dict(fee_gbp_mwh=r['fee_gbp_mwh'],effective_wind_mw=xx,
                                    opening_K=k,wind_K_fraction=r['wind_K_fraction']))
    terms.extend(dict(fee_gbp_mwh=2.,effective_wind_mw=x,opening_K=0.,wind_K_fraction=0.)
                 for x in [0.,25.,237.5,365.625,415.625,625.])
    return pd.DataFrame(terms).drop_duplicates().sort_values(KEYS).reset_index(drop=True)

def confirm(f,terms):
    rows=[]
    for seed in [251001,251002,251003]:
        ar=f.draw(f.panel_ppa(),30000,seed);engine=f.Engine(ar[:,:,0]);zero=np.zeros_like(ar[:,:,0]);base={}
        for k in terms.opening_K.unique():
            for frac in [0.,.5,1.]:
                lim=engine.bounds(zero,k*100*(1-frac));base[k,frac]={m:min(f.stat(lim,m),engine.margin_limit(0))/100 for m in METHODS}
        for fee,ft in terms.groupby('fee_gbp_mwh'):
            u=ar[:,:,1]+(fee-1)*ar[:,:,2]
            for x,xt in ft.groupby('effective_wind_mw'):
                p=x/100*u;cp=np.cumsum(p,axis=1);mp=float(p.mean());mar=engine.margin_limit(mp)
                for k,kt in xt.groupby('opening_K'):
                    cb=engine.bounds(p,k*100);fc={m:min(f.stat(cb,m),mar)/100 for m in METHODS}
                    for r in kt.to_dict('records'):
                        frac=r['wind_K_fraction'];wb=((cp+k*100*frac)/np.arange(1,11)).min(axis=1)
                        for m in METHODS:
                            fw=min(f.stat(wb,m),mp)/100
                            rows.append(dict(**r,method=m,seed=seed,paths=30000,mean_ppa_cash=mp/100,
                                joint_path_pass=float(np.mean(cb>=fc[m]*100-1e-7)),**f.outcome(base[k,frac][m],fw,fc[m])))
        print('PPA full-search confirmation seed',seed,'complete',flush=True)
    d=pd.DataFrame(rows);group=d.groupby(KEYS+['method'])
    cols=['bess_standalone','wind_standalone_signed','separate_sum','combined_floor','pooling_gain','mean_ppa_cash','joint_path_pass']
    summary=group[cols].mean().reset_index()
    summary['all_seed_bases_positive']=group.valid_percentage_base.all().to_numpy()
    summary['pooling_percent']=np.where(summary.separate_sum>0,100*summary.pooling_gain/summary.separate_sum,np.nan)
    best=[]
    for bound in [800.,4000.]:
        for k in KS:
            for m in METHODS:
                z=summary[(summary.effective_wind_mw<=bound)&(summary.opening_K==k)&(summary.method==m)&(summary.separate_sum>0)&(summary.combined_floor>0)]
                if len(z):
                    r=z.sort_values(['pooling_percent','effective_wind_mw'],ascending=[False,True]).iloc[0].to_dict()
                    best.append(dict(bound_effective_mw=bound,**r))
    return pd.DataFrame(best),summary

def run(f):
    start=time.time();ar=f.draw(f.panel_ppa(),4000,241000)
    winds=np.r_[np.arange(0.,800.01,12.5),np.arange(900.,4000.01,100.)];nominal={}
    for w in winds:
        for share in [.25,.5,.75,1.]:nominal.setdefault(float(w*share),[]).append((float(w),float(share)))
    coarse=screen(f,ar,[.5,1.,1.5,2.,3.,5.,10.,15.],sorted(nominal),'initial',nominal)
    dense=screen(f,ar,np.r_[np.arange(.5,5.001,.25),10.,15.],np.arange(0.,4000.001,12.5),'broad fee')
    fine=screen(f,ar,np.round(np.arange(2.,2.7501,.025),3),np.arange(0.,4000.001,25.),'fine fee')
    terms=candidates(coarse,dense,fine)
    # Large provisional grids are intentionally not delivered as final outputs.
    # Their dimensions and the selected candidates retain the search audit.
    dimensions=pd.DataFrame([{'stage':name,'screen_rows':len(d),'paths':4000,'seed':241000} for name,d in [('initial',coarse),('dense',dense),('fine',fine)]])
    print('Candidate contracts regenerated:',len(terms),flush=True)
    del coarse,dense,fine,ar
    best,confirmed=confirm(f,terms)
    f.write_table('search_dimensions',dimensions);f.write_table('search_best_by_bound',best)
    f.write_table('search_confirmed_contracts',confirmed)
    headline=best[(best.bound_effective_mw==4000)&best.opening_K.isin([0.,5000.])]
    checks=[]
    for r in f.INPUTS['selected_ppa_terms'].to_dict('records'):
        z=headline[(headline.opening_K==r['opening_K'])&(headline.method==r['method'])].iloc[0]
        checks.append(dict(case_id=r['case_id'],selected_fee=z.fee_gbp_mwh,selected_wind=z.effective_wind_mw,
            matches_paper_terms=bool(abs(z.fee_gbp_mwh-r['fee_gbp_mwh'])<1e-9 and abs(z.effective_wind_mw-r['effective_wind_mw'])<1e-9)))
    f.write_table('search_selection_check',pd.DataFrame(checks))
    print('Search seconds',round(time.time()-start,1),flush=True)
    return best
