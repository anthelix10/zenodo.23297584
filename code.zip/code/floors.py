"""Original floor, resampling and paper sensitivity routines, consolidated.
All computational inputs are reconstructed from raw sources by reproduce.py.
Tables labelled reported are comparison targets, never numerical model inputs.
"""
from __future__ import annotations
import argparse, calendar, hashlib, json, math, os, sys, time
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Dict, Tuple, Iterable

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
import numpy as np
import pandas as pd
from numba import njit, set_num_threads
from scipy.stats import norm
set_num_threads(1)

pm_CFG = SimpleNamespace(hurdle_fraction=0.70)
pm_MONTH_DAYS = {m: calendar.monthrange(2023, m)[1] for m in range(1, 13)}
rr_P_BESS_MW = 100.0
rr_TENOR_YEARS = 10
rr_RENEWABLE_REFERENCE_MW = 25.0
rr_ACCESS_REFERENCE = 0.50
rr_PROVIDER_UPSIDE_SHARE = 0.50
rr_REQUIRED_MARGIN_FRACTION = 0.05
rr_HURDLE_FRACTION = 0.70
rr_SEEDS = (20260805,20260806,20260807)
raf_Q = 0.95
raf_HURDLES = (0.50,0.70,0.90)
raf_TOL = 1e-8
ar_TARGET = 30000.0
ar_Q = 0.95
ar_TOL = 1e-8
mav_TARGET = 30000.0
mav_Q = 0.95
mav_TOL = 1e-8
mav_HURDLE = 0.70
mav_WIND_SHARE = 0.50
hfv_TARGET = 30000.0
hfv_Q = 0.95
hfv_TOL = 1e-8
hfv_HURDLE = 0.70
liquidity_Q = 0.95
liquidity_TOL = 1e-8
rce_Q = 0.95
rce_TOL = 1e-8
fsc_Q = 0.95
fsc_TOL = 1e-8


# phase_model.py: selected original mathematical routines.
@dataclass
class pm_BlockSet:
    b: np.ndarray
    w: np.ndarray
    s: np.ndarray
    source_days: np.ndarray
    target_days: int

def pm_complete_month_panel(df: pd.DataFrame) -> pd.DataFrame:
    x = df.copy()
    x['year'] = x['date'].dt.year
    x['month'] = x['date'].dt.month
    counts = x.groupby(['year', 'month'])['date'].nunique()
    accepted = {(int(y), int(m)) for (y, m), c in counts.items() if int(c) >= calendar.monthrange(int(y), int(m))[1] - 1}
    keep = [(int(y), int(m)) in accepted for y, m in zip(x['year'], x['month'])]
    return x[keep].sort_values('date').reset_index(drop=True)

def pm_build_blocks(panel: pd.DataFrame, block_days: int=14) -> Dict[int, pm_BlockSet]:
    out: Dict[int, pm_BlockSet] = {}
    for month in range(1, 13):
        sub = panel[panel['month'] == month].sort_values(['year', 'date'])
        ba = []
        wa = []
        sa = []
        da = []
        for _, g in sub.groupby('year'):
            b = g['bess_cash_gbp'].to_numpy(float)
            w = g['wind_gross'].to_numpy(float)
            s = g['solar_gross'].to_numpy(float)
            n = len(g)
            if n < 7:
                continue
            ix = (np.arange(n)[:, None] + np.arange(block_days)[None, :]) % n
            ba.append(b[ix])
            wa.append(w[ix])
            sa.append(s[ix])
            da.append(np.full(n, n, dtype=float))
        if not ba:
            raise RuntimeError(f'No blocks for month {month}')
        out[month] = pm_BlockSet(np.concatenate(ba), np.concatenate(wa), np.concatenate(sa), np.concatenate(da), pm_MONTH_DAYS[month])
    return out

def pm_historical_hurdle(panel: pd.DataFrame, fraction: float=pm_CFG.hurdle_fraction) -> Tuple[np.ndarray, np.ndarray]:
    mt = panel.groupby(['year', 'month'])[['wind_gross', 'solar_gross']].sum()
    clim = mt.groupby('month').mean().reindex(range(1, 13))
    return (fraction * clim['wind_gross'].to_numpy(float), fraction * clim['solar_gross'].to_numpy(float))


# run_retained_reserve_analysis.py: selected original mathematical routines.
@dataclass
class rr_AnnualScenarioSet:
    bess: np.ndarray
    wind_signed: np.ndarray
    solar_signed: np.ndarray
    wind_surplus: np.ndarray
    solar_surplus: np.ndarray

def rr_draw_both_rights(panel: pd.DataFrame, n: int, seed: int, chunk: int=25000) -> rr_AnnualScenarioSet:
    """Draw aligned annual BESS/wind/solar scenarios and both contractual rights.

    The daily observations within each 14-day block remain aligned. Blocks are
    sampled only within the same calendar month, preserving seasonality and
    persistent weather/price episodes. Monthly hurdles are fixed from historical
    calendar-month means and prorated to daily amounts before the signed or
    positive-part transformation.
    """
    blocks = pm_build_blocks(panel)
    hurdle_w, hurdle_s = pm_historical_hurdle(panel, rr_HURDLE_FRACTION)
    rng = np.random.default_rng(seed)
    B = np.zeros(n, dtype=float)
    Ws = np.zeros(n, dtype=float)
    Ss = np.zeros(n, dtype=float)
    Wp = np.zeros(n, dtype=float)
    Sp = np.zeros(n, dtype=float)
    for month in range(1, 13):
        z = blocks[month]
        n_blocks = math.ceil(z.target_days / z.b.shape[1])
        for lo in range(0, n, chunk):
            hi = min(n, lo + chunk)
            rows = hi - lo
            choices = rng.integers(0, len(z.b), size=(rows, n_blocks))
            bdays = z.b[choices].reshape(rows, -1)[:, :z.target_days]
            wdays = z.w[choices].reshape(rows, -1)[:, :z.target_days]
            sdays = z.s[choices].reshape(rows, -1)[:, :z.target_days]
            source_days = np.repeat(z.source_days[choices], z.b.shape[1], axis=1)[:, :z.target_days]
            wr = wdays - hurdle_w[month - 1] / source_days
            sr = sdays - hurdle_s[month - 1] / source_days
            B[lo:hi] += bdays.sum(axis=1)
            Ws[lo:hi] += wr.sum(axis=1)
            Ss[lo:hi] += sr.sum(axis=1)
            Wp[lo:hi] += np.maximum(wr, 0.0).sum(axis=1)
            Sp[lo:hi] += np.maximum(sr, 0.0).sum(axis=1)

    def equalise(w: np.ndarray, s: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        target = 0.5 * (float(w.mean()) + float(s.mean()))
        return (rr_RENEWABLE_REFERENCE_MW * target / float(w.mean()) * w, rr_RENEWABLE_REFERENCE_MW * target / float(s.mean()) * s)
    Ws, Ss = equalise(Ws, Ss)
    Wp, Sp = equalise(Wp, Sp)
    return rr_AnnualScenarioSet(B, Ws, Ss, Wp, Sp)

def rr_reshape_paths(x: np.ndarray, n_paths: int) -> np.ndarray:
    expected = n_paths * rr_TENOR_YEARS
    if len(x) != expected:
        raise ValueError(f'Expected {expected} annual scenarios; received {len(x)}')
    return np.asarray(x, dtype=float).reshape(n_paths, rr_TENOR_YEARS)

def rr_solve_path_floor(bess: np.ndarray, renewable: np.ndarray, solvency_level: float, *, provider_upside_share: float=rr_PROVIDER_UPSIDE_SHARE, required_margin_fraction: float=rr_REQUIRED_MARGIN_FRACTION) -> dict:
    """Maximum annual guarantee satisfying path solvency and expected margin."""
    bess = np.asarray(bess, dtype=float)
    renewable = np.asarray(renewable, dtype=float)
    mean_bess = float(bess.mean())
    required_margin = required_margin_fraction * mean_bess

    def diagnostics(guarantee: float):
        cash = renewable + provider_upside_share * np.maximum(bess - guarantee, 0.0) - np.maximum(guarantee - bess, 0.0)
        cumulative = np.cumsum(cash, axis=1)
        minimum = cumulative.min(axis=1)
        solvent = minimum >= -1e-08
        solvency = float(solvent.mean())
        mean_profit = float(cash.mean())
        feasible = solvency >= solvency_level - 1e-12 and mean_profit >= required_margin - 1e-07
        return (feasible, solvency, mean_profit, cash, cumulative)
    lo = 0.0
    hi = max(1.0, 1.5 * float(bess.mean() + max(renewable.mean(), 0.0)))
    while diagnostics(hi)[0]:
        hi *= 1.5
    for _ in range(42):
        mid = 0.5 * (lo + hi)
        if diagnostics(mid)[0]:
            lo = mid
        else:
            hi = mid
    _, solvency, mean_profit, cash, cumulative = diagnostics(lo)
    max_deficit = np.maximum(-cumulative.min(axis=1), 0.0)
    return {'floor_gbp_per_bess_mw_year': float(lo / rr_P_BESS_MW), 'guarantee_gbp_year': float(lo), 'solvency_fraction': solvency, 'mean_provider_profit_gbp_per_bess_mw_year': mean_profit / rr_P_BESS_MW, 'first_year_deficit_fraction': float((cash[:, 0] < 0.0).mean()), 'p95_maximum_cumulative_deficit_gbp_per_bess_mw': float(np.quantile(max_deficit, 0.95) / rr_P_BESS_MW), 'p99_maximum_cumulative_deficit_gbp_per_bess_mw': float(np.quantile(max_deficit, 0.99) / rr_P_BESS_MW), 'mean_terminal_reserve_gbp_per_bess_mw': float(cumulative[:, -1].mean() / rr_P_BESS_MW), 'median_terminal_reserve_gbp_per_bess_mw': float(np.median(cumulative[:, -1]) / rr_P_BESS_MW), 'mean_bess_revenue_gbp_per_bess_mw_year': mean_bess / rr_P_BESS_MW, 'mean_admitted_renewable_cash_gbp_per_bess_mw_year': float(renewable.mean() / rr_P_BESS_MW), 'required_margin_gbp_per_bess_mw_year': required_margin / rr_P_BESS_MW}

def rr_right_arrays(scen: rr_AnnualScenarioSet, right: str) -> Tuple[np.ndarray, np.ndarray]:
    if right == 'signed':
        return (scen.wind_signed, scen.solar_signed)
    if right == 'surplus_only':
        return (scen.wind_surplus, scen.solar_surplus)
    raise ValueError(right)

def rr_path_arrays(scen: rr_AnnualScenarioSet, n_paths: int, right: str, wind_weight: float, access_share: float=rr_ACCESS_REFERENCE, renewable_scale_multiplier: float=1.0) -> Tuple[np.ndarray, np.ndarray]:
    W, S = rr_right_arrays(scen, right)
    B = rr_reshape_paths(scen.bess, n_paths)
    R = rr_reshape_paths(access_share * renewable_scale_multiplier * (wind_weight * W + (1.0 - wind_weight) * S), n_paths)
    return (B, R)


# run_access_frontier.py: selected original mathematical routines.
@dataclass
class raf_HurdleScenarioSet:
    bess: np.ndarray
    daily: dict[float, tuple[np.ndarray, np.ndarray]]
    monthly: dict[float, tuple[np.ndarray, np.ndarray]]

def raf__equalise_pair(wind: np.ndarray, solar: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Scale technologies to the paper's 25 MW-equivalent equal-mean cash basis."""
    target = 0.5 * (float(wind.mean()) + float(solar.mean()))
    return (rr_RENEWABLE_REFERENCE_MW * target / float(wind.mean()) * wind, rr_RENEWABLE_REFERENCE_MW * target / float(solar.mean()) * solar)

def raf_draw_common_hurdle_scenarios(panel: pd.DataFrame, n: int, seed: int, *, hurdles: tuple[float, ...]=raf_HURDLES, chunk: int=25000) -> raf_HurdleScenarioSet:
    """Draw common BESS/wind/solar annual scenarios for all hurdle definitions."""
    blocks = pm_build_blocks(panel)
    hurdle_values = {h: pm_historical_hurdle(panel, h) for h in hurdles}
    rng = np.random.default_rng(seed)
    bess = np.zeros(n, dtype=float)
    daily = {h: (np.zeros(n, dtype=float), np.zeros(n, dtype=float)) for h in hurdles}
    monthly = {h: (np.zeros(n, dtype=float), np.zeros(n, dtype=float)) for h in hurdles}
    for month in range(1, 13):
        z = blocks[month]
        n_blocks = math.ceil(z.target_days / z.b.shape[1])
        for lo in range(0, n, chunk):
            hi = min(n, lo + chunk)
            rows = hi - lo
            choices = rng.integers(0, len(z.b), size=(rows, n_blocks))
            bdays = z.b[choices].reshape(rows, -1)[:, :z.target_days]
            wdays = z.w[choices].reshape(rows, -1)[:, :z.target_days]
            sdays = z.s[choices].reshape(rows, -1)[:, :z.target_days]
            source_days = np.repeat(z.source_days[choices], z.b.shape[1], axis=1)[:, :z.target_days]
            bess[lo:hi] += bdays.sum(axis=1)
            w_month = wdays.sum(axis=1)
            s_month = sdays.sum(axis=1)
            for h in hurdles:
                hurdle_w, hurdle_s = hurdle_values[h]
                wr = wdays - hurdle_w[month - 1] / source_days
                sr = sdays - hurdle_s[month - 1] / source_days
                wd, sd = daily[h]
                wm, sm = monthly[h]
                wd[lo:hi] += np.maximum(wr, 0.0).sum(axis=1)
                sd[lo:hi] += np.maximum(sr, 0.0).sum(axis=1)
                wm[lo:hi] += np.maximum(w_month - hurdle_w[month - 1], 0.0)
                sm[lo:hi] += np.maximum(s_month - hurdle_s[month - 1], 0.0)
    for h in hurdles:
        daily[h] = raf__equalise_pair(*daily[h])
        monthly[h] = raf__equalise_pair(*monthly[h])
    return raf_HurdleScenarioSet(bess=bess, daily=daily, monthly=monthly)

def raf__evaluate_floor(bess: np.ndarray, renewable: np.ndarray, guarantee: float, *, q: float=raf_Q) -> tuple[bool, float, float]:
    cash = renewable + rr_PROVIDER_UPSIDE_SHARE * np.maximum(bess - guarantee, 0.0) - np.maximum(guarantee - bess, 0.0)
    minimum = np.cumsum(cash, axis=1).min(axis=1)
    solvency = float((minimum >= -raf_TOL).mean())
    mean_cash = float(cash.mean())
    required_margin = rr_REQUIRED_MARGIN_FRACTION * float(bess.mean())
    feasible = solvency >= q - 1e-12 and mean_cash >= required_margin - 1e-07
    return (feasible, solvency, mean_cash)

def raf_solve_floor_fast(bess: np.ndarray, renewable: np.ndarray, *, q: float=raf_Q, lo_hint: float=0.0, iterations: int=22) -> dict:
    """Solve the zero-opening-reserve unlimited-retention floor."""
    lo = max(0.0, float(lo_hint))
    hi = max(lo + 1.0, 1.5 * float(bess.mean() + max(renewable.mean(), 0.0)))
    while raf__evaluate_floor(bess, renewable, hi, q=q)[0]:
        hi *= 1.5
    for _ in range(iterations):
        mid = 0.5 * (lo + hi)
        if raf__evaluate_floor(bess, renewable, mid, q=q)[0]:
            lo = mid
        else:
            hi = mid
    _, solvency, mean_cash = raf__evaluate_floor(bess, renewable, lo, q=q)
    required_margin = rr_REQUIRED_MARGIN_FRACTION * float(bess.mean())
    solvency_slack = solvency - q
    margin_slack = (mean_cash - required_margin) / rr_P_BESS_MW
    one_path = 1.0 / len(bess)
    binding = 'expected margin' if abs(margin_slack) < 0.25 and solvency_slack > 2.0 * one_path else 'path solvency'
    return {'floor_gbp_per_bess_mw_year': lo / rr_P_BESS_MW, 'solvency_fraction': solvency, 'mean_provider_cash_gbp_per_bess_mw_year': mean_cash / rr_P_BESS_MW, 'required_margin_gbp_per_bess_mw_year': required_margin / rr_P_BESS_MW, 'binding_constraint': binding}

def raf_alpha_min_for_target(bess: np.ndarray, residual_100: np.ndarray, target_floor_gbp_per_mw_year: float, *, q: float=raf_Q, iterations: int=22) -> dict:
    guarantee = target_floor_gbp_per_mw_year * rr_P_BESS_MW

    def feasible(alpha: float) -> tuple[bool, float, float]:
        return raf__evaluate_floor(bess, alpha * residual_100, guarantee, q=q)
    feasible_full, solvency_full, mean_cash_full = feasible(1.0)
    if not feasible_full:
        return {'reached': False, 'alpha_min': np.nan, 'solvency_fraction': solvency_full, 'mean_provider_cash_gbp_per_bess_mw_year': mean_cash_full / rr_P_BESS_MW}
    lo, hi = (0.0, 1.0)
    for _ in range(iterations):
        mid = 0.5 * (lo + hi)
        if feasible(mid)[0]:
            hi = mid
        else:
            lo = mid
    _, solvency, mean_cash = feasible(hi)
    return {'reached': True, 'alpha_min': hi, 'solvency_fraction': solvency, 'mean_provider_cash_gbp_per_bess_mw_year': mean_cash / rr_P_BESS_MW}


# run_access_reserve_tradeoff.py: selected original mathematical routines.
def ar_metrics(bess: np.ndarray, residual: np.ndarray, alpha: float, opening_reserve_per_mw: float) -> tuple[bool, float, float]:
    guarantee = ar_TARGET * rr_P_BESS_MW
    cash = alpha * residual + rr_PROVIDER_UPSIDE_SHARE * np.maximum(bess - guarantee, 0.0) - np.maximum(guarantee - bess, 0.0)
    opening = opening_reserve_per_mw * rr_P_BESS_MW
    solvent = (opening + np.cumsum(cash, axis=1)).min(axis=1) >= -ar_TOL
    solvency = float(solvent.mean())
    mean_cash = float(cash.mean())
    required_margin = rr_REQUIRED_MARGIN_FRACTION * float(bess.mean())
    return (bool(solvency >= ar_Q - 1e-12 and mean_cash >= required_margin - 1e-07), solvency, mean_cash)

def ar_solve_alpha(bess: np.ndarray, residual: np.ndarray, opening_reserve_per_mw: float, iterations: int=25) -> dict:
    ok, solvency, mean_cash = ar_metrics(bess, residual, 1.0, opening_reserve_per_mw)
    if not ok:
        return {'reached': False, 'alpha_min': np.nan, 'solvency_fraction': solvency, 'mean_provider_cash_gbp_per_bess_mw_year': mean_cash / rr_P_BESS_MW}
    lo, hi = (0.0, 1.0)
    for _ in range(iterations):
        mid = 0.5 * (lo + hi)
        if ar_metrics(bess, residual, mid, opening_reserve_per_mw)[0]:
            hi = mid
        else:
            lo = mid
    _, solvency, mean_cash = ar_metrics(bess, residual, hi, opening_reserve_per_mw)
    return {'reached': True, 'alpha_min': hi, 'solvency_fraction': solvency, 'mean_provider_cash_gbp_per_bess_mw_year': mean_cash / rr_P_BESS_MW}


# run_methodological_extensions.py: selected original mathematical routines.
rme_Z = 1.6448536269514722

def rme_wilson_lower(successes: int, n: int, z: float=rme_Z) -> float:
    p = successes / n
    z2 = z * z
    return (p + z2 / (2 * n) - z * math.sqrt(p * (1 - p) / n + z2 / (4 * n * n))) / (1 + z2 / n)

def rme_bootstrap_panel(panel, rng):
    pieces = []
    targets = list(panel.groupby(['year', 'month'], sort=True).groups.keys())
    bym = {}
    for y, m in targets:
        bym.setdefault(int(m), []).append((int(y), int(m)))
    for ty, m in targets:
        sy, sm = bym[int(m)][int(rng.integers(0, len(bym[int(m)])))]
        g = panel[(panel.year == sy) & (panel.month == sm)].copy().sort_values('date').reset_index(drop=True)
        g['year'] = int(ty)
        g['month'] = int(m)
        base = pd.Timestamp(2100 + (int(ty) - 2020), int(m), 1)
        g['date'] = base + pd.to_timedelta(np.arange(len(g)), unit='D')
        pieces.append(g)
    return pd.concat(pieces, ignore_index=True)


# run_minimum_access_validation.py: selected original mathematical routines.
@dataclass(frozen=True)
class mav_FrozenResidualConfig:
    hurdle_w: np.ndarray
    hurdle_s: np.ndarray
    daily_scale_w: float
    daily_scale_s: float
    monthly_scale_w: float
    monthly_scale_s: float

def mav__pair_scale(wind: np.ndarray, solar: np.ndarray) -> tuple[float, float]:
    target = 0.5 * (float(wind.mean()) + float(solar.mean()))
    return (rr_RENEWABLE_REFERENCE_MW * target / float(wind.mean()), rr_RENEWABLE_REFERENCE_MW * target / float(solar.mean()))

def mav_draw_residual_scenarios(panel: pd.DataFrame, n: int, seed: int, *, frozen: mav_FrozenResidualConfig | None=None, chunk: int=25000) -> tuple[np.ndarray, dict[str, np.ndarray], mav_FrozenResidualConfig]:
    blocks = pm_build_blocks(panel)
    if frozen is None:
        hurdle_w, hurdle_s = pm_historical_hurdle(panel, mav_HURDLE)
    else:
        hurdle_w, hurdle_s = (frozen.hurdle_w, frozen.hurdle_s)
    rng = np.random.default_rng(seed)
    bess = np.zeros(n, dtype=float)
    daily_w = np.zeros(n, dtype=float)
    daily_s = np.zeros(n, dtype=float)
    monthly_w = np.zeros(n, dtype=float)
    monthly_s = np.zeros(n, dtype=float)
    for month in range(1, 13):
        z = blocks[month]
        n_blocks = math.ceil(z.target_days / z.b.shape[1])
        for lo in range(0, n, chunk):
            hi = min(n, lo + chunk)
            rows = hi - lo
            choices = rng.integers(0, len(z.b), size=(rows, n_blocks))
            bdays = z.b[choices].reshape(rows, -1)[:, :z.target_days]
            wdays = z.w[choices].reshape(rows, -1)[:, :z.target_days]
            sdays = z.s[choices].reshape(rows, -1)[:, :z.target_days]
            source_days = np.repeat(z.source_days[choices], z.b.shape[1], axis=1)[:, :z.target_days]
            bess[lo:hi] += bdays.sum(axis=1)
            wr = wdays - hurdle_w[month - 1] / source_days
            sr = sdays - hurdle_s[month - 1] / source_days
            daily_w[lo:hi] += np.maximum(wr, 0.0).sum(axis=1)
            daily_s[lo:hi] += np.maximum(sr, 0.0).sum(axis=1)
            monthly_w[lo:hi] += np.maximum(wdays.sum(axis=1) - hurdle_w[month - 1], 0.0)
            monthly_s[lo:hi] += np.maximum(sdays.sum(axis=1) - hurdle_s[month - 1], 0.0)
    if frozen is None:
        dsw, dss = mav__pair_scale(daily_w, daily_s)
        msw, mss = mav__pair_scale(monthly_w, monthly_s)
        frozen = mav_FrozenResidualConfig(hurdle_w=np.asarray(hurdle_w, dtype=float), hurdle_s=np.asarray(hurdle_s, dtype=float), daily_scale_w=dsw, daily_scale_s=dss, monthly_scale_w=msw, monthly_scale_s=mss)
    daily = frozen.daily_scale_w * daily_w * mav_WIND_SHARE + frozen.daily_scale_s * daily_s * (1.0 - mav_WIND_SHARE)
    monthly = frozen.monthly_scale_w * monthly_w * mav_WIND_SHARE + frozen.monthly_scale_s * monthly_s * (1.0 - mav_WIND_SHARE)
    return (bess, {'daily_non_carrying': daily, 'monthly_netted': monthly}, frozen)

def mav_reserve_metrics(bess: np.ndarray, residual: np.ndarray, alpha: float) -> dict[str, float | bool]:
    guarantee = mav_TARGET * rr_P_BESS_MW
    cash = alpha * residual + rr_PROVIDER_UPSIDE_SHARE * np.maximum(bess - guarantee, 0.0) - np.maximum(guarantee - bess, 0.0)
    solvent = np.cumsum(cash, axis=1).min(axis=1) >= -mav_TOL
    successes = int(solvent.sum())
    n = len(solvent)
    solvency = successes / n
    wilson = rme_wilson_lower(successes, n)
    mean_cash = float(cash.mean())
    required_margin = rr_REQUIRED_MARGIN_FRACTION * float(bess.mean())
    return {'solvency': solvency, 'wilson_lower': wilson, 'margin_pass': bool(mean_cash >= required_margin - 1e-07), 'mean_provider_cash_gbp_per_bess_mw_year': mean_cash / rr_P_BESS_MW}

def mav_solve_alpha(bess: np.ndarray, residual: np.ndarray, *, wilson_rule: bool) -> tuple[float, dict]:

    def feasible(a: float) -> tuple[bool, dict]:
        m = mav_reserve_metrics(bess, residual, a)
        solvency_ok = m['wilson_lower'] >= mav_Q - 1e-12 if wilson_rule else m['solvency'] >= mav_Q - 1e-12
        return (bool(solvency_ok and m['margin_pass']), m)
    ok, metrics = feasible(1.0)
    if not ok:
        return (float('nan'), metrics)
    lo, hi = (0.0, 1.0)
    for _ in range(25):
        mid = 0.5 * (lo + hi)
        if feasible(mid)[0]:
            hi = mid
        else:
            lo = mid
    return (hi, feasible(hi)[1])


# run_heldout_fixed_access_validation.py: selected original mathematical routines.
def hfv_build_master_frozen_config(panel: pd.DataFrame, n_paths: int=20000) -> mav_FrozenResidualConfig:
    """Freeze full-sample hurdles and the canonical three-seed scale mapping."""
    hurdle_w, hurdle_s = pm_historical_hurdle(panel, hfv_HURDLE)
    configs: list[mav_FrozenResidualConfig] = []
    for seed in rr_SEEDS:
        _, _, cfg = mav_draw_residual_scenarios(panel, n_paths * rr_TENOR_YEARS, seed)
        configs.append(cfg)
    return mav_FrozenResidualConfig(hurdle_w=np.asarray(hurdle_w, dtype=float), hurdle_s=np.asarray(hurdle_s, dtype=float), daily_scale_w=float(np.mean([c.daily_scale_w for c in configs])), daily_scale_s=float(np.mean([c.daily_scale_s for c in configs])), monthly_scale_w=float(np.mean([c.monthly_scale_w for c in configs])), monthly_scale_s=float(np.mean([c.monthly_scale_s for c in configs])))

def hfv_target_metrics(bess: np.ndarray, residual: np.ndarray, alpha: float) -> dict[str, float | bool]:
    guarantee = hfv_TARGET * rr_P_BESS_MW
    cash = alpha * residual + rr_PROVIDER_UPSIDE_SHARE * np.maximum(bess - guarantee, 0.0) - np.maximum(guarantee - bess, 0.0)
    cumulative = np.cumsum(cash, axis=1)
    solvent = cumulative.min(axis=1) >= -hfv_TOL
    successes = int(solvent.sum())
    n = len(solvent)
    solvency = successes / n
    wilson = rme_wilson_lower(successes, n)
    mean_cash = float(cash.mean())
    required_margin = rr_REQUIRED_MARGIN_FRACTION * float(bess.mean())
    margin_pass = bool(mean_cash >= required_margin - 1e-07)
    return {'solvency': solvency, 'wilson_lower': wilson, 'margin_pass': margin_pass, 'empirical_target_attained': bool(solvency >= hfv_Q - 1e-12 and margin_pass), 'wilson_target_attained': bool(wilson >= hfv_Q - 1e-12 and margin_pass), 'mean_provider_cash_gbp_per_bess_mw_year': mean_cash / rr_P_BESS_MW}


# run_one_year_liquidity_horizons.py: selected original mathematical routines.
def liquidity_provider_cash(bess: np.ndarray, renewable: np.ndarray, guarantee: float) -> np.ndarray:
    """Annual provider cash before reserve/bridge financing."""
    return renewable + rr_PROVIDER_UPSIDE_SHARE * np.maximum(bess - guarantee, 0.0) - np.maximum(guarantee - bess, 0.0)

def liquidity_unlimited_reserve_diagnostics(cash: np.ndarray) -> dict:
    cumulative = np.cumsum(np.asarray(cash, float), axis=1)
    minimum = cumulative.min(axis=1)
    solvent = minimum >= -liquidity_TOL
    n, T = cumulative.shape
    return {'solvent': solvent, 'reserve': cumulative, 'distribution': np.zeros((n, T)), 'bridge_draw': np.zeros((n, T)), 'max_bridge': np.zeros(n), 'bridge_used': np.zeros(n, dtype=bool), 'duration_breach': ~solvent}

def liquidity_one_year_reserve_diagnostics(cash: np.ndarray) -> dict:
    """Only the immediately preceding year's positive cash remains available."""
    cash = np.asarray(cash, float)
    n, T = cash.shape
    reserve = np.zeros(n)
    solvent = np.ones(n, dtype=bool)
    reserve_hist = np.zeros((n, T))
    distribution = np.zeros((n, T))
    for t in range(T):
        c = cash[:, t]
        shortfall = np.maximum(-c, 0.0)
        uncovered = np.maximum(shortfall - reserve, 0.0)
        solvent &= uncovered <= liquidity_TOL
        distribution[:, t] = np.maximum(reserve - shortfall, 0.0)
        reserve = np.maximum(c, 0.0)
        reserve_hist[:, t] = reserve
    n, T = cash.shape
    return {'solvent': solvent, 'reserve': reserve_hist, 'distribution': distribution, 'bridge_draw': np.zeros((n, T)), 'max_bridge': np.zeros(n), 'bridge_used': np.zeros(n, dtype=bool), 'duration_breach': ~solvent}

def liquidity_one_year_bridge_diagnostics(cash: np.ndarray) -> dict:
    """One-year reserve plus bridge draws due at the next annual settlement.

    At settlement t, prior-year reserve and current positive provider cash first
    repay the bridge drawn at t-1. Failure to repay is a tenor breach; the path is
    not refinanced. Remaining prior-year reserve then covers the current shortfall.
    Any residual shortfall is a new bridge draw due at t+1. Only unused current-year
    positive cash is carried as the next reserve vintage. No bridge may remain at
    contract maturity in the main conservative specification.
    """
    cash = np.asarray(cash, float)
    n, T = cash.shape
    reserve = np.zeros(n)
    debt = np.zeros(n)
    active = np.ones(n, dtype=bool)
    solvent = np.ones(n, dtype=bool)
    duration_breach = np.zeros(n, dtype=bool)
    bridge_draw = np.zeros((n, T))
    max_bridge = np.zeros(n)
    reserve_hist = np.zeros((n, T))
    distribution = np.zeros((n, T))
    for t in range(T):
        c = cash[:, t]
        current_positive = np.maximum(c, 0.0)
        current_shortfall = np.maximum(-c, 0.0)
        old_reserve = reserve.copy()
        repay_old = np.minimum(old_reserve, debt)
        old_reserve -= repay_old
        debt -= repay_old
        repay_current = np.minimum(current_positive, debt)
        current_positive -= repay_current
        debt -= repay_current
        late = active & (debt > liquidity_TOL)
        solvent[late] = False
        duration_breach[late] = True
        active[late] = False
        cover = np.where(active, np.minimum(old_reserve, current_shortfall), 0.0)
        old_reserve -= cover
        current_shortfall -= cover
        new_draw = np.where(active, current_shortfall, 0.0)
        bridge_draw[:, t] = new_draw
        debt = np.where(active, new_draw, debt)
        max_bridge = np.maximum(max_bridge, np.where(active, debt, 0.0))
        distribution[:, t] = np.where(active, old_reserve, 0.0)
        reserve = np.where(active, current_positive, 0.0)
        reserve_hist[:, t] = reserve
    final_outstanding = active & (debt > liquidity_TOL)
    solvent[final_outstanding] = False
    duration_breach[final_outstanding] = True
    return {'solvent': solvent, 'reserve': reserve_hist, 'distribution': distribution, 'bridge_draw': bridge_draw, 'max_bridge': max_bridge, 'bridge_used': max_bridge > liquidity_TOL, 'duration_breach': duration_breach}

def liquidity_policy_diagnostics(cash: np.ndarray, policy: str) -> dict:
    if policy == 'unlimited_reserve':
        return liquidity_unlimited_reserve_diagnostics(cash)
    if policy == 'one_year_reserve':
        return liquidity_one_year_reserve_diagnostics(cash)
    if policy == 'one_year_reserve_bridge':
        return liquidity_one_year_bridge_diagnostics(cash)
    raise ValueError(f'Unknown policy: {policy}')

def liquidity_solve_floor(bess: np.ndarray, renewable: np.ndarray, policy: str, q: float=0.95) -> dict:
    bess = np.asarray(bess, float)
    renewable = np.asarray(renewable, float)
    required_margin = rr_REQUIRED_MARGIN_FRACTION * float(bess.mean())

    def evaluate(guarantee: float):
        cash = liquidity_provider_cash(bess, renewable, guarantee)
        diag = liquidity_policy_diagnostics(cash, policy)
        solvency = float(diag['solvent'].mean())
        mean_cash = float(cash.mean())
        feasible = solvency >= q - 1e-12 and mean_cash >= required_margin - 1e-07
        return (feasible, cash, diag, solvency, mean_cash)
    lo = 0.0
    hi = max(1.0, 1.5 * float(bess.mean() + max(renewable.mean(), 0.0)))
    while evaluate(hi)[0]:
        hi *= 1.5
    for _ in range(44):
        mid = 0.5 * (lo + hi)
        if evaluate(mid)[0]:
            lo = mid
        else:
            hi = mid
    _, cash, diag, solvency, mean_cash = evaluate(lo)
    max_bridge = diag['max_bridge'] / rr_P_BESS_MW
    return {'floor_gbp_per_bess_mw_year': lo / rr_P_BESS_MW, 'solvency_fraction': solvency, 'mean_provider_cash_gbp_per_bess_mw_year': mean_cash / rr_P_BESS_MW, 'mean_terminal_reserve_gbp_per_bess_mw': float(diag['reserve'][:, -1].mean() / rr_P_BESS_MW), 'p95_max_bridge_gbp_per_bess_mw': float(np.quantile(max_bridge, 0.95)), 'p99_max_bridge_gbp_per_bess_mw': float(np.quantile(max_bridge, 0.99)), 'bridge_use_fraction': float(diag['bridge_used'].mean()), 'duration_breach_fraction': float(diag['duration_breach'].mean()), 'mean_annual_distribution_gbp_per_bess_mw': float(diag['distribution'].mean() / rr_P_BESS_MW), 'first_year_negative_cash_fraction': float((cash[:, 0] < 0.0).mean())}


# run_contract_robustness_extensions.py: selected original mathematical routines.
@dataclass
class rce_SettlementScenarioSet:
    bess: np.ndarray
    wind_daily_surplus: np.ndarray
    solar_daily_surplus: np.ndarray
    wind_monthly_surplus: np.ndarray
    solar_monthly_surplus: np.ndarray

def rce__equalise_pair(wind: np.ndarray, solar: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Scale wind and solar to equal expected cash at the 25 MW reference scale."""
    target = 0.5 * (float(wind.mean()) + float(solar.mean()))
    return (rr_RENEWABLE_REFERENCE_MW * target / float(wind.mean()) * wind, rr_RENEWABLE_REFERENCE_MW * target / float(solar.mean()) * solar)

def rce_draw_surplus_settlement_scenarios(panel: pd.DataFrame, n: int, seed: int, *, chunk: int=25000) -> rce_SettlementScenarioSet:
    """Draw common annual scenarios under daily and monthly positive-part rules.

    The BESS, wind and solar blocks are identical across both contract definitions.
    The daily rule applies the positive part after prorating the monthly protected
    hurdle to each source day. The monthly rule first aggregates gross monthly cash
    and then applies the positive part to the monthly residual.
    """
    blocks = pm_build_blocks(panel)
    hurdle_w, hurdle_s = pm_historical_hurdle(panel, rr_HURDLE_FRACTION)
    rng = np.random.default_rng(seed)
    B = np.zeros(n, dtype=float)
    Wd = np.zeros(n, dtype=float)
    Sd = np.zeros(n, dtype=float)
    Wm = np.zeros(n, dtype=float)
    Sm = np.zeros(n, dtype=float)
    for month in range(1, 13):
        z = blocks[month]
        n_blocks = math.ceil(z.target_days / z.b.shape[1])
        for lo in range(0, n, chunk):
            hi = min(n, lo + chunk)
            rows = hi - lo
            choices = rng.integers(0, len(z.b), size=(rows, n_blocks))
            bdays = z.b[choices].reshape(rows, -1)[:, :z.target_days]
            wdays = z.w[choices].reshape(rows, -1)[:, :z.target_days]
            sdays = z.s[choices].reshape(rows, -1)[:, :z.target_days]
            source_days = np.repeat(z.source_days[choices], z.b.shape[1], axis=1)[:, :z.target_days]
            wind_daily_residual = wdays - hurdle_w[month - 1] / source_days
            solar_daily_residual = sdays - hurdle_s[month - 1] / source_days
            B[lo:hi] += bdays.sum(axis=1)
            Wd[lo:hi] += np.maximum(wind_daily_residual, 0.0).sum(axis=1)
            Sd[lo:hi] += np.maximum(solar_daily_residual, 0.0).sum(axis=1)
            Wm[lo:hi] += np.maximum(wdays.sum(axis=1) - hurdle_w[month - 1], 0.0)
            Sm[lo:hi] += np.maximum(sdays.sum(axis=1) - hurdle_s[month - 1], 0.0)
    Wd, Sd = rce__equalise_pair(Wd, Sd)
    Wm, Sm = rce__equalise_pair(Wm, Sm)
    return rce_SettlementScenarioSet(B, Wd, Sd, Wm, Sm)

def rce__path_pair(scen: rce_SettlementScenarioSet, n_paths: int, settlement: str, *, access_share: float=rr_ACCESS_REFERENCE, wind_weight: float=0.5, multiplier: float=1.0) -> tuple[np.ndarray, np.ndarray]:
    B = np.asarray(scen.bess, float).reshape(n_paths, rr_TENOR_YEARS)
    if settlement == 'daily':
        W, S = (scen.wind_daily_surplus, scen.solar_daily_surplus)
    elif settlement == 'monthly':
        W, S = (scen.wind_monthly_surplus, scen.solar_monthly_surplus)
    else:
        raise ValueError(settlement)
    R = (access_share * multiplier * (wind_weight * W + (1.0 - wind_weight) * S)).reshape(n_paths, rr_TENOR_YEARS)
    return (B, R)

def rce_finite_vintage_diagnostics(cash: np.ndarray, retention_years: int | None) -> dict:
    """Evaluate finite reserve vintages using an oldest-first cash waterfall."""
    cash = np.asarray(cash, float)
    n, T = cash.shape
    if retention_years is None:
        cumulative = np.cumsum(cash, axis=1)
        solvent = cumulative.min(axis=1) >= -rce_TOL
        return {'solvent': solvent, 'distribution': np.zeros_like(cash), 'terminal_reserve': cumulative[:, -1]}
    k = int(retention_years)
    if k < 1:
        raise ValueError('retention_years must be positive or None')
    vintages = np.zeros((n, k), dtype=float)
    solvent = np.ones(n, dtype=bool)
    distribution = np.zeros_like(cash)
    for t in range(T):
        c = cash[:, t]
        shortfall = np.maximum(-c, 0.0)
        for j in range(k):
            use = np.minimum(vintages[:, j], shortfall)
            vintages[:, j] -= use
            shortfall -= use
        solvent &= shortfall <= rce_TOL
        distribution[:, t] = vintages[:, 0]
        if k > 1:
            vintages[:, :-1] = vintages[:, 1:]
        vintages[:, -1] = np.maximum(c, 0.0)
    return {'solvent': solvent, 'distribution': distribution, 'terminal_reserve': vintages.sum(axis=1)}

def rce_solve_scheduled_retention_floor(B: np.ndarray, R: np.ndarray, schedule: np.ndarray, retention_years: int | None, *, q: float=rce_Q, provider_upside_share: float=rr_PROVIDER_UPSIDE_SHARE, required_margin_fraction: float=rr_REQUIRED_MARGIN_FRACTION) -> dict:
    B = np.asarray(B, float)
    R = np.asarray(R, float)
    schedule = np.asarray(schedule, float)
    if B.shape != R.shape or B.shape[1] != len(schedule):
        raise ValueError('B, R and schedule dimensions do not agree')
    required_margin = required_margin_fraction * float(B.mean())

    def evaluate(full_floor: float):
        G = full_floor * schedule[None, :]
        cash = R + provider_upside_share * np.maximum(B - G, 0.0) - np.maximum(G - B, 0.0)
        diag = rce_finite_vintage_diagnostics(cash, retention_years)
        solvency = float(diag['solvent'].mean())
        mean_cash = float(cash.mean())
        feasible = solvency >= q - 1e-12 and mean_cash >= required_margin - 1e-07
        return (feasible, cash, diag, solvency, mean_cash)
    lo = 0.0
    hi = max(1.0, 1.5 * float(B.mean() + max(R.mean(), 0.0)))
    while evaluate(hi)[0]:
        hi *= 1.5
    for _ in range(44):
        mid = 0.5 * (lo + hi)
        if evaluate(mid)[0]:
            lo = mid
        else:
            hi = mid
    _, cash, diag, solvency, mean_cash = evaluate(lo)
    return {'full_floor_gbp_per_bess_mw_year': lo / rr_P_BESS_MW, 'average_scheduled_floor_gbp_per_bess_mw_year': lo * float(schedule.mean()) / rr_P_BESS_MW, 'solvency_fraction': solvency, 'mean_provider_cash_gbp_per_bess_mw_year': mean_cash / rr_P_BESS_MW, 'mean_annual_distribution_gbp_per_bess_mw': float(diag['distribution'].mean() / rr_P_BESS_MW), 'mean_terminal_reserve_gbp_per_bess_mw': float(diag['terminal_reserve'].mean() / rr_P_BESS_MW), 'first_year_negative_cash_fraction': float((cash[:, 0] < 0.0).mean())}

def rce_build_contiguous_annual_window_library(panel: pd.DataFrame, *, baseline_draws: int=100000, baseline_seed: int=20260815) -> pd.DataFrame:
    """Construct overlapping contiguous 12-calendar-month joint cash windows.

    Component means are rescaled to the month-stratified generator's annual means,
    so the stress changes annual coherence and variance rather than the expected
    cash level.
    """
    x = panel.copy().sort_values('date').reset_index(drop=True)
    hurdle_w, hurdle_s = pm_historical_hurdle(x, rr_HURDLE_FRACTION)
    counts = x.groupby(['year', 'month'])['date'].transform('count').to_numpy(float)
    month_idx = x['month'].to_numpy(int) - 1
    wind_residual = x['wind_gross'].to_numpy(float) - hurdle_w[month_idx] / counts
    solar_residual = x['solar_gross'].to_numpy(float) - hurdle_s[month_idx] / counts
    x['wind_signed_raw'] = wind_residual
    x['solar_signed_raw'] = solar_residual
    x['wind_surplus_raw'] = np.maximum(wind_residual, 0.0)
    x['solar_surplus_raw'] = np.maximum(solar_residual, 0.0)
    x['ym'] = x['date'].dt.to_period('M')
    months = sorted(x['ym'].unique())
    rows: list[dict] = []
    for i in range(len(months) - 11):
        selected = months[i:i + 12]
        g = x[x['ym'].isin(selected)]
        if len(g) < 350:
            continue
        rows.append({'window_id': len(rows), 'start_month': str(selected[0]), 'end_month': str(selected[-1]), 'days': int(len(g)), 'bess': float(g['bess_cash_gbp'].sum()), 'wind_signed': float(g['wind_signed_raw'].sum()), 'solar_signed': float(g['solar_signed_raw'].sum()), 'wind_surplus': float(g['wind_surplus_raw'].sum()), 'solar_surplus': float(g['solar_surplus_raw'].sum())})
    library = pd.DataFrame(rows)
    if len(library) < 10:
        raise RuntimeError('Too few contiguous 12-month windows')
    baseline = rr_draw_both_rights(panel, baseline_draws, baseline_seed)
    targets = {'bess': float(baseline.bess.mean()), 'wind_signed': float(baseline.wind_signed.mean()), 'solar_signed': float(baseline.solar_signed.mean()), 'wind_surplus': float(baseline.wind_surplus.mean()), 'solar_surplus': float(baseline.solar_surplus.mean())}
    for column, target in targets.items():
        raw_mean = float(library[column].mean())
        library[column] *= target / raw_mean
        library[f'{column}_scale_to_baseline_mean'] = target / raw_mean
    library['signed_accessible'] = rr_ACCESS_REFERENCE * (0.5 * library['wind_signed'] + 0.5 * library['solar_signed'])
    library['surplus_accessible'] = rr_ACCESS_REFERENCE * (0.5 * library['wind_surplus'] + 0.5 * library['solar_surplus'])
    library['bess_rank'] = library['bess'].rank(method='first', pct=True)
    return library

def rce__window_path_indices(n_paths: int, years: int, n_windows: int, seed: int, rho: float) -> np.ndarray:
    rng = np.random.default_rng(seed)
    if rho <= 0.0:
        return rng.integers(0, n_windows, size=(n_paths, years))
    z = np.empty((n_paths, years), dtype=float)
    z[:, 0] = rng.normal(size=n_paths)
    scale = math.sqrt(max(0.0, 1.0 - rho * rho))
    for t in range(1, years):
        z[:, t] = rho * z[:, t - 1] + scale * rng.normal(size=n_paths)
    u = norm.cdf(z)
    return np.minimum((u * n_windows).astype(int), n_windows - 1)

def rce__paths_from_window_library(library: pd.DataFrame, n_paths: int, years: int, seed: int, rho: float) -> tuple[np.ndarray, dict[str, np.ndarray], float]:
    ordered = library.sort_values('bess').reset_index(drop=True)
    indices = rce__window_path_indices(n_paths, years, len(ordered), seed, rho)
    B = ordered['bess'].to_numpy(float)[indices]
    rights = {'bess_only': np.zeros_like(B), 'signed': ordered['signed_accessible'].to_numpy(float)[indices], 'surplus_only': ordered['surplus_accessible'].to_numpy(float)[indices]}
    if years > 1:
        actual_corr = float(np.corrcoef(B[:, :-1].ravel(), B[:, 1:].ravel())[0, 1])
    else:
        actual_corr = float('nan')
    return (B, rights, actual_corr)


# run_focused_specification_checks.py: selected original mathematical routines.
@dataclass
class fsc_NonCircularBlockSet:
    b: np.ndarray
    w: np.ndarray
    s: np.ndarray
    source_days: np.ndarray
    target_days: int

def fsc_build_non_circular_blocks(panel: pd.DataFrame, block_days: int=14) -> Dict[int, fsc_NonCircularBlockSet]:
    """Build exact-calendar blocks with no month-end wrap and no missing-day adjacency."""
    out: Dict[int, fsc_NonCircularBlockSet] = {}
    for month in range(1, 13):
        sub = panel.loc[panel['month'] == month].sort_values(['year', 'date'])
        b_rows: list[np.ndarray] = []
        w_rows: list[np.ndarray] = []
        s_rows: list[np.ndarray] = []
        source_days: list[float] = []
        for _, group in sub.groupby('year'):
            g = group.sort_values('date').reset_index(drop=True)
            n = len(g)
            for start in range(0, n - block_days + 1):
                dates = pd.DatetimeIndex(g.loc[start:start + block_days - 1, 'date'])
                if len(dates) != block_days:
                    continue
                if not np.all(np.diff(dates.values).astype('timedelta64[D]') == np.timedelta64(1, 'D')):
                    continue
                sl = slice(start, start + block_days)
                b_rows.append(g['bess_cash_gbp'].to_numpy(float)[sl])
                w_rows.append(g['wind_gross'].to_numpy(float)[sl])
                s_rows.append(g['solar_gross'].to_numpy(float)[sl])
                source_days.append(float(n))
        if not b_rows:
            raise RuntimeError(f'No non-circular {block_days}-day blocks for month {month}')
        out[month] = fsc_NonCircularBlockSet(b=np.stack(b_rows), w=np.stack(w_rows), s=np.stack(s_rows), source_days=np.asarray(source_days, dtype=float), target_days=pm_MONTH_DAYS[month])
    return out

def fsc_draw_non_circular_surplus(blocks: Dict[int, fsc_NonCircularBlockSet], panel: pd.DataFrame, n: int, seed: int, *, wind_weight: float=0.5, access_share: float=rr_ACCESS_REFERENCE) -> tuple[np.ndarray, np.ndarray]:
    hurdle_w, hurdle_s = pm_historical_hurdle(panel, rr_HURDLE_FRACTION)
    rng = np.random.default_rng(seed)
    B = np.zeros(n, dtype=float)
    W = np.zeros(n, dtype=float)
    S = np.zeros(n, dtype=float)
    for month in range(1, 13):
        z = blocks[month]
        n_blocks = math.ceil(z.target_days / z.b.shape[1])
        choices = rng.integers(0, len(z.b), size=(n, n_blocks))
        bdays = z.b[choices].reshape(n, -1)[:, :z.target_days]
        wdays = z.w[choices].reshape(n, -1)[:, :z.target_days]
        sdays = z.s[choices].reshape(n, -1)[:, :z.target_days]
        div = np.repeat(z.source_days[choices], z.b.shape[1], axis=1)[:, :z.target_days]
        B += bdays.sum(axis=1)
        W += np.maximum(wdays - hurdle_w[month - 1] / div, 0.0).sum(axis=1)
        S += np.maximum(sdays - hurdle_s[month - 1] / div, 0.0).sum(axis=1)
    target = 0.5 * (float(W.mean()) + float(S.mean()))
    W = rr_RENEWABLE_REFERENCE_MW * target / float(W.mean()) * W
    S = rr_RENEWABLE_REFERENCE_MW * target / float(S.mean()) * S
    R = access_share * (wind_weight * W + (1.0 - wind_weight) * S)
    return (B, R)


# Signed-PPA engine, retained without changes to its mathematics.
"""Exact ten-year original cash-allocation engine. Money is GBP for 100 MW BESS.
No normality assumption; losses remain signed; same margin before/after pairing.
"""
import math
import numpy as np
from numba import njit

@njit(cache=True)
def _bounds(b,lower,prefix,ppa,k,theta):
    n,t=b.shape
    out=np.empty(n)
    for i in range(n):
        cp=0.;bound=1e300
        for j in range(t):
            cp+=ppa[i,j]
            cash=k+cp+theta*prefix[i,j]
            for z in range(j+2):
                x=(cash+(1-theta)*lower[i,j,z])/(theta*(j+1)+(1-theta)*z)
                if x<bound:bound=x
        out[i]=bound
    return out

class Engine:
    def __init__(self,b,theta=.5,margin=.05,q=.95,required_margin=None):
        self.b=np.ascontiguousarray(b,dtype=np.float64)
        if self.b.ndim!=2 or not np.isfinite(self.b).all():raise ValueError('Finite N x T BESS cash required')
        if not(0<theta<=1 and 0<q<=1 and margin>=0):raise ValueError('Invalid parameter')
        self.n,self.t=self.b.shape;self.theta=theta;self.q=q;self.mean_b=float(self.b.mean())
        self.req=float(required_margin) if required_margin is not None else margin*self.mean_b
        self.prefix=np.cumsum(self.b,axis=1)
        self.lower=np.zeros((self.n,self.t,self.t+1))
        for j in range(self.t):self.lower[:,j,1:j+2]=np.cumsum(np.sort(self.b[:,:j+1],axis=1),axis=1)
        self.bs=np.sort(self.b.ravel());self.bc=np.r_[0,np.cumsum(self.bs)]
    def margin_value(self,g,mp):
        j=np.searchsorted(self.bs,g)
        return mp+self.theta*(self.mean_b-g)+(1-self.theta)*(self.bc[j]-j*g)/len(self.bs)
    def margin_limit(self,mp):
        lo=min(0,self.bs[0])-abs(mp)-abs(self.req)-abs(self.mean_b)-1
        hi=max(0,self.bs[-1])+abs(mp)+abs(self.req)+abs(self.mean_b)+1
        while self.margin_value(lo,mp)<self.req:lo=2*lo-1
        while self.margin_value(hi,mp)>=self.req:hi=2*hi+1
        for _ in range(55):
            x=(lo+hi)/2
            if self.margin_value(x,mp)>=self.req:lo=x
            else:hi=x
        return lo
    def bounds(self,r,k=0):
        r=np.ascontiguousarray(r,dtype=np.float64)
        if r.shape!=self.b.shape or not np.isfinite(r).all() or k<0:raise ValueError('Invalid support/capital')
        return _bounds(self.b,self.lower,self.prefix,r,float(k),self.theta)
    def solve(self,r,k=0):
        r=np.asarray(r,float);mp=float(r.mean());lim=self.bounds(r,k)
        risk=float(np.partition(lim,int(math.floor((1-self.q)*self.n+1e-9)))[int(math.floor((1-self.q)*self.n+1e-9))])
        margin=self.margin_limit(mp);g=min(risk,margin)
        return {'floor':g/100,'nonnegative_feasible':g>=-1e-7,'risk_limit':risk/100,'margin_limit':margin/100,'binding':'margin' if margin<risk else 'path','mean_support':mp/100,'mean_bess':self.mean_b/100,'required_margin':self.req/100,'path_pass':float(np.mean(lim>=g-1e-7)),'net_margin':self.margin_value(g,mp)/100,'K':k/100}
    def evaluate(self,r,k,g):
        x=r+self.theta*np.maximum(self.b-g,0)-np.maximum(g-self.b,0)
        z=k+np.cumsum(x,axis=1)
        return {'path_pass':float(np.mean(z.min(axis=1)>=-1e-7)),'net_margin':float(x.mean())/100,'required_margin':self.req/100,'margin_pass':bool(x.mean()>=self.req-1e-7)}
    def reserve(self,r,g):
        x=r+self.theta*np.maximum(self.b-g,0)-np.maximum(g-self.b,0)
        d=np.maximum(-np.cumsum(x,axis=1).min(axis=1),0)
        ix=int(math.ceil(self.q*self.n-1e-9))-1
        k=float(np.partition(d,ix)[ix]);mean=float(x.mean())
        return {'required_K':k/100,'margin_feasible':mean>=self.req-1e-7,'net_margin':mean/100,'required_margin':self.req/100,'path_pass':float(np.mean(d<=k+1e-7))}

def stat(x: np.ndarray, method: str) -> float:
    x = np.asarray(x, float)
    if x.ndim != 1 or not len(x) or (not np.isfinite(x).all()):
        raise ValueError('Finite vector required')
    mass = 0.05 * len(x)
    k = int(math.floor(mass + 1e-10))
    part = np.partition(x, k)
    if method == 'coverage95':
        return float(part[k])
    if method == 'worst5':
        return float((part[:k].sum() + (mass - k) * part[k]) / mass)
    raise ValueError(method)

def outcome(fb, fw, fc):
    sep = float(fb + fw)
    gain = float(fc - sep)
    return dict(bess_standalone=float(fb), wind_standalone_signed=float(fw), separate_sum=sep, combined_floor=float(fc), pooling_gain=gain, pooling_percent=100 * gain / sep if sep > 1e-08 else np.nan, separate_sum_as_fraction_of_bess=sep / fb if fb > 0 else np.nan, combined_change_vs_bess=float(fc - fb), combined_change_vs_bess_percent=100 * (fc - fb) / fb if fb > 0 else np.nan, positive_combined=bool(fc > 0), valid_percentage_base=bool(sep > 1e-08))

def draw(panel, npaths, seed):
    """Identical RNG order and source selection to prior common_panel.draw."""
    rng = np.random.default_rng(seed)
    N = npaths * 10
    cols = ['bess_cash_gbp', 'ppa100_fee1', 'ppa100_export']
    out = np.zeros((N, 3))
    for month in range(1, 13):
        sources = []
        for y, g in panel[panel.month == month].groupby('year'):
            g = g.sort_values('date')
            x = g[cols].to_numpy(float)
            ix = (np.arange(len(g))[:, None] + np.arange(14)) % len(g)
            sources.append(x[ix])
        if not sources:
            raise ValueError(f'No source month {month}')
        blocks = np.concatenate(sources)
        target = calendar.monthrange(2023, month)[1]
        nb = int(np.ceil(target / 14))
        for lo in range(0, N, 25000):
            hi = min(N, lo + 25000)
            pick = rng.integers(0, len(blocks), size=(hi - lo, nb))
            days = blocks[pick].reshape(hi - lo, -1, 3)[:, :target, :]
            out[lo:hi] += days.sum(axis=1)
    return out.reshape(npaths, 10, 3)

def standalone_wind(p, k_source, method):
    lim = ((k_source + np.cumsum(p, axis=1)) / np.arange(1, p.shape[1] + 1)).min(axis=1)
    return min(stat(lim, method), p.mean()) / 100

def annual_case(engine, u, e, k, kfrac, method):
    p = e * u / 100
    z = np.zeros_like(p)
    K = k * 100
    K_W = K * kfrac
    K_B = K - K_W
    base_bound = engine.bounds(z, K_B)
    fb = min(stat(base_bound, method), engine.margin_limit(0)) / 100
    fw = standalone_wind(p, K_W, method)
    comb = engine.bounds(p, K)
    fc = min(stat(comb, method), engine.margin_limit(float(p.mean()))) / 100
    rr = outcome(fb, fw, fc)
    rr.update(combined_path_pass=float(np.mean(comb >= 100 * fc - 1e-07)), bess_path_pass=float(np.mean(base_bound >= 100 * fb - 1e-07)), mean_ppa_cash=float(p.mean() / 100))
    return rr


# Raw-generated inputs are injected by reproduce.py. Expected files are used ONLY
# for comparisons, never to calculate cash, parameters, model paths or floors.
INPUTS={}; EXPECTED={}; CONFIG={}; RESULTS={}; _CHECKS=[]
OUT_PATH=Path("reproduced")
def read_table(name):
    if name in INPUTS:return INPUTS[name].copy()
    return EXPECTED.get(name,None)
def metadata(key):return CONFIG[key]
def write_table(name, frame):
    if not name or not all(c.isalnum() or c == '_' for c in name):
        raise ValueError('Unsafe output table name')
    RESULTS[name] = frame.copy()


def panel_reference() -> pd.DataFrame:
    d=read_table('input_reference_daily');d['date']=pd.to_datetime(d.date)
    return d

def panel_ppa(sample: str='extended') -> pd.DataFrame:
    d=read_table('input_ppa_daily')
    if sample=='without2022':d=d[d.year!=2022]
    elif sample!='extended':raise ValueError('Expected extended or without2022.')
    return d.reset_index(drop=True)

def check_numeric(name, new, old, columns, keys=None, tolerance=1e-4):
    """Compare numeric outputs; report mismatches rather than alter reference data."""
    if old is None:return
    a=new.copy();b=old.copy()
    if keys:
        a=a.sort_values(keys).reset_index(drop=True)
        b=b.sort_values(keys).reset_index(drop=True)
        if len(a)!=len(b) or not a[keys].astype(str).equals(b[keys].astype(str)):
            raise AssertionError(f'{name}: comparison keys differ')
    if len(a)!=len(b):raise AssertionError(f'{name}: row counts differ')
    errs=[]
    for c in columns:
        x=a[c].to_numpy(float);y=b[c].to_numpy(float)
        ok=bool(np.allclose(x,y,atol=tolerance,rtol=1e-10,equal_nan=True))
        v=np.abs(x-y);err=float(np.nanmax(v)) if np.isfinite(v).any() else 0.0
        _CHECKS.append({'check':name,'column':c,'status':'PASS' if ok else 'MISMATCH',
                        'maximum_absolute_error':err,'absolute_tolerance':tolerance})
        if not ok:errs.append((c,err))
    if errs:print('OUTPUT MISMATCH',name,errs,flush=True)

def original_main() -> None:
    """Tables I and Figure 1, with original draws and original bisection resolution."""
    p=panel_reference();target_rows=[];reserve_rows=[];headline=[];matching=[]
    for seed in rr_SEEDS:
        n=20000
        sc=raf_draw_common_hurdle_scenarios(p,n*10,seed,hurdles=(.70,))
        b=sc.bess.reshape(n,10)
        base=raf_solve_floor_fast(b,np.zeros_like(b))['floor_gbp_per_bess_mw_year']
        rights={}
        for rule,pair in [('daily_non_carrying',sc.daily[.7]),('monthly_netted',sc.monthly[.7])]:
            r=(.5*pair[0]+.5*pair[1]).reshape(n,10);rights[rule]=r
            mean_r=float(r.mean()/100)
            for target in (24000.,26000.,28000.,30000.,32000.):
                sol=raf_alpha_min_for_target(b,r,target)
                target_rows.append(dict(seed=seed,target_floor=target,settlement_rule=rule,
                    alpha=sol['alpha_min'],cash=sol['alpha_min']*mean_r))
            for k in (0.,500.,1000.,1500.,2500.,5000.):
                s=ar_solve_alpha(b,r,k)
                reserve_rows.append(dict(seed=seed,settlement_rule=rule,
                    opening_reserve_gbp_per_bess_mw=k,alpha_min_mean=s['alpha_min'],
                    transferred_cash_gbp_per_bess_mw_year=s['alpha_min']*mean_r))
        for label,r,access in [('daily_50',rights['daily_non_carrying']*.5,.5),
                               ('monthly_50',rights['monthly_netted']*.5,.5),
                               ('monthly_cash_matched',rights['monthly_netted']*.5*
                                (rights['daily_non_carrying'].mean()/rights['monthly_netted'].mean()),
                                .5*rights['daily_non_carrying'].mean()/rights['monthly_netted'].mean())]:
            result=raf_solve_floor_fast(b,r)
            matching.append(dict(seed=seed,case=label,access=access,
                mean_transfer=float(r.mean()/100),floor=result['floor_gbp_per_bess_mw_year']))
        headline.append(dict(seed=seed,bess_only=base,backed_daily_50=matching[-3]['floor']))
        print('Table I / Figure 1 seed',seed,'complete',flush=True)
    t=pd.DataFrame(target_rows)
    s=t.groupby(['target_floor','settlement_rule'])[['alpha','cash']].mean().unstack()
    table=pd.DataFrame({'target_floor':s.index,
        'daily_access_pct':100*s['alpha']['daily_non_carrying'].values,
        'daily_cash':s['cash']['daily_non_carrying'].values,
        'monthly_access_pct':100*s['alpha']['monthly_netted'].values,
        'monthly_cash':s['cash']['monthly_netted'].values})
    fig=pd.DataFrame(reserve_rows).groupby(['settlement_rule','opening_reserve_gbp_per_bess_mw'],as_index=False)[['alpha_min_mean','transferred_cash_gbp_per_bess_mw_year']].mean()
    write_table('table_i',table);write_table('figure_1_data',fig)
    write_table('original_target_seed_runs',t);write_table('original_reserve_seed_runs',pd.DataFrame(reserve_rows))
    write_table('original_headline_seed_runs',pd.DataFrame(headline))
    write_table('original_cash_matching',pd.DataFrame(matching))
    check_numeric('Table I',table,read_table('reported_table_i'),
                  ['daily_access_pct','daily_cash','monthly_access_pct','monthly_cash'],['target_floor'],1e-4)
    check_numeric('Figure 1',fig,read_table('reported_figure_1'),
                  ['alpha_min_mean','transferred_cash_gbp_per_bess_mw_year'],
                  ['settlement_rule','opening_reserve_gbp_per_bess_mw'],1e-4)

def ppa_headlines() -> None:
    """Re-solve the four paper terms, not just their stored percentages."""
    terms=read_table('selected_ppa_terms');rows=[]
    for seed in (251001,251002,251003):
        a=draw(panel_ppa(),30000,seed);engine=Engine(a[:,:,0])
        for r in terms.to_dict('records'):
            u=a[:,:,1]+(r['fee_gbp_mwh']-1)*a[:,:,2]
            v=annual_case(engine,u,r['effective_wind_mw'],r['opening_K'],r['wind_K_fraction'],r['method'])
            rows.append(dict(**r,seed=seed,paths=30000,**v))
        print('PPA Tables III-IV seed',seed,'complete',flush=True)
    runs=pd.DataFrame(rows)
    cols=['bess_standalone','wind_standalone_signed','separate_sum','combined_floor','pooling_gain','mean_ppa_cash']
    summary=runs.groupby('case_id',as_index=False)[cols].mean().merge(terms,on='case_id')
    summary['pooling_percent']=100*summary.pooling_gain/summary.separate_sum
    summary['wind_bess_ratio']=summary.effective_wind_mw/100
    write_table('ppa_tables_iii_iv',summary);write_table('ppa_seed_runs',runs)
    check_numeric('PPA selected seed limits',runs,read_table('reference_ppa_seed_runs'),cols,['case_id','seed'],1e-4)
    check_numeric('Tables III-IV',summary,read_table('reference_tables_iii_iv'),
                  cols+['pooling_percent'],['case_id'],1e-4)

def correlations() -> None:
    d=read_table('input_monthly_correlation');rows=[]
    for fee in (1.,2.):
        wind=d.wind100+(fee-1)*d.export100
        coefficient=float(np.corrcoef(wind,d.bess_staged)[0,1])
        rows.append({'PPA_fee_gbp_mwh':fee,'months':len(d),'battery_cash':'staged_DA_MID',
                     'pearson':coefficient,'paper_rounded':-.657 if fee==1 else -.613})
        assert round(coefficient,3)==rows[-1]['paper_rounded']
    write_table('monthly_correlations',pd.DataFrame(rows))

def confirmation() -> None:
    rows=[];p=panel_reference()
    for seed in rr_SEEDS:
        sc=rr_draw_both_rights(p,500000,seed);b,r=rr_path_arrays(sc,50000,'surplus_only',.5)
        base=rr_solve_path_floor(b,np.zeros_like(b),.95);both=rr_solve_path_floor(b,r,.95)
        rows.append({'seed':seed,'right':'surplus_only',
            'bess_only_floor_gbp_per_bess_mw_year':base['floor_gbp_per_bess_mw_year'],
            'renewable_backed_floor_gbp_per_bess_mw_year':both['floor_gbp_per_bess_mw_year'],
            'uplift_fraction':both['floor_gbp_per_bess_mw_year']/base['floor_gbp_per_bess_mw_year']-1})
        print('50,000-path original confirmation seed',seed,flush=True)
    r=pd.DataFrame(rows);write_table('original_50000_confirmation',r)
    check_numeric('Original 50,000-path confirmation',r,read_table('reference_confirmation'),
      ['bess_only_floor_gbp_per_bess_mw_year','renewable_backed_floor_gbp_per_bess_mw_year','uplift_fraction'],['seed','right'],1e-4)

def heldout() -> None:
    """Recovered default Table II rerun. Reported counts are not overwritten."""
    settings=metadata('heldout_settings');f=settings['frozen_contract'];p=panel_reference()
    frozen=mav_FrozenResidualConfig(np.array(f['hurdle_w']),np.array(f['hurdle_s']),
        f['daily_scale_w'],f['daily_scale_s'],f['monthly_scale_w'],f['monthly_scale_s'])
    master=np.random.default_rng(20260822);rows=[]
    for rep in range(300):
        bs=int(master.integers(0,2**32-1));es=int(master.integers(0,2**32-1))
        boot=rme_bootstrap_panel(p,np.random.default_rng(bs))
        b,rights,_=mav_draw_residual_scenarios(boot,5000*10,es,frozen=frozen);b=b.reshape(5000,10)
        for rule,r in rights.items():
            r=r.reshape(5000,10)
            for label,t in settings['selected_terms'].items():
                v=hfv_target_metrics(b,r,t[rule])
                rows.append(dict(replication=rep,term_type=label,settlement_rule=rule,
                    access_share=t[rule],evaluation_empirical_target_attained=int(v['empirical_target_attained']),
                    evaluation_wilson_target_attained=int(v['wilson_target_attained']),solvency=v['solvency']))
        if (rep+1)%50==0:print('Table II recovered default',rep+1,'/300',flush=True)
    r=pd.DataFrame(rows);g=r.groupby(['term_type','settlement_rule'],as_index=False).agg(
        access_share=('access_share','first'),evaluation_empirical_success_count=('evaluation_empirical_target_attained','sum'))
    g['heldout_replications']=300;g['evaluation_empirical_target_attainment']=g.evaluation_empirical_success_count/300
    write_table('table_ii_recovered_run',g);write_table('table_ii_recovered_seed_runs',r)
    check_numeric('Table II recovered-default reproduction',g,read_table('recovered_table_ii'),
                  ['evaluation_empirical_success_count','access_share'],['term_type','settlement_rule'],1e-10)
    reported=read_table('reported_table_ii')
    if reported is not None:
        comp=reported.merge(g,on=['term_type','settlement_rule'])
        comp['matches_manuscript']=comp.target_met==comp.evaluation_empirical_success_count
        comp['note']='Unreconciled manuscript-versus-recovered-run count; no seeds or outcomes altered.'
        write_table('table_ii_reported_vs_recovered',comp)
        for r in comp.to_dict('records'):
            _CHECKS.append({'check':'Manuscript Table II count','column':r['term_type']+'/'+r['settlement_rule'],
                'status':'PASS' if r['matches_manuscript'] else 'MISMATCH',
                'maximum_absolute_error':abs(r['target_met']-r['evaluation_empirical_success_count']),
                'absolute_tolerance':0.})
        print('TABLE II: manuscript and recovered counts remain separate.\n'+comp[['term_type','settlement_rule','target_met','evaluation_empirical_success_count']].to_string(index=False),flush=True)

def ppa_sensitivity() -> None:
    """Exclusion-of-2022 check and whole-path pairing on the two worst-5% cases."""
    terms=read_table('selected_ppa_terms');terms=terms[terms.method=='worst5'];rows=[]
    for sample in ('extended','without2022'):
        for seed in (251001,251002,251003):
            a=draw(panel_ppa(sample),10000,seed);e=Engine(a[:,:,0])
            rng=np.random.default_rng(seed+10000);perms=[rng.permutation(len(a)) for _ in range(20)]
            for r in terms.to_dict('records'):
                u=a[:,:,1]+(r['fee_gbp_mwh']-1)*a[:,:,2];p=r['effective_wind_mw']/100*u
                v=annual_case(e,u,r['effective_wind_mw'],r['opening_K'],r['wind_K_fraction'],'worst5')
                mar=e.margin_limit(float(p.mean()))
                re=float(np.mean([min(stat(e.bounds(p[ix],100*r['opening_K']),'worst5'),mar)/100 for ix in perms]))
                rows.append(dict(case_id=r['case_id'],sample=sample,seed=seed,re_paired_combined=re,
                                 alignment_amount=v['combined_floor']-re,**v))
            print('PPA sensitivity',sample,seed,flush=True)
    df=pd.DataFrame(rows);cols=['bess_standalone','wind_standalone_signed','separate_sum','combined_floor','pooling_gain','re_paired_combined','alignment_amount']
    s=df.groupby(['case_id','sample'],as_index=False)[cols].mean();s['pooling_percent']=100*s.pooling_gain/s.separate_sum
    write_table('ppa_sensitivity',s);write_table('ppa_sensitivity_seed_runs',df)
    old=read_table('reference_ppa_sensitivity_runs')
    if old is not None:old=old[(old.method=='worst5')&old['sample'].isin(['extended','without2022'])]
    check_numeric('PPA fixed-term sensitivity',df,old,cols,['case_id','sample','seed'],1e-4)

def robustness() -> None:
    """Recalculate only the alternative schedule / persistence / retention in IV.C."""
    p=panel_reference();n=20000;rows=[];nc_rows=[];ret_rows=[];reg_rows=[]
    blocks=fsc_build_non_circular_blocks(p)
    library=rce_build_contiguous_annual_window_library(p)
    for seed in rr_SEEDS:
        sc=rr_draw_both_rights(p,n*10,seed);b,r=rr_path_arrays(sc,n,'surplus_only',.5)
        # Flat immediate payments and 50% first-year ramp; only the retained cases.
        for ramp in (False,True):
            schedule=np.r_[.5 if ramp else 1.,np.ones(9)]
            for life in (1,None):
                sol=rce_solve_scheduled_retention_floor(b,r,schedule,life)
                ret_rows.append(dict(seed=seed,ramp=ramp,retention_years='unlimited' if life is None else '1',**sol))
        # Non-circular-day comparison, same means as the archived reference draw.
        ba,ra=fsc_draw_non_circular_surplus(blocks,p,n*10,seed)
        ba=ba.reshape(n,10);ra=ra.reshape(n,10);ba*=b.mean()/ba.mean();ra*=r.mean()/ra.mean()
        for label,B,R in [('circular_within_source_month',b,r),('non_circular_calendar_contiguous_mean_matched',ba,ra)]:
            base=rr_solve_path_floor(B,np.zeros_like(B),.95);back=rr_solve_path_floor(B,R,.95)
            nc_rows.append(dict(seed=seed,construction=label,bess_only_floor_gbp_per_bess_mw_year=base['floor_gbp_per_bess_mw_year'],
                surplus_backed_floor_gbp_per_bess_mw_year=back['floor_gbp_per_bess_mw_year'],
                uplift_pct=100*(back['floor_gbp_per_bess_mw_year']/base['floor_gbp_per_bess_mw_year']-1)))
        # Four-week seasonal schedule, holding renewable inputs fixed.
        alt=p.copy();alt['bess_cash_gbp']=alt.bess_seasonal_gbp
        ss=raf_draw_common_hurdle_scenarios(alt,n*10,seed,hurdles=(.7,));bb=ss.bess.reshape(n,10)
        for rule,pair in [('daily_non_carrying',ss.daily[.7]),('monthly_netted',ss.monthly[.7])]:
            R=(.5*pair[0]+.5*pair[1]).reshape(n,10);sol=raf_alpha_min_for_target(bb,R,30000.)
            rows.append(dict(seed=seed,strategy='seasonal_28d',settlement_rule=rule,alpha_min=sol['alpha_min'],
                             admitted_cash_gbp_per_bess_mw_year=sol['alpha_min']*R.mean()/100))
        for rho in (0.,.5,.8):
            B,rights,actual=rce__paths_from_window_library(library,n,10,seed+int(10000*rho)+901,rho)
            base=liquidity_solve_floor(B,np.zeros_like(B),'unlimited_reserve',.95)
            for case in ('bess_only','surplus_only'):
                sol=liquidity_solve_floor(B,rights[case],'unlimited_reserve',.95)
                reg_rows.append(dict(seed=seed,rank_persistence_rho=rho,case=case,
                    floor_gbp_per_bess_mw_year=sol['floor_gbp_per_bess_mw_year'],
                    uplift_fraction=sol['floor_gbp_per_bess_mw_year']/base['floor_gbp_per_bess_mw_year']-1))
        print('Original IV.C robustness seed',seed,flush=True)
    nc=pd.DataFrame(nc_rows);alt=pd.DataFrame(rows);ret=pd.DataFrame(ret_rows);reg=pd.DataFrame(reg_rows)
    write_table('original_noncircular',nc);write_table('original_seasonal_schedule',alt)
    write_table('original_retention',ret);write_table('original_regime',reg)
    check_numeric('Original non-circular sensitivity',nc,read_table('reference_noncircular'),
                  ['bess_only_floor_gbp_per_bess_mw_year','surplus_backed_floor_gbp_per_bess_mw_year','uplift_pct'],['seed','construction'],1e-4)
    old=read_table('reference_alt_schedule');old=old[old.strategy=='seasonal_28d'] if old is not None else None
    check_numeric('Original seasonal schedule',alt,old,['alpha_min','admitted_cash_gbp_per_bess_mw_year'],['seed','strategy','settlement_rule'],1e-4)
    old=read_table('reference_retention');old=old[(old.case=='surplus_only')&old.retention_years.isin(['1','unlimited'])] if old is not None else None
    check_numeric('Original first-year-ramp retention',ret[ret.ramp],old,
                  ['average_scheduled_floor_gbp_per_bess_mw_year'],['seed','retention_years'],1e-4)
    old=read_table('reference_regime');old=old[(old.generator=='contiguous_12_month')&(old.policy=='unlimited_reserve')] if old is not None else None
    check_numeric('Original annual-regime stress',reg,old,['floor_gbp_per_bess_mw_year','uplift_fraction'],['seed','rank_persistence_rho','case'],1e-4)

def tests() -> None:
    checks=[]
    def passed(label,cond):
        if not cond:raise AssertionError(label)
        checks.append({'test':label,'status':'PASS'})
    passed('Signed standalone baseline',abs(outcome(10,-2,11)['pooling_percent']-37.5)<1e-12)
    passed('Zero denominator is undefined',np.isnan(outcome(10,-10,11)['pooling_percent']))
    passed('Negative denominator is undefined',np.isnan(outcome(10,-11,11)['pooling_percent']))
    passed('Signed wind loss retained',outcome(10,-2,11)['wind_standalone_signed']==-2)
    x=np.arange(31,dtype=float)
    passed('Worst-5% fractional boundary',abs(stat(x,'worst5')-.55/1.55)<1e-12)
    passed('95% empirical order statistic',stat(x,'coverage95')==1)
    rng=np.random.default_rng(713);b=rng.uniform(100,200,(100,10));r=rng.normal(2,8,b.shape);e=Engine(b)
    sol=e.solve(r,10);lo=-200.;hi=400.
    for _ in range(60):
        mid=(lo+hi)/2;v=e.evaluate(r,10,mid)
        if v['path_pass']>=.95 and v['margin_pass']:lo=mid
        else:hi=mid
    passed('Analytic floor vs direct bisection',abs(sol['floor']-lo/100)<1e-7)
    passed('Equivalent PPA participation',np.array_equal(r*475*.5,r*237.5))
    passed('More opening capital cannot reduce bound',np.all(e.bounds(r,20)>=e.bounds(r,10)-1e-12))
    passed('Whole-path pairing preserves mean cash',abs(r.mean()-r[rng.permutation(len(r))].mean())<1e-12)
    cap=standalone_wind(-np.ones((100,10))*20,0,'coverage95')
    passed('Negative standalone wind capacity retained',abs(cap+.2)<1e-12)
    terms=read_table('selected_ppa_terms')
    passed('Capital allocated once',bool((terms.wind_K_fraction.between(0,1)).all()))
    d=RESULTS.get('ppa_tables_iii_iv')
    if d is not None:passed('Selected denominator identity',np.allclose(d.separate_sum,d.bess_standalone+d.wind_standalone_signed))
    if d is not None:passed('Selected percent identity',np.allclose(d.pooling_percent,100*(d.combined_floor-d.separate_sum)/d.separate_sum))
    write_table('unit_tests',pd.DataFrame(checks));print(len(checks),'numerical tests PASS',flush=True)

def select_residual_terms() -> None:
    """Re-estimate the 120-panel selection stage from reconstructed cash inputs.
    No published higher access percentage or saved threshold array is an input.
    """
    p=panel_reference();master=np.random.default_rng(20260815);rows=[]
    for rep in range(120):
        bs,ts,es=[int(master.integers(0,2**32-1)) for _ in range(3)]
        boot=rme_bootstrap_panel(p,np.random.default_rng(bs))
        ba,ra,cfg=mav_draw_residual_scenarios(boot,20000,ts)
        be,re,_=mav_draw_residual_scenarios(boot,50000,es,frozen=cfg)
        ba=ba.reshape(2000,10);be=be.reshape(5000,10)
        for cal,wilson in [('empirical_q',False),('wilson_lower_bound',True)]:
            for rule in ['daily_non_carrying','monthly_netted']:
                alpha,train=mav_solve_alpha(ba,ra[rule].reshape(2000,10),wilson_rule=wilson)
                ok=bool(np.isfinite(alpha))
                ev=mav_reserve_metrics(be,re[rule].reshape(5000,10),alpha) if ok else {'solvency':np.nan,'wilson_lower':np.nan,'margin_pass':False}
                rows.append(dict(replication=rep,calibration_rule=cal,settlement_rule=rule,
                    alpha_min=alpha,training_target_reached=int(ok),
                    training_solvency=train['solvency'],training_wilson_lower=train['wilson_lower'],
                    evaluation_solvency=ev['solvency'],
                    evaluation_empirical_target_attained=int(ok and ev['solvency']>=.95-1e-12 and ev['margin_pass']),
                    evaluation_wilson_target_attained=int(ok and ev['wilson_lower']>=.95-1e-12 and ev['margin_pass'])))
        if (rep+1)%30==0:print('Original 120-panel access selection',rep+1,'/120',flush=True)
    d=pd.DataFrame(rows);summary=d.groupby(['calibration_rule','settlement_rule'],as_index=False).agg(
        replications=('replication','count'),training_target_reachability=('training_target_reached','mean'),
        alpha_min_median=('alpha_min','median'),alpha_min_p025=('alpha_min',lambda x:x.quantile(.025)),
        alpha_min_p975=('alpha_min',lambda x:x.quantile(.975)),
        evaluation_empirical_success_count=('evaluation_empirical_target_attained','sum'))
    write_table('residual_selection_summary',summary);write_table('residual_selection_runs',d)
    old=read_table('reference_selection')
    if old is not None:
        check_numeric('Original access-selection exercise',summary,old,
            ['training_target_reachability','alpha_min_p975','evaluation_empirical_success_count'],
            ['calibration_rule','settlement_rule'],1e-7)
    cfg=hfv_build_master_frozen_config(p)
    f={name:(value.tolist() if isinstance(value,np.ndarray) else value) for name,value in vars(cfg).items()}
    central=RESULTS['original_target_seed_runs'];central=central[central.target_floor==30000].groupby('settlement_rule').alpha.mean().to_dict()
    high=summary[summary.calibration_rule=='wilson_lower_bound'].set_index('settlement_rule').alpha_min_p975.to_dict()
    CONFIG['heldout_settings']={'frozen_contract':f,'selected_terms':{'full_sample_point':central,'higher_resampling_fixed':high}}
    write_table('reconstructed_contract_configuration',pd.DataFrame([{'key':'heldout_settings','value_json':json.dumps(CONFIG['heldout_settings'])}]))
