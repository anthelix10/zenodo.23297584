#!/usr/bin/env python3
"""Test target-floor access requirements under alternative BESS schedules.

The central target is a £30,000/MW-year BESS floor under q=95%, zero opening
reserve, a 70% protected hurdle, fixed 50% wind equal-mean cash exposure and
the paper's 25 MW-equivalent renewable cash scale.  The script retains the same
renewable data and contract terms while replacing the BESS cash schedule with
the archived canonical Ridge, 28-day seasonal and two-day-lag alternatives.

This is a focused portability test of the minimum-access decision, not a new
forecasting study or a complete all-market BESS valuation.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))

import phase_model as pm  # noqa: E402
import run_access_frontier as raf  # noqa: E402
import run_retained_reserve_analysis as rr  # noqa: E402

DEFAULT_OUT = ROOT / "results" / "retained_reserve"
DEFAULT_VALIDATION = ROOT / "validation"
TARGET = 30_000.0
Q = 0.95
HURDLE = 0.70
WIND_SHARE = 0.50


def panels() -> dict[str, pd.DataFrame]:
    duration_daily = rr.prepare_duration_daily(False)
    canonical = rr.live_panel_for_duration(2, duration_daily)
    alt = pd.read_csv(
        ROOT / "results" / "operating_phase" / "alternative_bess_daily_cash.csv",
        parse_dates=["date"],
    )
    out = {"canonical_ridge": canonical}
    for strategy, group in alt.groupby("strategy"):
        out[str(strategy)] = pm.load_live_panel(group[["date", "bess_cash_gbp"]])
    return out


def run(n_paths: int, out: Path, validation: Path) -> dict:
    out.mkdir(parents=True, exist_ok=True)
    validation.mkdir(parents=True, exist_ok=True)
    rows: list[dict] = []
    start = time.time()

    for strategy, panel in panels().items():
        for seed in rr.SEEDS:
            scenarios = raf.draw_common_hurdle_scenarios(
                panel,
                n_paths * rr.TENOR_YEARS,
                seed,
                hurdles=(HURDLE,),
            )
            bess = scenarios.bess.reshape(n_paths, rr.TENOR_YEARS)
            base = raf.solve_floor_fast(bess, np.zeros_like(bess), q=Q)
            for settlement, pair in (
                ("daily_non_carrying", scenarios.daily[HURDLE]),
                ("monthly_netted", scenarios.monthly[HURDLE]),
            ):
                residual_100_annual = WIND_SHARE * pair[0] + (1.0 - WIND_SHARE) * pair[1]
                residual_100 = residual_100_annual.reshape(n_paths, rr.TENOR_YEARS)
                solved = raf.alpha_min_for_target(bess, residual_100, TARGET, q=Q)
                alpha = float(solved["alpha_min"]) if solved["reached"] else float("nan")
                rows.append({
                    "strategy": strategy,
                    "seed": seed,
                    "panel_days": len(panel),
                    "paths": n_paths,
                    "q": Q,
                    "target_floor_gbp_per_bess_mw_year": TARGET,
                    "protected_hurdle": HURDLE,
                    "wind_equal_mean_cash_share": WIND_SHARE,
                    "renewable_cash_scale_mw_equivalent_per_100mw_bess": rr.RENEWABLE_REFERENCE_MW,
                    "settlement_rule": settlement,
                    "bess_only_floor_gbp_per_bess_mw_year": base["floor_gbp_per_bess_mw_year"],
                    "simple_cash_gap_gbp_per_bess_mw_year": TARGET - base["floor_gbp_per_bess_mw_year"],
                    "target_reached_at_or_below_100pct_access": bool(solved["reached"]),
                    "alpha_min": alpha,
                    "admitted_cash_gbp_per_bess_mw_year": (
                        alpha * float(residual_100.mean()) / rr.P_BESS_MW
                        if np.isfinite(alpha)
                        else float("nan")
                    ),
                    "solvency_fraction": solved["solvency_fraction"],
                    "mean_provider_cash_gbp_per_bess_mw_year": solved["mean_provider_cash_gbp_per_bess_mw_year"],
                })
        print(f"target schedule sensitivity complete: {strategy}", flush=True)

    run_level = pd.DataFrame(rows)
    run_level.to_csv(out / "target_floor_schedule_sensitivity_run_level.csv", index=False)

    summary_rows: list[dict] = []
    for (strategy, settlement), group in run_level.groupby(["strategy", "settlement_rule"], sort=False):
        reached = bool(group["target_reached_at_or_below_100pct_access"].all())
        summary_rows.append({
            "strategy": strategy,
            "settlement_rule": settlement,
            "panel_days": int(group["panel_days"].iloc[0]),
            "bess_only_floor_gbp_per_bess_mw_year": float(group["bess_only_floor_gbp_per_bess_mw_year"].mean()),
            "simple_cash_gap_gbp_per_bess_mw_year": float(group["simple_cash_gap_gbp_per_bess_mw_year"].mean()),
            "target_reached_all_seeds": reached,
            "alpha_min_mean": float(group["alpha_min"].mean()) if reached else float("nan"),
            "alpha_min_seed_min": float(group["alpha_min"].min()) if reached else float("nan"),
            "alpha_min_seed_max": float(group["alpha_min"].max()) if reached else float("nan"),
            "admitted_cash_gbp_per_bess_mw_year": float(group["admitted_cash_gbp_per_bess_mw_year"].mean()) if reached else float("nan"),
            "solvency_fraction": float(group["solvency_fraction"].mean()),
        })
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(out / "Table_S43_target_floor_bess_schedule.csv", index=False)

    audit = {
        "status": "PASS",
        "release": "1.9.1",
        "paths_per_seed": n_paths,
        "seeds": list(rr.SEEDS),
        "target_floor_gbp_per_bess_mw_year": TARGET,
        "q": Q,
        "protected_hurdle": HURDLE,
        "wind_equal_mean_cash_share": WIND_SHARE,
        "renewable_cash_scale_mw_equivalent_per_100mw_bess": rr.RENEWABLE_REFERENCE_MW,
        "note": "Only the archived BESS cash schedule changes; renewable data, access definition and reserve solver remain fixed.",
    }
    (validation / "target_floor_schedule_sensitivity_audit.json").write_text(
        json.dumps(audit, indent=2), encoding="utf-8"
    )
    meta = {
        **audit,
        "runtime_seconds": time.time() - start,
        "outputs": [
            "target_floor_schedule_sensitivity_run_level.csv",
            "Table_S43_target_floor_bess_schedule.csv",
            "validation/target_floor_schedule_sensitivity_audit.json",
        ],
    }
    (out / "target_floor_schedule_sensitivity_metadata.json").write_text(
        json.dumps(meta, indent=2), encoding="utf-8"
    )
    return meta


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--paths", type=int, default=20_000)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--validation-dir", type=Path, default=DEFAULT_VALIDATION)
    args = parser.parse_args()
    print(json.dumps(run(args.paths, args.output_dir, args.validation_dir), indent=2))


if __name__ == "__main__":
    main()
