#!/usr/bin/env python3
"""Evaluate fixed residual-access terms across historical outer resamples.

This script answers a different question from the re-estimated-access validation:
how do pre-specified access percentages perform when the historical year-month
panel changes? Two designs are evaluated for the £30,000/MW-year target:

* the full-sample point estimates from Table S33; and
* the 97.5th-percentile Wilson-calibrated training requirements from Table S36.

For each of the same 120 outer bootstrap panels, the monthly threshold schedule
and equal-mean wind/solar scaling are estimated on 2,000 training paths and frozen
on 5,000 independent evaluation paths. The access percentage is never re-estimated.
The result is a historical-resampling diagnostic, not an externally validated
future default probability.
"""
from __future__ import annotations

import argparse
import json
import math
import multiprocessing as mp
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))

import run_methodological_extensions as rme  # noqa: E402
import run_minimum_access_validation as mav  # noqa: E402
import run_retained_reserve_analysis as rr  # noqa: E402

DEFAULT_OUT = ROOT / "results" / "retained_reserve"
DEFAULT_VALIDATION = ROOT / "validation"
Q = 0.95
TARGET = 30_000.0
HURDLE = 0.70
WIND_SHARE = 0.50

_PANEL: pd.DataFrame | None = None
_TERMS: dict[str, dict[str, float]] | None = None
_N_TRAIN = 2_000
_N_EVAL = 5_000


def wilson_interval(successes: int, n: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if n <= 0:
        return float("nan"), float("nan")
    phat = successes / n
    denom = 1.0 + z * z / n
    centre = (phat + z * z / (2.0 * n)) / denom
    half = z * math.sqrt(phat * (1.0 - phat) / n + z * z / (4.0 * n * n)) / denom
    return centre - half, centre + half


def load_terms(out: Path) -> dict[str, dict[str, float]]:
    targets = pd.read_csv(out / "Table_S33_minimum_access_targets.csv")
    historical = pd.read_csv(out / "Table_S36_minimum_access_historical_validation.csv")
    point = targets[targets["target_floor_gbp_per_bess_mw_year"].eq(TARGET)].set_index("settlement_rule")
    upper = historical[historical["calibration_rule"].eq("wilson_lower_bound")].set_index("settlement_rule")
    return {
        "full_sample_point": {
            "daily_non_carrying": float(point.loc["daily_non_carrying", "alpha_min_mean"]),
            "monthly_netted": float(point.loc["monthly_netted", "alpha_min_mean"]),
        },
        "upper_tail_resampling": {
            "daily_non_carrying": float(upper.loc["daily_non_carrying", "alpha_min_p975"]),
            "monthly_netted": float(upper.loc["monthly_netted", "alpha_min_p975"]),
        },
    }


def _init_worker(panel: pd.DataFrame, terms: dict[str, dict[str, float]], n_train: int, n_eval: int) -> None:
    global _PANEL, _TERMS, _N_TRAIN, _N_EVAL
    _PANEL = panel
    _TERMS = terms
    _N_TRAIN = n_train
    _N_EVAL = n_eval


def _run_rep(task: tuple[int, int, int, int]) -> list[dict]:
    rep, bootstrap_seed, train_seed, eval_seed = task
    assert _PANEL is not None and _TERMS is not None
    boot = rme.bootstrap_panel(_PANEL, np.random.default_rng(bootstrap_seed))
    _, _, cfg = mav.draw_residual_scenarios(boot, _N_TRAIN * rr.TENOR_YEARS, train_seed)
    b_eval_annual, r_eval_annual, _ = mav.draw_residual_scenarios(
        boot, _N_EVAL * rr.TENOR_YEARS, eval_seed, frozen=cfg
    )
    b_eval = b_eval_annual.reshape(_N_EVAL, rr.TENOR_YEARS)
    rows: list[dict] = []
    for settlement in ("daily_non_carrying", "monthly_netted"):
        r_eval = r_eval_annual[settlement].reshape(_N_EVAL, rr.TENOR_YEARS)
        for term_type, by_settlement in _TERMS.items():
            alpha = float(by_settlement[settlement])
            metrics = mav.reserve_metrics(b_eval, r_eval, alpha)
            empirical = bool(metrics["solvency"] >= Q - 1e-12 and metrics["margin_pass"])
            wilson = bool(metrics["wilson_lower"] >= Q - 1e-12 and metrics["margin_pass"])
            rows.append({
                "replication": rep,
                "term_type": term_type,
                "settlement_rule": settlement,
                "target_floor_gbp_per_bess_mw_year": TARGET,
                "protected_hurdle": HURDLE,
                "wind_equal_mean_cash_share": WIND_SHARE,
                "renewable_cash_scale_mw_equivalent_per_100mw_bess": rr.RENEWABLE_REFERENCE_MW,
                "access_share": alpha,
                "evaluation_solvency": metrics["solvency"],
                "evaluation_wilson_lower": metrics["wilson_lower"],
                "evaluation_margin_pass": float(metrics["margin_pass"]),
                "evaluation_empirical_target_attained": float(empirical),
                "evaluation_wilson_target_attained": float(wilson),
                "evaluation_admitted_cash_gbp_per_bess_mw_year": alpha * float(r_eval.mean()) / rr.P_BESS_MW,
                "evaluation_mean_provider_cash_gbp_per_bess_mw_year": metrics["mean_provider_cash_gbp_per_bess_mw_year"],
            })
    return rows


def summarize(run: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict] = []
    for (term_type, settlement), g in run.groupby(["term_type", "settlement_rule"], sort=True):
        n = int(len(g))
        emp = int(g["evaluation_empirical_target_attained"].sum())
        wil = int(g["evaluation_wilson_target_attained"].sum())
        emp_lo, emp_hi = wilson_interval(emp, n)
        wil_lo, wil_hi = wilson_interval(wil, n)
        rows.append({
            "term_type": term_type,
            "settlement_rule": settlement,
            "access_share": float(g["access_share"].iloc[0]),
            "replications": n,
            "evaluation_empirical_success_count": emp,
            "evaluation_empirical_target_attainment": emp / n,
            "evaluation_empirical_attainment_wilson95_lower": emp_lo,
            "evaluation_empirical_attainment_wilson95_upper": emp_hi,
            "evaluation_wilson_success_count": wil,
            "evaluation_wilson_target_attainment": wil / n,
            "evaluation_wilson_attainment_wilson95_lower": wil_lo,
            "evaluation_wilson_attainment_wilson95_upper": wil_hi,
            "evaluation_solvency_median": float(g["evaluation_solvency"].median()),
            "evaluation_solvency_p025": float(g["evaluation_solvency"].quantile(0.025)),
            "evaluation_solvency_p975": float(g["evaluation_solvency"].quantile(0.975)),
            "evaluation_admitted_cash_median_gbp_per_bess_mw_year": float(g["evaluation_admitted_cash_gbp_per_bess_mw_year"].median()),
            "evaluation_admitted_cash_p025_gbp_per_bess_mw_year": float(g["evaluation_admitted_cash_gbp_per_bess_mw_year"].quantile(0.025)),
            "evaluation_admitted_cash_p975_gbp_per_bess_mw_year": float(g["evaluation_admitted_cash_gbp_per_bess_mw_year"].quantile(0.975)),
        })
    return pd.DataFrame(rows)


def run(reps: int, n_train: int, n_eval: int, seed: int, workers: int, out: Path, validation: Path) -> dict:
    out.mkdir(parents=True, exist_ok=True)
    validation.mkdir(parents=True, exist_ok=True)
    terms = load_terms(out)
    duration_daily = rr.prepare_duration_daily(False)
    panel = rr.live_panel_for_duration(2, duration_daily)

    master = np.random.default_rng(seed)
    tasks = [
        (rep, int(master.integers(0, 2**32 - 1)), int(master.integers(0, 2**32 - 1)), int(master.integers(0, 2**32 - 1)))
        for rep in range(reps)
    ]
    start = time.time()
    rows: list[dict] = []
    ctx = mp.get_context("fork")
    with ctx.Pool(
        processes=workers,
        initializer=_init_worker,
        initargs=(panel, terms, n_train, n_eval),
        maxtasksperchild=20,
    ) as pool:
        for done, rep_rows in enumerate(pool.imap_unordered(_run_rep, tasks, chunksize=1), start=1):
            rows.extend(rep_rows)
            if done % max(1, reps // 10) == 0:
                print(f"fixed access validation {done}/{reps}", flush=True)

    run_level = pd.DataFrame(rows).sort_values(["replication", "term_type", "settlement_rule"]).reset_index(drop=True)
    summary = summarize(run_level)
    run_level.to_csv(out / "fixed_access_terms_run_level.csv", index=False)
    summary.to_csv(out / "Table_S42_fixed_access_terms.csv", index=False)

    audit = {
        "status": "PASS",
        "release": "1.9.1",
        "replications": reps,
        "training_paths": n_train,
        "evaluation_paths": n_eval,
        "outer_seed": seed,
        "target_floor_gbp_per_bess_mw_year": TARGET,
        "q": Q,
        "workers": workers,
        "full_sample_point_terms": terms["full_sample_point"],
        "upper_tail_resampling_terms": terms["upper_tail_resampling"],
        "engine_note": "Access percentages are read from archived Tables S33 and S36 and evaluated without re-estimation in each outer panel.",
        "note": "Upper-tail terms are the 97.5th percentiles of Wilson-calibrated training requirements from the same historical-resampling design; they are not external future guarantees.",
    }
    (validation / "fixed_access_terms_audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    meta = {
        "status": "PASS",
        "release": "1.9.1",
        "replications": reps,
        "training_paths": n_train,
        "evaluation_paths": n_eval,
        "outer_seed": seed,
        "workers": workers,
        "runtime_seconds": time.time() - start,
        "outputs": [
            "fixed_access_terms_run_level.csv",
            "Table_S42_fixed_access_terms.csv",
            "validation/fixed_access_terms_audit.json",
        ],
    }
    (out / "fixed_access_terms_metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return meta


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--replications", type=int, default=120)
    ap.add_argument("--training-paths", type=int, default=2_000)
    ap.add_argument("--evaluation-paths", type=int, default=5_000)
    ap.add_argument("--seed", type=int, default=20260815)
    ap.add_argument("--workers", type=int, default=max(1, min(4, (mp.cpu_count() or 2) - 1)))
    ap.add_argument("--output-dir", type=Path, default=DEFAULT_OUT)
    ap.add_argument("--validation-dir", type=Path, default=DEFAULT_VALIDATION)
    args = ap.parse_args()
    meta = run(args.replications, args.training_paths, args.evaluation_paths, args.seed, args.workers, args.output_dir, args.validation_dir)
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
