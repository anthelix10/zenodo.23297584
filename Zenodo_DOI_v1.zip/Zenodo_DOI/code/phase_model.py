#!/usr/bin/env python3
from __future__ import annotations

import argparse
import calendar
import importlib.util
import json
import math
import os
import sys
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Tuple

import numpy as np
import pandas as pd
from numba import njit, prange, set_num_threads
from scipy.optimize import linprog
from scipy.sparse import lil_matrix, csr_matrix

# Numba uses the thread count configured by the execution environment.

ROOT = Path(__file__).resolve().parents[1]
WORK = Path(os.environ.get('BESS_PHASE_WORK', str(ROOT / '_work')))
BASE = ROOT
MASTER = ROOT / 'data' / 'operating' / 'renewable_bess_master_panel_all_rows.csv.gz'
OUT = Path(os.environ.get('BESS_PHASE_OUT', str(ROOT / 'results' / 'operating_phase')))
WORK.mkdir(parents=True, exist_ok=True)
OUT.mkdir(parents=True, exist_ok=True)

@dataclass(frozen=True)
class Cfg:
    operating_start: str = '2023-05-01'
    operating_end: str = '2025-11-30'
    hurdle_fraction: float = 0.70
    access: float = 0.50
    upside: float = 0.50
    margin: float = 0.05
    risk: float = 0.10
    bess_mw: float = 100.0
    renewable_mw: float = 25.0
    block_days: int = 14
    main_n: int = 20_000
    main_seed: int = 20260805
    main_step: float = 0.01
    nested_reps: int = 1_000
    nested_n: int = 500
    nested_seed: int = 20260804
    nested_step: float = 0.02
    permutation_reps: int = 100
    permutation_n: int = 1_500
    permutation_seed: int = 20261201
    permutation_step: float = 0.02

CFG = Cfg()
MONTH_DAYS = {m: calendar.monthrange(2023, m)[1] for m in range(1, 13)}
MONTH_DAYS[2] = 28

# ---------------- live annual-floor engine ----------------
@njit(cache=True, nogil=True)
def expected_shortfall_numba(loss: np.ndarray) -> float:
    n = loss.size
    k = int(math.ceil(0.05 * n))
    ordered = np.partition(loss, n-k)
    s = 0.0
    for i in range(n-k, n):
        s += ordered[i]
    return s/k

@njit(cache=True, nogil=True)
def supportable_floor_one(bess: np.ndarray, renewable: np.ndarray,
                          access: float, upside: float,
                          margin_rate: float, risk_fraction: float) -> float:
    n = bess.size
    risk_budget = risk_fraction * bess.mean()
    lo = 0.0
    hi = max(bess.max() + access * max(renewable.max(), 0.0), 3.0*bess.mean())
    losses = np.empty(n)
    for _ in range(40):
        f = 0.5*(lo+hi)
        ps = 0.0
        for i in range(n):
            if bess[i] >= f:
                p = access*renewable[i] + upside*(bess[i]-f)
            else:
                p = access*renewable[i] - (f-bess[i])
            ps += p
            losses[i] = max(-p, 0.0)
        es = expected_shortfall_numba(losses)
        feasible = ps/n >= margin_rate*f and es <= risk_budget
        if feasible:
            lo = f
        else:
            hi = f
    return lo

@njit(cache=True, parallel=True, nogil=True)
def supportable_floors(bess: np.ndarray, wind: np.ndarray, solar: np.ndarray,
                       weights: np.ndarray, access: float, upside: float,
                       margin_rate: float, risk_fraction: float) -> np.ndarray:
    out = np.empty(weights.size)
    for j in prange(weights.size):
        out[j] = supportable_floor_one(
            bess, weights[j]*wind + (1.0-weights[j])*solar,
            access, upside, margin_rate, risk_fraction
        )
    return out

@njit(cache=True, nogil=True)
def margin_only_floor(bess: np.ndarray, renewable: np.ndarray,
                      access: float, upside: float, margin_rate: float) -> float:
    lo = 0.0
    hi = max(bess.max() + access*max(renewable.max(), 0.0), 3.0*bess.mean())
    n = bess.size
    for _ in range(50):
        f = 0.5*(lo+hi)
        ps = 0.0
        for i in range(n):
            if bess[i] >= f:
                ps += access*renewable[i] + upside*(bess[i]-f)
            else:
                ps += access*renewable[i] - (f-bess[i])
        if ps/n >= margin_rate*f:
            lo = f
        else:
            hi = f
    return lo

@njit(cache=True, nogil=True)
def es_at_floor(bess: np.ndarray, renewable: np.ndarray, floor: float,
                access: float, upside: float) -> float:
    n = bess.size
    loss = np.empty(n)
    for i in range(n):
        if bess[i] >= floor:
            p = access*renewable[i] + upside*(bess[i]-floor)
        else:
            p = access*renewable[i] - (floor-bess[i])
        loss[i] = max(-p, 0.0)
    return expected_shortfall_numba(loss)

@dataclass
class BlockSet:
    b: np.ndarray
    w: np.ndarray
    s: np.ndarray
    source_days: np.ndarray
    target_days: int


def complete_month_panel(df: pd.DataFrame) -> pd.DataFrame:
    x = df.copy()
    x['year'] = x['date'].dt.year
    x['month'] = x['date'].dt.month
    counts = x.groupby(['year','month'])['date'].nunique()
    accepted = {(int(y), int(m)) for (y,m),c in counts.items()
                if int(c) >= calendar.monthrange(int(y), int(m))[1]-1}
    keep = [(int(y),int(m)) in accepted for y,m in zip(x['year'],x['month'])]
    return x[keep].sort_values('date').reset_index(drop=True)


def load_live_panel(bess_daily: pd.DataFrame | None = None,
                    wind_col: str = 'live_wind_index_cash_per_mw_gbp',
                    solar_col: str = 'live_solar_primary_cash_per_mw_gbp') -> pd.DataFrame:
    live = pd.read_csv(BASE/'data/operating/live_technology_indices_daily.csv', parse_dates=['date'])
    if bess_daily is None:
        b = pd.read_csv(BASE/'data/operating/reference_daily_cash.csv.gz', parse_dates=['date'])
        b['date'] = pd.DatetimeIndex(b['date']).tz_localize(None)
        b = b[['date','bess_cash_gbp']]
    else:
        b = bess_daily.copy()
        b['date'] = pd.to_datetime(b['date']).dt.tz_localize(None)
    x = b.merge(live[['date',wind_col,solar_col,'periods']], on='date', how='inner')
    x = x[(x['date']>=pd.Timestamp(CFG.operating_start)) &
          (x['date']<=pd.Timestamp(CFG.operating_end)) & (x['periods']>=48)].copy()
    x = x.rename(columns={wind_col:'wind_gross', solar_col:'solar_gross'})
    return complete_month_panel(x)


def build_blocks(panel: pd.DataFrame, block_days: int = 14) -> Dict[int, BlockSet]:
    out: Dict[int, BlockSet] = {}
    for month in range(1,13):
        sub = panel[panel['month']==month].sort_values(['year','date'])
        ba=[]; wa=[]; sa=[]; da=[]
        for _,g in sub.groupby('year'):
            b=g['bess_cash_gbp'].to_numpy(float)
            w=g['wind_gross'].to_numpy(float)
            s=g['solar_gross'].to_numpy(float)
            n=len(g)
            if n<7:
                continue
            ix=(np.arange(n)[:,None]+np.arange(block_days)[None,:])%n
            ba.append(b[ix]);wa.append(w[ix]);sa.append(s[ix]);da.append(np.full(n,n,dtype=float))
        if not ba:
            raise RuntimeError(f'No blocks for month {month}')
        out[month]=BlockSet(np.concatenate(ba),np.concatenate(wa),np.concatenate(sa),
                            np.concatenate(da),MONTH_DAYS[month])
    return out


def historical_hurdle(panel: pd.DataFrame, fraction: float=CFG.hurdle_fraction) -> Tuple[np.ndarray,np.ndarray]:
    mt = panel.groupby(['year','month'])[['wind_gross','solar_gross']].sum()
    clim = mt.groupby('month').mean().reindex(range(1,13))
    return fraction*clim['wind_gross'].to_numpy(float), fraction*clim['solar_gross'].to_numpy(float)


def draw_monthly_gross(blocks: Dict[int,BlockSet], n: int, seed: int,
                       independent_renewable: bool=False) -> Tuple[np.ndarray,np.ndarray,np.ndarray]:
    rng=np.random.default_rng(seed)
    b=np.zeros((n,12));w=np.zeros((n,12));s=np.zeros((n,12))
    for month in range(1,13):
        z=blocks[month]; nb=math.ceil(z.target_days/z.b.shape[1])
        ib=rng.integers(0,len(z.b),size=(n,nb))
        ir=(rng.integers(0,len(z.b),size=(n,nb)) if independent_renewable else ib)
        b[:,month-1]=z.b[ib].reshape(n,-1)[:,:z.target_days].sum(axis=1)
        w[:,month-1]=z.w[ir].reshape(n,-1)[:,:z.target_days].sum(axis=1)
        s[:,month-1]=z.s[ir].reshape(n,-1)[:,:z.target_days].sum(axis=1)
    return b,w,s


def draw_annual_right(blocks: Dict[int,BlockSet], n: int, seed: int,
                      hurdle_w: np.ndarray, hurdle_s: np.ndarray,
                      right: str, independent_renewable: bool=False) -> Tuple[np.ndarray,np.ndarray,np.ndarray]:
    rng=np.random.default_rng(seed)
    b=np.zeros(n);w=np.zeros(n);s=np.zeros(n)
    for month in range(1,13):
        z=blocks[month]; nb=math.ceil(z.target_days/z.b.shape[1])
        ib=rng.integers(0,len(z.b),size=(n,nb))
        ir=(rng.integers(0,len(z.b),size=(n,nb)) if independent_renewable else ib)
        bdays=z.b[ib].reshape(n,-1)[:,:z.target_days]
        wr=z.w[ir].reshape(n,-1)[:,:z.target_days]
        sr=z.s[ir].reshape(n,-1)[:,:z.target_days]
        # The contractual calendar-month benchmark is fixed before evaluation.
        # It is prorated over the number of observed days in the source month,
        # matching the paper's daily residual definition.
        div=np.repeat(z.source_days[ir], z.b.shape[1], axis=1)[:,:z.target_days]
        wr=wr-hurdle_w[month-1]/div
        sr=sr-hurdle_s[month-1]/div
        if right=='surplus':
            wr=np.maximum(wr,0.0); sr=np.maximum(sr,0.0)
        elif right=='gross':
            wr=z.w[ir].reshape(n,-1)[:,:z.target_days]
            sr=z.s[ir].reshape(n,-1)[:,:z.target_days]
        elif right!='signed':
            raise ValueError(right)
        b += bdays.sum(axis=1); w += wr.sum(axis=1); s += sr.sum(axis=1)
    return b,w,s


def calibrate_hurdle_from_selection(blocks: Dict[int,BlockSet], n: int, seed: int) -> Tuple[np.ndarray,np.ndarray]:
    _,wm,sm=draw_monthly_gross(blocks,n,seed,False)
    return CFG.hurdle_fraction*wm.mean(axis=0), CFG.hurdle_fraction*sm.mean(axis=0)


def frontier(blocks: Dict[int,BlockSet], right: str, n: int, seed: int,
             hurdle_w: np.ndarray, hurdle_s: np.ndarray,
             step: float=CFG.main_step, access: float=CFG.access,
             risk: float=CFG.risk, margin: float=CFG.margin,
             upside: float=CFG.upside,
             target_admitted: float | None=None,
             equal_support: bool=True,
             independent_renewable: bool=False) -> Tuple[pd.DataFrame,dict,Tuple[np.ndarray,np.ndarray,np.ndarray]]:
    b,w0,s0=draw_annual_right(blocks,n,seed,hurdle_w,hurdle_s,right,independent_renewable)
    if target_admitted is not None:
        target_per_mw = target_admitted/(access*CFG.renewable_mw)
    elif equal_support:
        target_per_mw = 0.5*(w0.mean()+s0.mean())
    else:
        target_per_mw = None
    if target_per_mw is None:
        aw=ass=1.0
    else:
        aw=target_per_mw/w0.mean();ass=target_per_mw/s0.mean()
    W=CFG.renewable_mw*aw*w0; S=CFG.renewable_mw*ass*s0
    weights=np.round(np.arange(0,1+step/2,step),10)
    f=supportable_floors(b,W,S,weights,access,upside,margin,risk)/CFG.bess_mw
    i=int(np.argmax(f)); ep=max(f[0],f[-1]); near=weights[f>=0.999*f[i]]
    df=pd.DataFrame({'wind_revenue_exposure':weights,'floor_gbp_per_bess_mw_year':f})
    summary={
        'right':right,'n_scenarios':n,'seed':seed,'access':access,'risk_fraction':risk,
        'best_wind_exposure':float(weights[i]),'best_floor':float(f[i]),
        'all_solar':float(f[0]),'all_wind':float(f[-1]),'udp':float(f[i]-ep),
        'near_min':float(near.min()),'near_max':float(near.max()),
        'wind_mean_before_scale':float(w0.mean()),'solar_mean_before_scale':float(s0.mean()),
        'target_per_mw':None if target_per_mw is None else float(target_per_mw),
        'wind_scale':float(aw),'solar_scale':float(ass),
        'common_support_gbp_year':None if target_per_mw is None else float(CFG.renewable_mw*target_per_mw),
        'admitted_common_support_gbp_year':None if target_per_mw is None else float(access*CFG.renewable_mw*target_per_mw),
    }
    return df,summary,(b,W,S)


def nested_evaluation(blocks: Dict[int,BlockSet], right: str, reps: int, n: int,
                      base_seed: int, step: float) -> Tuple[pd.DataFrame,dict]:
    weights=np.round(np.arange(0,1+step/2,step),10)
    rows=[]
    for rep in range(reps):
        ss=base_seed+10000+rep*2; es=ss+1
        hw,hs=calibrate_hurdle_from_selection(blocks,n,ss)
        bs,w0s,s0s=draw_annual_right(blocks,n,ss,hw,hs,right)
        be,w0e,s0e=draw_annual_right(blocks,n,es,hw,hs,right)
        target=0.5*(w0s.mean()+s0s.mean()); aw=target/w0s.mean(); ass=target/s0s.mean()
        Ws=CFG.renewable_mw*aw*w0s; Ss=CFG.renewable_mw*ass*s0s
        We=CFG.renewable_mw*aw*w0e; Se=CFG.renewable_mw*ass*s0e
        fs=supportable_floors(bs,Ws,Ss,weights,CFG.access,CFG.upside,CFG.margin,CFG.risk)
        fe=supportable_floors(be,We,Se,weights,CFG.access,CFG.upside,CFG.margin,CFG.risk)
        chosen=int(np.argmax(fs)); oracle=int(np.argmax(fe))
        rows.append({
            'replicate':rep+1,'selected_wind_exposure':float(weights[chosen]),
            'evaluation_floor_selected':float(fe[chosen]/CFG.bess_mw),
            'evaluation_floor_all_solar':float(fe[0]/CFG.bess_mw),
            'evaluation_floor_all_wind':float(fe[-1]/CFG.bess_mw),
            'evaluation_udp':float((fe[chosen]-max(fe[0],fe[-1]))/CFG.bess_mw),
            'evaluation_oracle_wind_exposure':float(weights[oracle]),
            'selection_wind_scale':float(aw),'selection_solar_scale':float(ass),
            'selection_hurdle_w_jan':float(hw[0]),'selection_hurdle_s_jan':float(hs[0]),
        })
        if (rep+1)%100==0:
            print(f'nested {right}: {rep+1}/{reps}',flush=True)
    d=pd.DataFrame(rows); pos=int((d.evaluation_udp>0).sum())
    summary={'right':right,'replicates':reps,'positive_count':pos,'positive_rate':pos/reps,
             'median_udp':float(d.evaluation_udp.median()),'p10_udp':float(d.evaluation_udp.quantile(.1)),
             'p90_udp':float(d.evaluation_udp.quantile(.9)),
             'p10_weight':float(d.selected_wind_exposure.quantile(.1)),
             'median_weight':float(d.selected_wind_exposure.median()),
             'p90_weight':float(d.selected_wind_exposure.quantile(.9))}
    return d,summary


def daily_right(panel: pd.DataFrame, hw: np.ndarray, hs: np.ndarray, right: str) -> pd.DataFrame:
    x=panel.copy()
    counts=x.groupby(['year','month'])['date'].transform('count').to_numpy(float)
    w=x.wind_gross.to_numpy(float)-hw[x.month.to_numpy()-1]/counts
    s=x.solar_gross.to_numpy(float)-hs[x.month.to_numpy()-1]/counts
    if right=='surplus': w=np.maximum(w,0);s=np.maximum(s,0)
    elif right=='gross':w=x.wind_gross.to_numpy(float);s=x.solar_gross.to_numpy(float)
    x['wind_right']=w;x['solar_right']=s
    return x


def tail_ratio(panel_right: pd.DataFrame) -> dict:
    b=panel_right.bess_cash_gbp.to_numpy(float)
    q=np.quantile(b,.1); mask=b<=q
    out={}
    for tech in ['wind','solar']:
        r=panel_right[f'{tech}_right'].to_numpy(float)
        out[f'{tech}_ratio']=float(r[mask].mean()/r.mean())
    return out


def block_tail_bootstrap(panel_right: pd.DataFrame,reps:int=2000,seed:int=20261202) -> Tuple[pd.DataFrame,dict]:
    b=panel_right.bess_cash_gbp.to_numpy(float);w=panel_right.wind_right.to_numpy(float);s=panel_right.solar_right.to_numpy(float)
    n=len(b);nb=math.ceil(n/CFG.block_days);rng=np.random.default_rng(seed);starts=rng.integers(0,n,size=(reps,nb));offs=np.arange(CFG.block_days)
    rows=[]
    def rat(bb,rr):
        m=bb<=np.quantile(bb,.1);return rr[m].mean()/rr.mean()
    for rep in range(reps):
        ix=((starts[rep,:,None]+offs[None,:])%n).reshape(-1)[:n]
        rows.append((rat(b[ix],w[ix]),rat(b[ix],s[ix])))
    d=pd.DataFrame(rows,columns=['wind_ratio','solar_ratio']);obs=tail_ratio(panel_right)
    summary={**obs,'wind_ci_low':float(d.wind_ratio.quantile(.025)),'wind_ci_high':float(d.wind_ratio.quantile(.975)),
             'solar_ci_low':float(d.solar_ratio.quantile(.025)),'solar_ci_high':float(d.solar_ratio.quantile(.975))}
    return d,summary


def timing_block_null(blocks: Dict[int,BlockSet], right: str, hw: np.ndarray, hs: np.ndarray,
                      reps:int,n:int,seed:int,step:float) -> Tuple[pd.DataFrame,dict]:
    weights=np.round(np.arange(0,1+step/2,step),10)
    b,w0,s0=draw_annual_right(blocks,n,seed,hw,hs,right,False)
    target=.5*(w0.mean()+s0.mean());W=CFG.renewable_mw*w0*target/w0.mean();S=CFG.renewable_mw*s0*target/s0.mean()
    fo=supportable_floors(b,W,S,weights,CFG.access,CFG.upside,CFG.margin,CFG.risk)/CFG.bess_mw
    obs=float(fo.max()-max(fo[0],fo[-1])); vals=[]
    for rep in range(reps):
        bn,wn,sn=draw_annual_right(blocks,n,seed+1000+rep,hw,hs,right,True)
        # Freeze the observed normalisation factors; only the aligned timing is broken.
        Wn=CFG.renewable_mw*wn*target/w0.mean();Sn=CFG.renewable_mw*sn*target/s0.mean()
        fn=supportable_floors(bn,Wn,Sn,weights,CFG.access,CFG.upside,CFG.margin,CFG.risk)/CFG.bess_mw
        vals.append(float(fn.max()-max(fn[0],fn[-1])))
        if (rep+1)%100==0: print(f'timing null {rep+1}/{reps}',flush=True)
    d=pd.DataFrame({'replicate':np.arange(1,reps+1),'udp':vals})
    p=(1+int((d.udp>=obs).sum()))/(reps+1)
    return d,{'observed_udp':obs,'null_median':float(d.udp.median()),'null_p95':float(d.udp.quantile(.95)),'p_value':p,'reps':reps,
              'null_design':'calendar-month-stratified independent 14-day blocks; wind and solar sampled jointly'}

# ---------------- alternative BESS schedules ----------------
def make_lp_mats(T:int,P:float=100.,E:float=200.,purch:float=60.,sale:float=70.,eta:float=math.sqrt(.93),dt:float=.5):
    n=3*T;Aeq=lil_matrix((T+1,n));beq=np.zeros(T+1)
    for t in range(T):
        Aeq[t,t]=-eta*dt;Aeq[t,T+t]=dt/eta;Aeq[t,2*T+t]=1
        if t>0:Aeq[t,2*T+t-1]=-1
    Aeq[T,3*T-1]=1
    Aub=lil_matrix((T,n));bub=np.full(T,P)
    for t in range(T):Aub[t,t]=1;Aub[t,T+t]=1
    bounds=[(0,purch)]*T+[(0,sale)]*T+[(0,E)]*T
    return csr_matrix(Aeq),beq,csr_matrix(Aub),bub,bounds


def generate_alternative_bess_daily() -> Tuple[pd.DataFrame,pd.DataFrame]:
    p=BASE/'data/operating/live_technology_indices_period.csv.gz';df=pd.read_csv(p)
    df['date']=pd.to_datetime(df.date);df=df.sort_values(['date','settlement_period']).reset_index(drop=True)
    df['ts']=df.date+pd.to_timedelta((df.settlement_period-1)*30,unit='m');df=df.set_index('ts')
    actual=df.price_actual.astype(float)
    frame=pd.DataFrame({'p':actual.values,'sp':df.settlement_period.values},index=df.index)
    season=np.full(len(frame),np.nan)
    for sp,g in frame.groupby('sp'):
        idx=g.index;vals=g.p.shift(2).rolling(28,min_periods=7).median();season[frame.index.get_indexer(idx)]=vals.values
    season=pd.Series(season,index=df.index).fillna(actual.shift(96)).fillna(actual.expanding().mean().shift(1)).fillna(actual.iloc[0])
    lag2=actual.shift(96).fillna(actual.expanding().mean().shift(1)).fillna(actual.iloc[0])
    forecasts={'two_day_lag':lag2,'seasonal_28d':season}
    cache={};rows=[];daily=[];eta=math.sqrt(.93);dt=.5;cost=4.25;E=200.
    for name,fc in forecasts.items():
        n=len(df);ch=np.zeros(n);dis=np.zeros(n);soc=.5*E;h=96;execute=48
        for st in range(0,n,execute):
            stop=min(n,st+h);T=stop-st
            if T not in cache:cache[T]=make_lp_mats(T)
            Aeq,b0,Aub,bub,bounds=cache[T];bv=b0.copy();bv[0]=soc;bv[T]=soc
            pf=fc.iloc[st:stop].to_numpy();obj=np.r_[(pf+cost)*dt,(-pf+cost)*dt,np.zeros(T)]
            r=linprog(obj,A_ub=Aub,b_ub=bub,A_eq=Aeq,b_eq=bv,bounds=bounds,method='highs')
            if not r.success:raise RuntimeError(r.message)
            c=r.x[:T];d=r.x[T:2*T];s=r.x[2*T:];k=min(execute,T)
            ch[st:st+k]=c[:k];dis[st:st+k]=d[:k];soc=float(s[k-1])
        cash=(actual.to_numpy()*(dis-ch)-cost*(ch+dis))*dt
        sim=np.minimum(ch,dis)*dt
        tmp=pd.DataFrame({'date':df.date.values,'cash':cash}).groupby('date',as_index=False).cash.sum().rename(columns={'cash':'bess_cash_gbp'})
        tmp['strategy']=name;daily.append(tmp)
        rows.append({'strategy':name,'periods':n,'annual_cash_gbp':float(cash.sum()/(n/(48*365.25))),
                     'simultaneous_periods':int((sim>1e-8).sum()),'simultaneous_mwh':float(sim.sum()),
                     'forecast_mae':float(np.mean(np.abs(fc.to_numpy()-actual.to_numpy()))),
                     'forecast_rmse':float(np.sqrt(np.mean((fc.to_numpy()-actual.to_numpy())**2)))})
    return pd.concat(daily,ignore_index=True),pd.DataFrame(rows)

# ---------------- national comparable wind/solar index ----------------
def build_national_daily(reference_dates: pd.Series | None = None) -> pd.DataFrame:
    use=['start_time','settlement_date','settlement_period','mid_combined_price_gbp_mwh','system_sell_price','system_buy_price',
         'neso_embedded_wind_generation_mw','neso_embedded_wind_capacity_mw','neso_embedded_solar_generation_mw','neso_embedded_solar_capacity_mw']
    d=pd.read_csv(MASTER,usecols=use,parse_dates=['start_time','settlement_date'])
    price=pd.to_numeric(d.mid_combined_price_gbp_mwh,errors='coerce')
    sysprice=pd.concat([pd.to_numeric(d.system_sell_price,errors='coerce'),pd.to_numeric(d.system_buy_price,errors='coerce')],axis=1).mean(axis=1)
    d['price']=price.fillna(sysprice)
    for c in ['price','neso_embedded_wind_generation_mw','neso_embedded_wind_capacity_mw','neso_embedded_solar_generation_mw','neso_embedded_solar_capacity_mw']:
        d[c]=pd.to_numeric(d[c],errors='coerce')
    wcf=(d.neso_embedded_wind_generation_mw/d.neso_embedded_wind_capacity_mw).clip(0,1.05)
    scf=(d.neso_embedded_solar_generation_mw/d.neso_embedded_solar_capacity_mw).clip(0,1.05)
    d['wind_gross']=wcf*d.price*.5;d['solar_gross']=scf*d.price*.5
    d['date']=pd.to_datetime(d.settlement_date).dt.tz_localize(None)
    dd=d.groupby('date',as_index=False).agg(wind_gross=('wind_gross','sum'),solar_gross=('solar_gross','sum'),periods=('settlement_period','nunique'))
    b=pd.read_csv(BASE/'data/operating/reference_daily_cash.csv.gz',parse_dates=['date']);b['date']=pd.DatetimeIndex(b.date).tz_localize(None)
    x=b[['date','bess_cash_gbp']].merge(dd,on='date')
    x=x[(x.date>=pd.Timestamp(CFG.operating_start))&(x.date<=pd.Timestamp(CFG.operating_end))&(x.periods>=48)]
    if reference_dates is not None:
        x=x[x.date.isin(pd.DatetimeIndex(reference_dates))].copy()
    return complete_month_panel(x)

# ---------------- phase boundary ----------------
def phase_boundary(scenarios: Tuple[np.ndarray,np.ndarray,np.ndarray], step=.02) -> Tuple[pd.DataFrame,pd.DataFrame]:
    b,W,S=scenarios; weights=np.round(np.arange(0,1+step/2,step),10)
    thresholds=[];curves=[]
    for access in [0.25,0.50,0.75]:
        # Margin-only floor is weight-invariant because E[W]=E[S].
        rmid=.5*W+.5*S
        gm=margin_only_floor(b,rmid,access,CFG.upside,CFG.margin)
        es=[]
        for w in weights:
            es.append(es_at_floor(b,w*W+(1-w)*S,gm,access,CFG.upside))
        critical=max(es)/b.mean()
        thresholds.append({'accessible_share':access,'critical_es95_fraction':critical,
                           'margin_only_floor':gm/CFG.bess_mw,'max_es_at_margin_floor':max(es),
                           'weight_with_max_es':float(weights[int(np.argmax(es))])})
        # Smooth diagnostic curve around the threshold.
        grid=np.unique(np.r_[np.arange(.02,.251,.01),max(.001,critical-.005),critical,critical+.005])
        for risk in sorted(grid):
            f=supportable_floors(b,W,S,weights,access,CFG.upside,CFG.margin,float(risk))/CFG.bess_mw
            i=int(np.argmax(f));curves.append({'accessible_share':access,'risk_fraction':float(risk),
                                               'best_wind_exposure':float(weights[i]),'best_floor':float(f[i]),
                                               'udp':float(f[i]-max(f[0],f[-1]))})
    return pd.DataFrame(thresholds),pd.DataFrame(curves)

# ---------------- contract bridge and access region ----------------
def import_contract_model():
    p=BASE/'code/renewable_bess_full_pool_model.py'
    spec=importlib.util.spec_from_file_location('rbfp',p);m=importlib.util.module_from_spec(spec);sys.modules['rbfp']=m;spec.loader.exec_module(m);return m


def build_contract_components() -> pd.DataFrame:
    # Create expected original folder structure for the packaged master panel.
    bundle=WORK/'master_bundle';(bundle/'processed').mkdir(parents=True,exist_ok=True)
    target=bundle/'processed/renewable_bess_master_panel_all_rows.csv.gz'
    if not target.exists():
        import shutil;shutil.copy2(MASTER,target)
    m=import_contract_model();df=m.load_and_prepare_panel(bundle)
    ev=df.loc[pd.Timestamp('2020-01-01',tz='UTC'):pd.Timestamp('2025-12-31 23:30',tz='UTC')]
    _,wcash,_=m.renewable_output_and_cash(ev,1.0,equal_cash=True)
    _,scash,_=m.renewable_output_and_cash(ev,0.0,equal_cash=True)
    daily=pd.DataFrame({'date':ev.index.floor('D'),'wind_cash':wcash.to_numpy(),'solar_cash':scash.to_numpy()}).groupby('date',as_index=False).sum()
    daily['date']=pd.DatetimeIndex(daily.date).tz_localize(None)
    b=pd.read_csv(BASE/'data/contract/reference_daily_cash.csv.gz',parse_dates=['date'])
    b['date']=pd.DatetimeIndex(b.date).tz_localize(None)
    out=b[['date','bess_cash_gbp','renewable_gross_cash_gbp']].merge(daily,on='date',how='inner')
    out['reconstructed_60_40']=.6*out.wind_cash+.4*out.solar_cash
    return out


def candidate_blocks_contract(dates:pd.DatetimeIndex,years:np.ndarray,block_days:int=7):
    blocks={}
    for y in years:
        for m in range(1,13):
            idx=np.where((dates.year==y)&(dates.month==m))[0];c=[]
            for st in range(0,len(idx)-block_days+1):
                ii=idx[st:st+block_days];dd=dates[ii]
                if all((dd[j]-dd[j-1]).days==1 for j in range(1,len(dd))):c.append(ii)
            if not c:raise RuntimeError((y,m))
            blocks[(int(y),m)]=np.stack(c)
    return blocks


def generate_contract_components(data:pd.DataFrame,n:int,tenor:int,seed:int):
    dates=pd.DatetimeIndex(data.date);years=np.array(sorted(dates.year.unique()),dtype=int);blocks=candidate_blocks_contract(dates,years)
    b=data.bess_cash_gbp.to_numpy(float);w=data.wind_cash.to_numpy(float);s=data.solar_cash.to_numpy(float)
    ab=np.zeros((n,tenor));mw=np.zeros((n,tenor,12));ms=np.zeros((n,tenor,12))
    root=np.random.SeedSequence(seed);children=root.spawn(tenor*5)
    for y in range(tenor):
        rr=np.random.default_rng(children[5*y]);reg=rr.choice(years,size=n,replace=True);br=np.random.default_rng(children[5*y+1])
        for month in range(1,13):
            target=MONTH_DAYS[month];nb=math.ceil(target/7);bm=np.zeros(n);wm=np.zeros(n);sm=np.zeros(n)
            for regime in np.unique(reg):
                rows=np.where(reg==regime)[0];avail=blocks[(int(regime),month)];choices=br.integers(0,len(avail),size=(len(rows),nb));ix=avail[choices].reshape(len(rows),nb*7)[:,:target]
                bm[rows]=b[ix].sum(1);wm[rows]=w[ix].sum(1);sm[rows]=s[ix].sum(1)
            ab[:,y]+=bm;mw[:,y,month-1]=wm;ms[:,y,month-1]=sm
    return ab,mw,ms


def es_np(loss:np.ndarray,alpha=.95):
    k=max(1,int(math.ceil((1-alpha)*len(loss))));return float(np.partition(loss,len(loss)-k)[-k:].mean())


def contract_diagnostics(bess,admitted,upside=.5,margin_frac=.05,risk_frac=.1,liq_frac=2.,discount=.07):
    tenor=bess.shape[1];disc=1/(1+discount)**np.arange(1,tenor+1);ann=disc.sum();mean_b=float(bess.mean())
    # The ten-year access application fixes the absolute profitability hurdle at
    # margin_frac times mean annual BESS revenue; unlike the live one-year phase
    # module, it is not margin_frac times the solved guarantee.
    req=margin_frac*mean_b;riskcap=risk_frac*mean_b;liqcap=liq_frac*mean_b
    def diag(G):
        pc=admitted+upside*np.maximum(bess-G,0)-np.maximum(G-bess,0)
        pv=(pc*disc).sum(1)/ann;meanp=float(pv.mean());es=es_np(np.maximum(-pv,0));cum=np.cumsum(pc,axis=1);liq=float(np.quantile(np.maximum(-cum.min(1),0),.99))
        owner=G+(1-upside)*np.maximum(bess-G,0);opv=(owner*disc).sum(1)/ann;k=max(1,int(math.ceil(.05*len(opv))));oworst=float(np.partition(opv,k-1)[:k].mean())
        return (meanp>=req-1e-7 and es<=riskcap+1e-7 and liq<=liqcap+1e-7),meanp,es,liq,float(opv.mean()),oworst,float(np.quantile(opv,.05)),pc
    lo=0.;hi=max(1.,1.5*float(bess.mean()+admitted.mean()))
    while diag(hi)[0]:hi*=1.5
    for _ in range(45):
        mid=.5*(lo+hi)
        if diag(mid)[0]:lo=mid
        else:hi=mid
    feas,meanp,es,liq,omean,oworst,op5,pc=diag(lo)
    sl={'margin':meanp-req,'es95':riskcap-es,'liquidity':liqcap-liq};sc={'margin':max(req,1.),'es95':max(riskcap,1.),'liquidity':max(liqcap,1.)}
    bind=min(sl,key=lambda k:abs(sl[k]/sc[k]))
    return {'floor':lo/100,'guarantee':lo,'provider_margin':meanp,'provider_es95':es,'p99_liquidity':liq,'binding':bind,
            'mean_bess':mean_b,'mean_admitted':float(admitted.mean()),'owner_mean':omean,'owner_worst5_mean':oworst,'owner_p5':op5}


def monthly_reference(data:pd.DataFrame,wgt:float):
    x=data.copy();x['year']=x.date.dt.year;x['month']=x.date.dt.month;x['r']=wgt*x.wind_cash+(1-wgt)*x.solar_cash
    return x.groupby(['year','month']).r.sum().groupby('month').mean().reindex(range(1,13)).to_numpy(float)


def fixed_cash(monthly,ref,h):
    q=np.maximum(monthly-h*ref[None,None,:],0);return q.sum(2),float((q==0).mean()*100)

def prop_cash(monthly,a):
    q=a*np.maximum(monthly,0);return q.sum(2),float((q==0).mean()*100)

def match_h(monthly,ref,target):
    lo=0.;hi=2.
    for _ in range(60):
        mid=.5*(lo+hi);mean=fixed_cash(monthly,ref,mid)[0].mean()
        if mean>target:lo=mid
        else:hi=mid
    return .5*(lo+hi)


def contract_bridge_and_region(data:pd.DataFrame,n:int=50000,seeds=(20260803,20260804,20260805)):
    weights=[0.,.53,.60,1.];bridge=[];reference_runs=[]
    saved=None
    for seed in seeds:
        b,mw,ms=generate_contract_components(data,n,10,seed)
        if saved is None:saved=(b,mw,ms)
        for wgt in weights:
            monthly=wgt*mw+(1-wgt)*ms;ref=monthly_reference(data,wgt);prop,zp=prop_cash(monthly,.3);h=match_h(monthly,ref,prop.mean());fixed,zf=fixed_cash(monthly,ref,h)
            for rule,cash,z in [('matched_fixed',fixed,zf),('proportional',prop,zp)]:
                r=contract_diagnostics(b,cash)
                bridge.append({'seed':seed,'wind_exposure':wgt,'rule':rule,'matched_h':h if rule=='matched_fixed' else np.nan,'zero_months_pct':z,**r})
        # save reference w=.60 results for owner table
    bridge_df=pd.DataFrame(bridge)
    # Parameter region on first 50k path set, w=.60, alpha=.30 and mean-matched h.
    b,mw,ms=saved;wgt=.60;monthly=wgt*mw+(1-wgt)*ms;ref=monthly_reference(data,wgt);prop,zp=prop_cash(monthly,.3);h=match_h(monthly,ref,prop.mean());fixed,zf=fixed_cash(monthly,ref,h)
    region=[]
    for risk in [.05,.10,.20]:
        for liq in [.5,1.,2.,4.]:
            rf=contract_diagnostics(b,fixed,risk_frac=risk,liq_frac=liq);rp=contract_diagnostics(b,prop,risk_frac=risk,liq_frac=liq)
            region.append({'risk_fraction':risk,'liquidity_fraction':liq,'upside_share':.5,'matched_support':prop.mean(),
                           'fixed_floor':rf['floor'],'proportional_floor':rp['floor'],'difference':rp['floor']-rf['floor'],
                           'fixed_binding':rf['binding'],'proportional_binding':rp['binding']})
    support_rows=[]
    for alpha in [.15,.30,.45]:
        pp,zpp=prop_cash(monthly,alpha);hh=match_h(monthly,ref,pp.mean());ff,zff=fixed_cash(monthly,ref,hh)
        rf=contract_diagnostics(b,ff);rp=contract_diagnostics(b,pp)
        support_rows.append({'proportional_share':alpha,'matched_h':hh,'mean_support':pp.mean(),
                             'fixed_floor':rf['floor'],'proportional_floor':rp['floor'],'difference':rp['floor']-rf['floor'],
                             'fixed_zero_months':zff,'proportional_zero_months':zpp})
    pd.DataFrame(support_rows).to_csv(OUT/'access_rule_support_quantity.csv',index=False)
    upside_rows=[]
    for up in [.25,.5,.75]:
        rf=contract_diagnostics(b,fixed,upside=up);rp=contract_diagnostics(b,prop,upside=up)
        upside_rows.append({'upside_share':up,'fixed_floor':rf['floor'],'proportional_floor':rp['floor'],'difference':rp['floor']-rf['floor'],
                            'fixed_owner_mean':rf['owner_mean'],'proportional_owner_mean':rp['owner_mean'],
                            'fixed_owner_worst5':rf['owner_worst5_mean'],'proportional_owner_worst5':rp['owner_worst5_mean']})
    return bridge_df,pd.DataFrame(region),pd.DataFrame(upside_rows),pd.DataFrame(support_rows)


def aggregate_bridge(d:pd.DataFrame):
    cols=['floor','mean_admitted','provider_margin','provider_es95','p99_liquidity','owner_mean','owner_worst5_mean','owner_p5','zero_months_pct','matched_h']
    g=d.groupby(['wind_exposure','rule'])[cols].mean().reset_index()
    piv=g.pivot(index='wind_exposure',columns='rule',values='floor')
    diff=(piv['proportional']-piv['matched_fixed']).rename('proportional_minus_fixed')
    return g.merge(diff.reset_index(),on='wind_exposure')

# ---------------- main ----------------
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--quick',action='store_true');args=ap.parse_args()
    cfg=CFG
    if args.quick:
        main_n=3000;nested_reps=20;nested_n=200;perm_reps=20;perm_n=500;contract_n=3000;seeds=(20260803,)
    else:
        main_n=cfg.main_n;nested_reps=cfg.nested_reps;nested_n=cfg.nested_n;perm_reps=cfg.permutation_reps;perm_n=cfg.permutation_n;contract_n=20000;seeds=(20260803,20260804,20260805)
    t=time.time();summary={'config':asdict(CFG),'quick':args.quick}
    panel=load_live_panel();panel.to_csv(OUT/'operating_screened_live_panel.csv',index=False)
    blocks=build_blocks(panel);hw,hs=historical_hurdle(panel)
    pd.DataFrame({'month':range(1,13),'wind_hurdle_gbp_per_mw':hw,'solar_hurdle_gbp_per_mw':hs}).to_csv(OUT/'reference_exante_monthly_hurdle.csv',index=False)
    main_scen={}
    for right in ['signed','surplus']:
        d,s,sc=frontier(blocks,right,main_n,cfg.main_seed,hw,hs)
        d.to_csv(OUT/f'reference_{right}_frontier.csv',index=False);summary[f'reference_{right}']=s;main_scen[right]=sc
    # Fixed installed capacity under three revenue definitions.
    fixed=[]
    for right in ['gross','signed','surplus']:
        d,s,_=frontier(blocks,right,main_n,cfg.main_seed,hw,hs,equal_support=False)
        d.to_csv(OUT/f'fixed_capacity_{right}_frontier.csv',index=False);fixed.append(s)
    pd.DataFrame(fixed).to_csv(OUT/'fixed_capacity_three_definitions.csv',index=False);summary['fixed_capacity']=fixed
    seed_rows=[]
    for right in ['signed','surplus']:
        for seed in [CFG.main_seed,CFG.main_seed+1,CFG.main_seed+2]:
            _,ss,_=frontier(blocks,right,main_n,seed,hw,hs)
            seed_rows.append({'right':right,'seed':seed,**ss})
    pd.DataFrame(seed_rows).to_csv(OUT/'main_frontier_seed_stability.csv',index=False);summary['seed_stability']=seed_rows
    # Ex-ante frozen-hurdle resampling.
    nested_summ=[]
    for right in ['signed','surplus']:
        d,s=nested_evaluation(blocks,right,nested_reps,nested_n,cfg.nested_seed,cfg.nested_step)
        d.to_csv(OUT/f'exante_nested_{right}.csv',index=False);nested_summ.append(s)
    pd.DataFrame(nested_summ).to_csv(OUT/'exante_nested_summary.csv',index=False);summary['nested']=nested_summ
    # Tail and month-stratified block timing null for signed right.
    pr=daily_right(panel,hw,hs,'signed');boot,bs=block_tail_bootstrap(pr,reps=200 if args.quick else 2000);boot.to_csv(OUT/'signed_tail_bootstrap.csv',index=False);summary['signed_tail']=bs
    nul,ns=timing_block_null(blocks,'signed',hw,hs,perm_reps,perm_n,cfg.permutation_seed,cfg.permutation_step);nul.to_csv(OUT/'signed_month_stratified_timing_null.csv',index=False);summary['timing_null']=ns
    # Alternative BESS schedules.
    alt_daily,forecast_audit=generate_alternative_bess_daily();alt_daily.to_csv(OUT/'alternative_bess_daily_cash.csv',index=False);forecast_audit.to_csv(OUT/'alternative_bess_forecast_and_dispatch_audit.csv',index=False)
    alt_rows=[]
    for name,g in alt_daily.groupby('strategy'):
        pp=load_live_panel(g[['date','bess_cash_gbp']]);bb=build_blocks(pp);dd,ss,_=frontier(bb,'signed',main_n,cfg.main_seed,hw,hs);dd.to_csv(OUT/f'alternative_bess_{name}_signed_frontier.csv',index=False)
        tr=tail_ratio(daily_right(pp,hw,hs,'signed'));alt_rows.append({'strategy':name,**ss,**tr})
    # Add canonical tail/frontier.
    alt_rows.append({'strategy':'rolling_ridge',**summary['reference_signed'],**tail_ratio(pr)})
    pd.DataFrame(alt_rows).to_csv(OUT/'alternative_bess_allocation_and_tail.csv',index=False);summary['alternative_bess']=alt_rows
    # Comparable national wind/solar index.
    nat=build_national_daily(panel['date']);nat.to_csv(OUT/'national_comparable_wind_solar_daily.csv',index=False);nb=build_blocks(nat);nhw,nhs=historical_hurdle(nat)
    nd,nsum,_=frontier(nb,'signed',main_n,cfg.main_seed,nhw,nhs);nd.to_csv(OUT/'national_index_signed_frontier.csv',index=False)
    nr, nrs=nested_evaluation(nb,'signed',200 if args.quick else 500,nested_n,cfg.nested_seed+500000,cfg.nested_step);nr.to_csv(OUT/'national_index_exante_nested_signed.csv',index=False)
    summary['national_index']={'frontier':nsum,'nested':nrs,'days':len(nat)}
    # Continuous phase boundary from reference signed scenarios.
    th,cur=phase_boundary(main_scen['signed']);th.to_csv(OUT/'signed_critical_es95_boundaries.csv',index=False);cur.to_csv(OUT/'signed_phase_curves.csv',index=False);summary['phase_thresholds']=th.to_dict('records')
    # Contract cross-module bridge and access parameter region.
    comp=build_contract_components();comp.to_csv(OUT/'contract_wind_solar_daily_components.csv',index=False)
    recon=float(np.max(np.abs(comp.reconstructed_60_40-comp.renewable_gross_cash_gbp)));summary['contract_reconstruction_max_abs_daily_diff']=recon
    bridge,region,ups,supportq=contract_bridge_and_region(comp,contract_n,seeds);bridge.to_csv(OUT/'contract_bridge_run_level.csv',index=False);region.to_csv(OUT/'access_rule_parameter_region.csv',index=False);ups.to_csv(OUT/'access_rule_upside_and_owner_metrics.csv',index=False)
    agg=aggregate_bridge(bridge);agg.to_csv(OUT/'contract_bridge_summary.csv',index=False);summary['contract_bridge']=agg.to_dict('records');summary['access_region']=region.to_dict('records');summary['upside_owner']=ups.to_dict('records');summary['support_quantity']=supportq.to_dict('records')
    summary['runtime_seconds']=time.time()-t
    (OUT/'phase_analysis_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
