#!/usr/bin/env python3
"""One-year reserve, self-liquidating bridge, and 1-10 year horizon tests.

The annual provider-cash definition is identical to the retained-reserve paper.
Three liquidity policies are compared on common path prefixes:

* unlimited_reserve: positive account cash is retained through the full contract.
* one_year_reserve: positive cash generated in year t may support year t+1 only;
  any unused amount is distributed after the next annual settlement.
* one_year_reserve_bridge: the one-year reserve rule plus a bridge for any remaining
  annual shortfall. Each draw must be fully repaid at the next annual settlement;
  refinancing is not allowed and no draw may remain outstanding at maturity.

The bridge analysis is a gross liquidity-capacity diagnostic. Interest, commitment
fees and fair-value pricing are deliberately outside this focused extension.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))
import run_retained_reserve_analysis as rr  # noqa: E402

TOL = 1e-8
POLICIES = ("unlimited_reserve", "one_year_reserve", "one_year_reserve_bridge")
CASES = ("bess_only", "signed", "surplus_only")


def provider_cash(bess: np.ndarray, renewable: np.ndarray, guarantee: float) -> np.ndarray:
    """Annual provider cash before reserve/bridge financing."""
    return (
        renewable
        + rr.PROVIDER_UPSIDE_SHARE * np.maximum(bess - guarantee, 0.0)
        - np.maximum(guarantee - bess, 0.0)
    )


def unlimited_reserve_diagnostics(cash: np.ndarray) -> dict:
    cumulative = np.cumsum(np.asarray(cash, float), axis=1)
    minimum = cumulative.min(axis=1)
    solvent = minimum >= -TOL
    n, T = cumulative.shape
    return {
        "solvent": solvent,
        "reserve": cumulative,
        "distribution": np.zeros((n, T)),
        "bridge_draw": np.zeros((n, T)),
        "max_bridge": np.zeros(n),
        "bridge_used": np.zeros(n, dtype=bool),
        "duration_breach": ~solvent,
    }


def one_year_reserve_diagnostics(cash: np.ndarray) -> dict:
    """Only the immediately preceding year's positive cash remains available."""
    cash = np.asarray(cash, float)
    n, T = cash.shape
    reserve = np.zeros(n)
    solvent = np.ones(n, dtype=bool)
    reserve_hist = np.zeros((n, T))
    distribution = np.zeros((n, T))

    for t in range(T):
        c = cash[:, t]
        shortfall = np.maximum(-c, 0.0)
        uncovered = np.maximum(shortfall - reserve, 0.0)
        solvent &= uncovered <= TOL

        # The prior-year vintage expires after this settlement. Any unused amount
        # is distributable; only current-year positive cash becomes next year's reserve.
        distribution[:, t] = np.maximum(reserve - shortfall, 0.0)
        reserve = np.maximum(c, 0.0)
        reserve_hist[:, t] = reserve

    n, T = cash.shape
    return {
        "solvent": solvent,
        "reserve": reserve_hist,
        "distribution": distribution,
        "bridge_draw": np.zeros((n, T)),
        "max_bridge": np.zeros(n),
        "bridge_used": np.zeros(n, dtype=bool),
        "duration_breach": ~solvent,
    }


def one_year_bridge_diagnostics(cash: np.ndarray) -> dict:
    """One-year reserve plus bridge draws due at the next annual settlement.

    At settlement t, prior-year reserve and current positive provider cash first
    repay the bridge drawn at t-1. Failure to repay is a tenor breach; the path is
    not refinanced. Remaining prior-year reserve then covers the current shortfall.
    Any residual shortfall is a new bridge draw due at t+1. Only unused current-year
    positive cash is carried as the next reserve vintage. No bridge may remain at
    contract maturity in the main conservative specification.
    """
    cash = np.asarray(cash, float)
    n, T = cash.shape
    reserve = np.zeros(n)
    debt = np.zeros(n)
    active = np.ones(n, dtype=bool)
    solvent = np.ones(n, dtype=bool)
    duration_breach = np.zeros(n, dtype=bool)

    bridge_draw = np.zeros((n, T))
    max_bridge = np.zeros(n)
    reserve_hist = np.zeros((n, T))
    distribution = np.zeros((n, T))

    for t in range(T):
        c = cash[:, t]
        current_positive = np.maximum(c, 0.0)
        current_shortfall = np.maximum(-c, 0.0)
        old_reserve = reserve.copy()

        # Repay the bridge due now. Use the expiring reserve vintage first.
        repay_old = np.minimum(old_reserve, debt)
        old_reserve -= repay_old
        debt -= repay_old
        repay_current = np.minimum(current_positive, debt)
        current_positive -= repay_current
        debt -= repay_current

        late = active & (debt > TOL)
        solvent[late] = False
        duration_breach[late] = True
        active[late] = False

        # Continue the cash waterfall only on paths that remain compliant.
        cover = np.where(active, np.minimum(old_reserve, current_shortfall), 0.0)
        old_reserve -= cover
        current_shortfall -= cover

        new_draw = np.where(active, current_shortfall, 0.0)
        bridge_draw[:, t] = new_draw
        debt = np.where(active, new_draw, debt)
        max_bridge = np.maximum(max_bridge, np.where(active, debt, 0.0))

        distribution[:, t] = np.where(active, old_reserve, 0.0)
        reserve = np.where(active, current_positive, 0.0)
        reserve_hist[:, t] = reserve

    # Conservative maturity rule: final-year borrowing cannot be left for a
    # post-contract repayment year.
    final_outstanding = active & (debt > TOL)
    solvent[final_outstanding] = False
    duration_breach[final_outstanding] = True

    return {
        "solvent": solvent,
        "reserve": reserve_hist,
        "distribution": distribution,
        "bridge_draw": bridge_draw,
        "max_bridge": max_bridge,
        "bridge_used": max_bridge > TOL,
        "duration_breach": duration_breach,
    }


def policy_diagnostics(cash: np.ndarray, policy: str) -> dict:
    if policy == "unlimited_reserve":
        return unlimited_reserve_diagnostics(cash)
    if policy == "one_year_reserve":
        return one_year_reserve_diagnostics(cash)
    if policy == "one_year_reserve_bridge":
        return one_year_bridge_diagnostics(cash)
    raise ValueError(f"Unknown policy: {policy}")


def solve_floor(bess: np.ndarray, renewable: np.ndarray, policy: str, q: float = 0.95) -> dict:
    bess = np.asarray(bess, float)
    renewable = np.asarray(renewable, float)
    required_margin = rr.REQUIRED_MARGIN_FRACTION * float(bess.mean())

    def evaluate(guarantee: float):
        cash = provider_cash(bess, renewable, guarantee)
        diag = policy_diagnostics(cash, policy)
        solvency = float(diag["solvent"].mean())
        mean_cash = float(cash.mean())
        feasible = solvency >= q - 1e-12 and mean_cash >= required_margin - 1e-7
        return feasible, cash, diag, solvency, mean_cash

    lo = 0.0
    hi = max(1.0, 1.5 * float(bess.mean() + max(renewable.mean(), 0.0)))
    while evaluate(hi)[0]:
        hi *= 1.5
    for _ in range(44):
        mid = 0.5 * (lo + hi)
        if evaluate(mid)[0]:
            lo = mid
        else:
            hi = mid

    _, cash, diag, solvency, mean_cash = evaluate(lo)
    max_bridge = diag["max_bridge"] / rr.P_BESS_MW
    return {
        "floor_gbp_per_bess_mw_year": lo / rr.P_BESS_MW,
        "solvency_fraction": solvency,
        "mean_provider_cash_gbp_per_bess_mw_year": mean_cash / rr.P_BESS_MW,
        "mean_terminal_reserve_gbp_per_bess_mw": float(diag["reserve"][:, -1].mean() / rr.P_BESS_MW),
        "p95_max_bridge_gbp_per_bess_mw": float(np.quantile(max_bridge, 0.95)),
        "p99_max_bridge_gbp_per_bess_mw": float(np.quantile(max_bridge, 0.99)),
        "bridge_use_fraction": float(diag["bridge_used"].mean()),
        "duration_breach_fraction": float(diag["duration_breach"].mean()),
        "mean_annual_distribution_gbp_per_bess_mw": float(diag["distribution"].mean() / rr.P_BESS_MW),
        "first_year_negative_cash_fraction": float((cash[:, 0] < 0.0).mean()),
    }


def annual_arrays(panel: pd.DataFrame, n_paths: int, years: int, seed: int):
    scenarios = rr.draw_both_rights(panel, n_paths * years, seed)
    bess = np.asarray(scenarios.bess).reshape(n_paths, years)
    rights = {
        "bess_only": np.zeros_like(bess),
        "signed": (
            rr.ACCESS_REFERENCE * (0.5 * scenarios.wind_signed + 0.5 * scenarios.solar_signed)
        ).reshape(n_paths, years),
        "surplus_only": (
            rr.ACCESS_REFERENCE * (0.5 * scenarios.wind_surplus + 0.5 * scenarios.solar_surplus)
        ).reshape(n_paths, years),
    }
    return bess, rights


def run(n_paths: int = 20_000, years: int = 10) -> pd.DataFrame:
    duration_daily = rr.prepare_duration_daily(False)
    panel = rr.live_panel_for_duration(2, duration_daily)
    rows = []

    for seed in rr.SEEDS:
        bess_all, rights = annual_arrays(panel, n_paths, years, seed)
        for horizon in range(1, years + 1):
            bess = bess_all[:, :horizon]
            for case in CASES:
                renewable = rights[case][:, :horizon]
                for policy in POLICIES:
                    result = solve_floor(bess, renewable, policy)
                    rows.append(
                        {
                            "seed": seed,
                            "n_paths": n_paths,
                            "horizon_years": horizon,
                            "case": case,
                            "policy": policy,
                            **result,
                        }
                    )

    frame = pd.DataFrame(rows)
    base = frame[frame["case"] == "bess_only"][
        ["seed", "horizon_years", "policy", "floor_gbp_per_bess_mw_year"]
    ].rename(columns={"floor_gbp_per_bess_mw_year": "bess_only_floor"})
    frame = frame.merge(base, on=["seed", "horizon_years", "policy"], validate="many_to_one")
    frame["uplift_gbp_per_bess_mw_year"] = frame["floor_gbp_per_bess_mw_year"] - frame["bess_only_floor"]
    frame["uplift_fraction"] = frame["uplift_gbp_per_bess_mw_year"] / frame["bess_only_floor"]
    return frame


def summarise(frame: pd.DataFrame) -> pd.DataFrame:
    metrics = [
        "floor_gbp_per_bess_mw_year",
        "bess_only_floor",
        "uplift_gbp_per_bess_mw_year",
        "uplift_fraction",
        "solvency_fraction",
        "mean_provider_cash_gbp_per_bess_mw_year",
        "mean_terminal_reserve_gbp_per_bess_mw",
        "p95_max_bridge_gbp_per_bess_mw",
        "p99_max_bridge_gbp_per_bess_mw",
        "bridge_use_fraction",
        "duration_breach_fraction",
        "mean_annual_distribution_gbp_per_bess_mw",
        "first_year_negative_cash_fraction",
    ]
    rows = []
    for keys, group in frame.groupby(["horizon_years", "case", "policy"], sort=True):
        row = dict(zip(["horizon_years", "case", "policy"], keys))
        for metric in metrics:
            values = group[metric].to_numpy(float)
            row[f"{metric}_mean"] = float(values.mean())
            row[f"{metric}_sd"] = float(values.std(ddof=1))
            row[f"{metric}_min"] = float(values.min())
            row[f"{metric}_max"] = float(values.max())
        rows.append(row)
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--paths", type=int, default=20_000)
    parser.add_argument("--years", type=int, default=10)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "reproduced_results" / "one_year_liquidity")
    args = parser.parse_args()

    start = time.time()
    run_level = run(args.paths, args.years)
    summary = summarise(run_level)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    run_level.to_csv(args.output_dir / "one_year_liquidity_horizon_run_level.csv", index=False)
    summary.to_csv(args.output_dir / "one_year_liquidity_horizon_summary.csv", index=False)
    metadata = {
        "version": "1.9.1",
        "paths_per_seed": args.paths,
        "seeds": list(rr.SEEDS),
        "horizons": f"1-{args.years} year prefixes of common 10-year paths",
        "wind_revenue_exposure": 0.50,
        "renewable_access": rr.ACCESS_REFERENCE,
        "policies": list(POLICIES),
        "reserve_vintage": "positive annual provider cash may support the next annual settlement only; unused cash is then distributed",
        "bridge_tenor": "each draw must be fully repaid at the next annual settlement; no refinancing and no bridge outstanding at maturity",
        "bridge_costs": "gross diagnostic; interest and commitment fees excluded",
        "settlement": "annual",
        "elapsed_seconds": time.time() - start,
    }
    (args.output_dir / "one_year_liquidity_horizon_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    print(summary.to_string(index=False))
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
