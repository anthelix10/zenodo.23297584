#!/usr/bin/env python3
"""Focused contract-identification and robustness tests.

This script adds four deliberately narrow extensions to the renewable-backed BESS
floor analysis:

1. daily-settled versus monthly-settled surplus-only renewable rights;
2. one-, two-, three-, five-year and unlimited reserve-vintage retention under a
   50% first-year floor ramp, separating retention tenor from the zero-opening-
   reserve first-payment bottleneck;
3. contiguous 12-month regime-preserving annual windows, with optional rank
   persistence between contract years; and
4. provider BESS-upside-share and expected-margin sensitivities.

The extensions preserve the article's same-percentile comparison and do not add a
new revenue stack, structural price model or fair-value contract-pricing exercise.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from scipy.stats import norm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))

import phase_model as pm  # noqa: E402
import run_one_year_liquidity_horizons as liquidity  # noqa: E402
import run_retained_reserve_analysis as rr  # noqa: E402

Q = 0.95
TOL = 1e-8
DEFAULT_OUT = ROOT / "reproduced_results" / "contract_robustness"


@dataclass
class SettlementScenarioSet:
    bess: np.ndarray
    wind_daily_surplus: np.ndarray
    solar_daily_surplus: np.ndarray
    wind_monthly_surplus: np.ndarray
    solar_monthly_surplus: np.ndarray


def _equalise_pair(wind: np.ndarray, solar: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Scale wind and solar to equal expected cash at the 25 MW reference scale."""
    target = 0.5 * (float(wind.mean()) + float(solar.mean()))
    return (
        rr.RENEWABLE_REFERENCE_MW * target / float(wind.mean()) * wind,
        rr.RENEWABLE_REFERENCE_MW * target / float(solar.mean()) * solar,
    )


def draw_surplus_settlement_scenarios(
    panel: pd.DataFrame,
    n: int,
    seed: int,
    *,
    chunk: int = 25_000,
) -> SettlementScenarioSet:
    """Draw common annual scenarios under daily and monthly positive-part rules.

    The BESS, wind and solar blocks are identical across both contract definitions.
    The daily rule applies the positive part after prorating the monthly protected
    hurdle to each source day. The monthly rule first aggregates gross monthly cash
    and then applies the positive part to the monthly residual.
    """
    blocks = pm.build_blocks(panel)
    hurdle_w, hurdle_s = pm.historical_hurdle(panel, rr.HURDLE_FRACTION)
    rng = np.random.default_rng(seed)

    B = np.zeros(n, dtype=float)
    Wd = np.zeros(n, dtype=float)
    Sd = np.zeros(n, dtype=float)
    Wm = np.zeros(n, dtype=float)
    Sm = np.zeros(n, dtype=float)

    for month in range(1, 13):
        z = blocks[month]
        n_blocks = math.ceil(z.target_days / z.b.shape[1])
        for lo in range(0, n, chunk):
            hi = min(n, lo + chunk)
            rows = hi - lo
            choices = rng.integers(0, len(z.b), size=(rows, n_blocks))
            bdays = z.b[choices].reshape(rows, -1)[:, : z.target_days]
            wdays = z.w[choices].reshape(rows, -1)[:, : z.target_days]
            sdays = z.s[choices].reshape(rows, -1)[:, : z.target_days]
            source_days = np.repeat(
                z.source_days[choices], z.b.shape[1], axis=1
            )[:, : z.target_days]

            wind_daily_residual = wdays - hurdle_w[month - 1] / source_days
            solar_daily_residual = sdays - hurdle_s[month - 1] / source_days

            B[lo:hi] += bdays.sum(axis=1)
            Wd[lo:hi] += np.maximum(wind_daily_residual, 0.0).sum(axis=1)
            Sd[lo:hi] += np.maximum(solar_daily_residual, 0.0).sum(axis=1)
            Wm[lo:hi] += np.maximum(wdays.sum(axis=1) - hurdle_w[month - 1], 0.0)
            Sm[lo:hi] += np.maximum(sdays.sum(axis=1) - hurdle_s[month - 1], 0.0)

    Wd, Sd = _equalise_pair(Wd, Sd)
    Wm, Sm = _equalise_pair(Wm, Sm)
    return SettlementScenarioSet(B, Wd, Sd, Wm, Sm)


def _path_pair(
    scen: SettlementScenarioSet,
    n_paths: int,
    settlement: str,
    *,
    access_share: float = rr.ACCESS_REFERENCE,
    wind_weight: float = 0.50,
    multiplier: float = 1.0,
) -> tuple[np.ndarray, np.ndarray]:
    B = np.asarray(scen.bess, float).reshape(n_paths, rr.TENOR_YEARS)
    if settlement == "daily":
        W, S = scen.wind_daily_surplus, scen.solar_daily_surplus
    elif settlement == "monthly":
        W, S = scen.wind_monthly_surplus, scen.solar_monthly_surplus
    else:
        raise ValueError(settlement)
    R = (
        access_share
        * multiplier
        * (wind_weight * W + (1.0 - wind_weight) * S)
    ).reshape(n_paths, rr.TENOR_YEARS)
    return B, R


def run_settlement_frequency(panel: pd.DataFrame, n_paths: int) -> pd.DataFrame:
    rows: list[dict] = []
    for seed in rr.SEEDS:
        scen = draw_surplus_settlement_scenarios(
            panel, n_paths * rr.TENOR_YEARS, seed
        )
        B, R_daily = _path_pair(scen, n_paths, "daily")
        _, R_monthly = _path_pair(scen, n_paths, "monthly")
        base_unlimited = liquidity.solve_floor(B, np.zeros_like(B), "unlimited_reserve", Q)
        base_one_year = liquidity.solve_floor(B, np.zeros_like(B), "one_year_reserve", Q)

        mean_match_multiplier = float(R_daily.mean() / R_monthly.mean())
        cases = {
            "daily_pro_rata_50pct": (R_daily, rr.ACCESS_REFERENCE),
            "monthly_residual_50pct": (R_monthly, rr.ACCESS_REFERENCE),
            "monthly_mean_matched": (
                R_monthly * mean_match_multiplier,
                rr.ACCESS_REFERENCE * mean_match_multiplier,
            ),
        }
        for case, (R, effective_access) in cases.items():
            for policy, base in (
                ("unlimited_reserve", base_unlimited),
                ("one_year_reserve", base_one_year),
            ):
                result = liquidity.solve_floor(B, R, policy, Q)
                rows.append(
                    {
                        "seed": seed,
                        "n_paths": n_paths,
                        "case": case,
                        "settlement_rule": "daily" if case.startswith("daily") else "monthly",
                        "policy": policy,
                        "effective_access_share": effective_access,
                        "mean_match_multiplier": 1.0 if case != "monthly_mean_matched" else mean_match_multiplier,
                        "admitted_cash_gbp_per_bess_mw_year": float(R.mean() / rr.P_BESS_MW),
                        "bess_only_floor_gbp_per_bess_mw_year": base["floor_gbp_per_bess_mw_year"],
                        "floor_gbp_per_bess_mw_year": result["floor_gbp_per_bess_mw_year"],
                        "uplift_gbp_per_bess_mw_year": result["floor_gbp_per_bess_mw_year"] - base["floor_gbp_per_bess_mw_year"],
                        "uplift_fraction": result["floor_gbp_per_bess_mw_year"] / base["floor_gbp_per_bess_mw_year"] - 1.0,
                        "solvency_fraction": result["solvency_fraction"],
                    }
                )
    return pd.DataFrame(rows)


def finite_vintage_diagnostics(cash: np.ndarray, retention_years: int | None) -> dict:
    """Evaluate finite reserve vintages using an oldest-first cash waterfall."""
    cash = np.asarray(cash, float)
    n, T = cash.shape
    if retention_years is None:
        cumulative = np.cumsum(cash, axis=1)
        solvent = cumulative.min(axis=1) >= -TOL
        return {
            "solvent": solvent,
            "distribution": np.zeros_like(cash),
            "terminal_reserve": cumulative[:, -1],
        }

    k = int(retention_years)
    if k < 1:
        raise ValueError("retention_years must be positive or None")
    vintages = np.zeros((n, k), dtype=float)  # index 0 is oldest
    solvent = np.ones(n, dtype=bool)
    distribution = np.zeros_like(cash)

    for t in range(T):
        c = cash[:, t]
        shortfall = np.maximum(-c, 0.0)
        for j in range(k):
            use = np.minimum(vintages[:, j], shortfall)
            vintages[:, j] -= use
            shortfall -= use
        solvent &= shortfall <= TOL

        # The oldest vintage expires after this settlement.
        distribution[:, t] = vintages[:, 0]
        if k > 1:
            vintages[:, :-1] = vintages[:, 1:]
        vintages[:, -1] = np.maximum(c, 0.0)

    return {
        "solvent": solvent,
        "distribution": distribution,
        "terminal_reserve": vintages.sum(axis=1),
    }


def solve_scheduled_retention_floor(
    B: np.ndarray,
    R: np.ndarray,
    schedule: np.ndarray,
    retention_years: int | None,
    *,
    q: float = Q,
    provider_upside_share: float = rr.PROVIDER_UPSIDE_SHARE,
    required_margin_fraction: float = rr.REQUIRED_MARGIN_FRACTION,
) -> dict:
    B = np.asarray(B, float)
    R = np.asarray(R, float)
    schedule = np.asarray(schedule, float)
    if B.shape != R.shape or B.shape[1] != len(schedule):
        raise ValueError("B, R and schedule dimensions do not agree")
    required_margin = required_margin_fraction * float(B.mean())

    def evaluate(full_floor: float):
        G = full_floor * schedule[None, :]
        cash = (
            R
            + provider_upside_share * np.maximum(B - G, 0.0)
            - np.maximum(G - B, 0.0)
        )
        diag = finite_vintage_diagnostics(cash, retention_years)
        solvency = float(diag["solvent"].mean())
        mean_cash = float(cash.mean())
        feasible = solvency >= q - 1e-12 and mean_cash >= required_margin - 1e-7
        return feasible, cash, diag, solvency, mean_cash

    lo = 0.0
    hi = max(1.0, 1.5 * float(B.mean() + max(R.mean(), 0.0)))
    while evaluate(hi)[0]:
        hi *= 1.5
    for _ in range(44):
        mid = 0.5 * (lo + hi)
        if evaluate(mid)[0]:
            lo = mid
        else:
            hi = mid

    _, cash, diag, solvency, mean_cash = evaluate(lo)
    return {
        "full_floor_gbp_per_bess_mw_year": lo / rr.P_BESS_MW,
        "average_scheduled_floor_gbp_per_bess_mw_year": lo * float(schedule.mean()) / rr.P_BESS_MW,
        "solvency_fraction": solvency,
        "mean_provider_cash_gbp_per_bess_mw_year": mean_cash / rr.P_BESS_MW,
        "mean_annual_distribution_gbp_per_bess_mw": float(diag["distribution"].mean() / rr.P_BESS_MW),
        "mean_terminal_reserve_gbp_per_bess_mw": float(diag["terminal_reserve"].mean() / rr.P_BESS_MW),
        "first_year_negative_cash_fraction": float((cash[:, 0] < 0.0).mean()),
    }


def run_staged_retention(panel: pd.DataFrame, n_paths: int) -> pd.DataFrame:
    rows: list[dict] = []
    schedule = np.r_[0.50, np.ones(rr.TENOR_YEARS - 1)]
    windows: tuple[int | None, ...] = (1, 2, 3, 5, None)
    for seed in rr.SEEDS:
        scen = rr.draw_both_rights(panel, n_paths * rr.TENOR_YEARS, seed)
        B = rr.reshape_paths(scen.bess, n_paths)
        rights = {
            "bess_only": np.zeros_like(B),
            "signed": rr.path_arrays(scen, n_paths, "signed", 0.50)[1],
            "surplus_only": rr.path_arrays(scen, n_paths, "surplus_only", 0.50)[1],
        }
        for case, R in rights.items():
            for retention_years in windows:
                result = solve_scheduled_retention_floor(
                    B, R, schedule, retention_years
                )
                rows.append(
                    {
                        "seed": seed,
                        "n_paths": n_paths,
                        "case": case,
                        "retention_years": "unlimited" if retention_years is None else str(retention_years),
                        "retention_years_numeric": rr.TENOR_YEARS + 1 if retention_years is None else retention_years,
                        "first_year_floor_fraction": schedule[0],
                        "mean_schedule_fraction": float(schedule.mean()),
                        **result,
                    }
                )
    frame = pd.DataFrame(rows)
    unlimited = frame[frame["retention_years"] == "unlimited"][[
        "seed", "case", "full_floor_gbp_per_bess_mw_year",
        "average_scheduled_floor_gbp_per_bess_mw_year"
    ]].rename(columns={
        "full_floor_gbp_per_bess_mw_year": "unlimited_full_floor",
        "average_scheduled_floor_gbp_per_bess_mw_year": "unlimited_average_floor",
    })
    frame = frame.merge(unlimited, on=["seed", "case"], validate="many_to_one")
    frame["full_floor_retained_fraction"] = frame["full_floor_gbp_per_bess_mw_year"] / frame["unlimited_full_floor"]
    frame["average_floor_retained_fraction"] = frame["average_scheduled_floor_gbp_per_bess_mw_year"] / frame["unlimited_average_floor"]
    return frame


def build_contiguous_annual_window_library(
    panel: pd.DataFrame,
    *,
    baseline_draws: int = 100_000,
    baseline_seed: int = 20260815,
) -> pd.DataFrame:
    """Construct overlapping contiguous 12-calendar-month joint cash windows.

    Component means are rescaled to the month-stratified generator's annual means,
    so the stress changes annual coherence and variance rather than the expected
    cash level.
    """
    x = panel.copy().sort_values("date").reset_index(drop=True)
    hurdle_w, hurdle_s = pm.historical_hurdle(x, rr.HURDLE_FRACTION)
    counts = x.groupby(["year", "month"])["date"].transform("count").to_numpy(float)
    month_idx = x["month"].to_numpy(int) - 1
    wind_residual = x["wind_gross"].to_numpy(float) - hurdle_w[month_idx] / counts
    solar_residual = x["solar_gross"].to_numpy(float) - hurdle_s[month_idx] / counts
    x["wind_signed_raw"] = wind_residual
    x["solar_signed_raw"] = solar_residual
    x["wind_surplus_raw"] = np.maximum(wind_residual, 0.0)
    x["solar_surplus_raw"] = np.maximum(solar_residual, 0.0)
    x["ym"] = x["date"].dt.to_period("M")

    months = sorted(x["ym"].unique())
    rows: list[dict] = []
    for i in range(len(months) - 11):
        selected = months[i : i + 12]
        g = x[x["ym"].isin(selected)]
        if len(g) < 350:
            continue
        rows.append(
            {
                "window_id": len(rows),
                "start_month": str(selected[0]),
                "end_month": str(selected[-1]),
                "days": int(len(g)),
                "bess": float(g["bess_cash_gbp"].sum()),
                "wind_signed": float(g["wind_signed_raw"].sum()),
                "solar_signed": float(g["solar_signed_raw"].sum()),
                "wind_surplus": float(g["wind_surplus_raw"].sum()),
                "solar_surplus": float(g["solar_surplus_raw"].sum()),
            }
        )
    library = pd.DataFrame(rows)
    if len(library) < 10:
        raise RuntimeError("Too few contiguous 12-month windows")

    baseline = rr.draw_both_rights(panel, baseline_draws, baseline_seed)
    targets = {
        "bess": float(baseline.bess.mean()),
        "wind_signed": float(baseline.wind_signed.mean()),
        "solar_signed": float(baseline.solar_signed.mean()),
        "wind_surplus": float(baseline.wind_surplus.mean()),
        "solar_surplus": float(baseline.solar_surplus.mean()),
    }
    for column, target in targets.items():
        raw_mean = float(library[column].mean())
        library[column] *= target / raw_mean
        library[f"{column}_scale_to_baseline_mean"] = target / raw_mean

    library["signed_accessible"] = rr.ACCESS_REFERENCE * (
        0.50 * library["wind_signed"] + 0.50 * library["solar_signed"]
    )
    library["surplus_accessible"] = rr.ACCESS_REFERENCE * (
        0.50 * library["wind_surplus"] + 0.50 * library["solar_surplus"]
    )
    library["bess_rank"] = library["bess"].rank(method="first", pct=True)
    return library


def _window_path_indices(
    n_paths: int,
    years: int,
    n_windows: int,
    seed: int,
    rho: float,
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    if rho <= 0.0:
        return rng.integers(0, n_windows, size=(n_paths, years))
    z = np.empty((n_paths, years), dtype=float)
    z[:, 0] = rng.normal(size=n_paths)
    scale = math.sqrt(max(0.0, 1.0 - rho * rho))
    for t in range(1, years):
        z[:, t] = rho * z[:, t - 1] + scale * rng.normal(size=n_paths)
    u = norm.cdf(z)
    return np.minimum((u * n_windows).astype(int), n_windows - 1)


def _paths_from_window_library(
    library: pd.DataFrame,
    n_paths: int,
    years: int,
    seed: int,
    rho: float,
) -> tuple[np.ndarray, dict[str, np.ndarray], float]:
    ordered = library.sort_values("bess").reset_index(drop=True)
    indices = _window_path_indices(n_paths, years, len(ordered), seed, rho)
    B = ordered["bess"].to_numpy(float)[indices]
    rights = {
        "bess_only": np.zeros_like(B),
        "signed": ordered["signed_accessible"].to_numpy(float)[indices],
        "surplus_only": ordered["surplus_accessible"].to_numpy(float)[indices],
    }
    if years > 1:
        actual_corr = float(np.corrcoef(B[:, :-1].ravel(), B[:, 1:].ravel())[0, 1])
    else:
        actual_corr = float("nan")
    return B, rights, actual_corr


def run_regime_persistence(panel: pd.DataFrame, n_paths: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    library = build_contiguous_annual_window_library(panel)
    rows: list[dict] = []
    annual_diag_rows: list[dict] = []

    # Baseline annual marginal diagnostics from a large month-stratified draw.
    baseline_annual = rr.draw_both_rights(panel, 100_000, 20260819)
    baseline_series = {
        "bess": baseline_annual.bess,
        "signed_accessible": rr.ACCESS_REFERENCE * (
            0.50 * baseline_annual.wind_signed + 0.50 * baseline_annual.solar_signed
        ),
        "surplus_accessible": rr.ACCESS_REFERENCE * (
            0.50 * baseline_annual.wind_surplus + 0.50 * baseline_annual.solar_surplus
        ),
    }
    window_series = {
        "bess": library["bess"].to_numpy(float),
        "signed_accessible": library["signed_accessible"].to_numpy(float),
        "surplus_accessible": library["surplus_accessible"].to_numpy(float),
    }
    for generator, series_map in (
        ("month_stratified", baseline_series),
        ("contiguous_12_month", window_series),
    ):
        for component, values in series_map.items():
            x = np.asarray(values, float) / rr.P_BESS_MW
            annual_diag_rows.append(
                {
                    "generator": generator,
                    "component": component,
                    "n_annual_states": len(x),
                    "mean_gbp_per_bess_mw_year": float(x.mean()),
                    "sd_gbp_per_bess_mw_year": float(x.std(ddof=1)),
                    "p05_gbp_per_bess_mw_year": float(np.quantile(x, 0.05)),
                    "median_gbp_per_bess_mw_year": float(np.median(x)),
                    "p95_gbp_per_bess_mw_year": float(np.quantile(x, 0.95)),
                }
            )

    for seed in rr.SEEDS:
        # Existing month-stratified generator, independent annual draws.
        scen = rr.draw_both_rights(panel, n_paths * rr.TENOR_YEARS, seed)
        B_base = rr.reshape_paths(scen.bess, n_paths)
        rights_base = {
            "bess_only": np.zeros_like(B_base),
            "signed": rr.path_arrays(scen, n_paths, "signed", 0.50)[1],
            "surplus_only": rr.path_arrays(scen, n_paths, "surplus_only", 0.50)[1],
        }
        for case, R in rights_base.items():
            for policy in ("unlimited_reserve", "one_year_reserve"):
                result = liquidity.solve_floor(B_base, R, policy, Q)
                rows.append(
                    {
                        "seed": seed,
                        "n_paths": n_paths,
                        "generator": "month_stratified",
                        "rank_persistence_rho": 0.0,
                        "actual_lag1_bess_cash_correlation": float(np.corrcoef(B_base[:, :-1].ravel(), B_base[:, 1:].ravel())[0, 1]),
                        "case": case,
                        "policy": policy,
                        **result,
                    }
                )

        for rho in (0.0, 0.50, 0.80):
            B, rights, actual_corr = _paths_from_window_library(
                library, n_paths, rr.TENOR_YEARS, seed + int(10_000 * rho) + 901, rho
            )
            for case, R in rights.items():
                for policy in ("unlimited_reserve", "one_year_reserve"):
                    result = liquidity.solve_floor(B, R, policy, Q)
                    rows.append(
                        {
                            "seed": seed,
                            "n_paths": n_paths,
                            "generator": "contiguous_12_month",
                            "rank_persistence_rho": rho,
                            "actual_lag1_bess_cash_correlation": actual_corr,
                            "case": case,
                            "policy": policy,
                            **result,
                        }
                    )

    frame = pd.DataFrame(rows)
    base = frame[frame["case"] == "bess_only"][[
        "seed", "generator", "rank_persistence_rho", "policy",
        "floor_gbp_per_bess_mw_year"
    ]].rename(columns={"floor_gbp_per_bess_mw_year": "bess_only_floor"})
    frame = frame.merge(
        base,
        on=["seed", "generator", "rank_persistence_rho", "policy"],
        validate="many_to_one",
    )
    frame["uplift_gbp_per_bess_mw_year"] = frame["floor_gbp_per_bess_mw_year"] - frame["bess_only_floor"]
    frame["uplift_fraction"] = frame["uplift_gbp_per_bess_mw_year"] / frame["bess_only_floor"]
    return frame, pd.DataFrame(annual_diag_rows), library


def run_provider_terms(panel: pd.DataFrame, n_paths: int) -> pd.DataFrame:
    rows: list[dict] = []
    for seed in rr.SEEDS:
        scen = rr.draw_both_rights(panel, n_paths * rr.TENOR_YEARS, seed)
        B = rr.reshape_paths(scen.bess, n_paths)
        R = rr.path_arrays(scen, n_paths, "surplus_only", 0.50)[1]
        for theta in (0.25, 0.50, 0.75):
            for margin in (0.00, 0.05, 0.10):
                base = rr.solve_path_floor(
                    B,
                    np.zeros_like(B),
                    Q,
                    provider_upside_share=theta,
                    required_margin_fraction=margin,
                )
                backed = rr.solve_path_floor(
                    B,
                    R,
                    Q,
                    provider_upside_share=theta,
                    required_margin_fraction=margin,
                )
                solvency_only = rr.solve_path_floor(
                    B,
                    R,
                    Q,
                    provider_upside_share=theta,
                    required_margin_fraction=-10.0,
                )
                margin_only = rr.solve_path_floor(
                    B,
                    R,
                    0.0,
                    provider_upside_share=theta,
                    required_margin_fraction=margin,
                )
                if solvency_only["floor_gbp_per_bess_mw_year"] < margin_only["floor_gbp_per_bess_mw_year"] - 1.0:
                    binding = "path solvency"
                elif margin_only["floor_gbp_per_bess_mw_year"] < solvency_only["floor_gbp_per_bess_mw_year"] - 1.0:
                    binding = "expected margin"
                else:
                    binding = "both"
                rows.append(
                    {
                        "seed": seed,
                        "n_paths": n_paths,
                        "provider_upside_share": theta,
                        "required_margin_fraction": margin,
                        "bess_only_floor_gbp_per_bess_mw_year": base["floor_gbp_per_bess_mw_year"],
                        "surplus_backed_floor_gbp_per_bess_mw_year": backed["floor_gbp_per_bess_mw_year"],
                        "absolute_uplift_gbp_per_bess_mw_year": backed["floor_gbp_per_bess_mw_year"] - base["floor_gbp_per_bess_mw_year"],
                        "uplift_fraction": backed["floor_gbp_per_bess_mw_year"] / base["floor_gbp_per_bess_mw_year"] - 1.0,
                        "solvency_only_ceiling_gbp_per_bess_mw_year": solvency_only["floor_gbp_per_bess_mw_year"],
                        "margin_only_ceiling_gbp_per_bess_mw_year": margin_only["floor_gbp_per_bess_mw_year"],
                        "binding_constraint": binding,
                    }
                )
    return pd.DataFrame(rows)


def summarise(frame: pd.DataFrame, groups: Iterable[str], metrics: Iterable[str]) -> pd.DataFrame:
    rows: list[dict] = []
    for keys, group in frame.groupby(list(groups), dropna=False, sort=True):
        if not isinstance(keys, tuple):
            keys = (keys,)
        row = dict(zip(groups, keys))
        for metric in metrics:
            x = pd.to_numeric(group[metric], errors="coerce").dropna().to_numpy(float)
            if len(x) == 0:
                continue
            row[f"{metric}_mean"] = float(x.mean())
            row[f"{metric}_sd"] = float(x.std(ddof=1)) if len(x) > 1 else 0.0
            row[f"{metric}_min"] = float(x.min())
            row[f"{metric}_max"] = float(x.max())
        rows.append(row)
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--paths", type=int, default=20_000)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument(
        "--segment",
        choices=("settlement", "retention", "regime", "terms", "all"),
        default="all",
    )
    args = parser.parse_args()

    start = time.time()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    duration_daily = rr.prepare_duration_daily(False)
    panel = rr.live_panel_for_duration(2, duration_daily)

    generated: list[str] = []
    if args.segment in ("settlement", "all"):
        settlement = run_settlement_frequency(panel, args.paths)
        settlement.to_csv(out / "settlement_frequency_run_level.csv", index=False)
        settlement_summary = summarise(
            settlement,
            ("case", "policy"),
            (
                "effective_access_share",
                "admitted_cash_gbp_per_bess_mw_year",
                "bess_only_floor_gbp_per_bess_mw_year",
                "floor_gbp_per_bess_mw_year",
                "uplift_gbp_per_bess_mw_year",
                "uplift_fraction",
            ),
        )
        settlement_summary.to_csv(out / "settlement_frequency_summary.csv", index=False)
        generated += ["settlement_frequency_run_level.csv", "settlement_frequency_summary.csv"]

    if args.segment in ("retention", "all"):
        retention = run_staged_retention(panel, args.paths)
        retention.to_csv(out / "staged_retention_window_run_level.csv", index=False)
        retention_summary = summarise(
            retention,
            ("case", "retention_years", "retention_years_numeric"),
            (
                "full_floor_gbp_per_bess_mw_year",
                "average_scheduled_floor_gbp_per_bess_mw_year",
                "full_floor_retained_fraction",
                "average_floor_retained_fraction",
                "mean_annual_distribution_gbp_per_bess_mw",
            ),
        )
        retention_summary.to_csv(out / "staged_retention_window_summary.csv", index=False)
        generated += ["staged_retention_window_run_level.csv", "staged_retention_window_summary.csv"]

    if args.segment in ("regime", "all"):
        regime, annual_diag, library = run_regime_persistence(panel, args.paths)
        regime.to_csv(out / "regime_persistence_run_level.csv", index=False)
        regime_summary = summarise(
            regime,
            ("generator", "rank_persistence_rho", "case", "policy"),
            (
                "actual_lag1_bess_cash_correlation",
                "floor_gbp_per_bess_mw_year",
                "bess_only_floor",
                "uplift_gbp_per_bess_mw_year",
                "uplift_fraction",
                "mean_annual_distribution_gbp_per_bess_mw",
            ),
        )
        regime_summary.to_csv(out / "regime_persistence_summary.csv", index=False)
        annual_diag.to_csv(out / "annual_regime_variation_diagnostic.csv", index=False)
        library.to_csv(out / "contiguous_12_month_window_library.csv", index=False)
        generated += [
            "regime_persistence_run_level.csv",
            "regime_persistence_summary.csv",
            "annual_regime_variation_diagnostic.csv",
            "contiguous_12_month_window_library.csv",
        ]

    if args.segment in ("terms", "all"):
        terms = run_provider_terms(panel, args.paths)
        terms.to_csv(out / "provider_terms_sensitivity_run_level.csv", index=False)
        terms_summary = summarise(
            terms,
            ("provider_upside_share", "required_margin_fraction", "binding_constraint"),
            (
                "bess_only_floor_gbp_per_bess_mw_year",
                "surplus_backed_floor_gbp_per_bess_mw_year",
                "absolute_uplift_gbp_per_bess_mw_year",
                "uplift_fraction",
                "solvency_only_ceiling_gbp_per_bess_mw_year",
                "margin_only_ceiling_gbp_per_bess_mw_year",
            ),
        )
        terms_summary.to_csv(out / "provider_terms_sensitivity_summary.csv", index=False)
        generated += ["provider_terms_sensitivity_run_level.csv", "provider_terms_sensitivity_summary.csv"]

    metadata = {
        "version": "1.9.1",
        "paths_per_seed": args.paths,
        "seeds": list(rr.SEEDS),
        "segment": args.segment,
        "new_tests": {
            "settlement_frequency": "daily pro-rata positive residual versus positive monthly residual, plus mean-matched monthly diagnostic",
            "staged_retention": "50% first-year floor ramp; reserve vintages retained for 1, 2, 3, 5 years or unlimited",
            "regime_persistence": "overlapping contiguous 12-calendar-month joint cash windows; component means matched to the reference generator; Gaussian-rank persistence rho 0, 0.5 and 0.8",
            "provider_terms": "BESS-upside share 25%, 50%, 75%; expected margin 0%, 5%, 10%",
        },
        "generated_files": generated,
        "elapsed_seconds": time.time() - start,
    }
    (out / "contract_robustness_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
