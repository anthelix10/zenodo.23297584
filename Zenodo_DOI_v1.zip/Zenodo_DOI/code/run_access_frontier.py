#!/usr/bin/env python3
"""Build the fixed-q residual-access and protected-hurdle design frontier.

The script preserves the paper's central same-percentile contract test.  It does
not optimise fair value or introduce a new revenue stack.  For the principal
non-negative residual right it reports:

* q95 BESS floors over access shares 0%-100% and hurdles 50%, 70%, 90%;
* daily non-carrying and monthly-netted residual definitions on common paths;
* the minimum access share required for selected target BESS floors; and
* cash-allocation cases used in the manuscript table and figure.

Wind-solar exposure is fixed at 50% of equal-mean renewable cash exposure and
opening reserve is zero.  All cases use identical BESS and renewable scenario
paths within a seed.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))

import phase_model as pm  # noqa: E402
import run_retained_reserve_analysis as rr  # noqa: E402

Q = 0.95
HURDLES = (0.50, 0.70, 0.90)
TARGET_FLOORS = (24_000.0, 26_000.0, 28_000.0, 30_000.0, 32_000.0, 34_000.0, 36_000.0)
DEFAULT_OUT = ROOT / "results" / "retained_reserve"
TOL = 1e-8


@dataclass
class HurdleScenarioSet:
    bess: np.ndarray
    daily: dict[float, tuple[np.ndarray, np.ndarray]]
    monthly: dict[float, tuple[np.ndarray, np.ndarray]]


def _equalise_pair(wind: np.ndarray, solar: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Scale technologies to the paper's 25 MW-equivalent equal-mean cash basis."""
    target = 0.5 * (float(wind.mean()) + float(solar.mean()))
    return (
        rr.RENEWABLE_REFERENCE_MW * target / float(wind.mean()) * wind,
        rr.RENEWABLE_REFERENCE_MW * target / float(solar.mean()) * solar,
    )


def draw_common_hurdle_scenarios(
    panel: pd.DataFrame,
    n: int,
    seed: int,
    *,
    hurdles: tuple[float, ...] = HURDLES,
    chunk: int = 25_000,
) -> HurdleScenarioSet:
    """Draw common BESS/wind/solar annual scenarios for all hurdle definitions."""
    blocks = pm.build_blocks(panel)
    hurdle_values = {h: pm.historical_hurdle(panel, h) for h in hurdles}
    rng = np.random.default_rng(seed)

    bess = np.zeros(n, dtype=float)
    daily = {h: (np.zeros(n, dtype=float), np.zeros(n, dtype=float)) for h in hurdles}
    monthly = {h: (np.zeros(n, dtype=float), np.zeros(n, dtype=float)) for h in hurdles}

    for month in range(1, 13):
        z = blocks[month]
        n_blocks = math.ceil(z.target_days / z.b.shape[1])
        for lo in range(0, n, chunk):
            hi = min(n, lo + chunk)
            rows = hi - lo
            choices = rng.integers(0, len(z.b), size=(rows, n_blocks))
            bdays = z.b[choices].reshape(rows, -1)[:, : z.target_days]
            wdays = z.w[choices].reshape(rows, -1)[:, : z.target_days]
            sdays = z.s[choices].reshape(rows, -1)[:, : z.target_days]
            source_days = np.repeat(z.source_days[choices], z.b.shape[1], axis=1)[:, : z.target_days]

            bess[lo:hi] += bdays.sum(axis=1)
            w_month = wdays.sum(axis=1)
            s_month = sdays.sum(axis=1)

            for h in hurdles:
                hurdle_w, hurdle_s = hurdle_values[h]
                wr = wdays - hurdle_w[month - 1] / source_days
                sr = sdays - hurdle_s[month - 1] / source_days
                wd, sd = daily[h]
                wm, sm = monthly[h]
                wd[lo:hi] += np.maximum(wr, 0.0).sum(axis=1)
                sd[lo:hi] += np.maximum(sr, 0.0).sum(axis=1)
                wm[lo:hi] += np.maximum(w_month - hurdle_w[month - 1], 0.0)
                sm[lo:hi] += np.maximum(s_month - hurdle_s[month - 1], 0.0)

    for h in hurdles:
        daily[h] = _equalise_pair(*daily[h])
        monthly[h] = _equalise_pair(*monthly[h])
    return HurdleScenarioSet(bess=bess, daily=daily, monthly=monthly)


def _evaluate_floor(
    bess: np.ndarray,
    renewable: np.ndarray,
    guarantee: float,
    *,
    q: float = Q,
) -> tuple[bool, float, float]:
    cash = (
        renewable
        + rr.PROVIDER_UPSIDE_SHARE * np.maximum(bess - guarantee, 0.0)
        - np.maximum(guarantee - bess, 0.0)
    )
    minimum = np.cumsum(cash, axis=1).min(axis=1)
    solvency = float((minimum >= -TOL).mean())
    mean_cash = float(cash.mean())
    required_margin = rr.REQUIRED_MARGIN_FRACTION * float(bess.mean())
    feasible = solvency >= q - 1e-12 and mean_cash >= required_margin - 1e-7
    return feasible, solvency, mean_cash


def solve_floor_fast(
    bess: np.ndarray,
    renewable: np.ndarray,
    *,
    q: float = Q,
    lo_hint: float = 0.0,
    iterations: int = 22,
) -> dict:
    """Solve the zero-opening-reserve unlimited-retention floor."""
    lo = max(0.0, float(lo_hint))
    hi = max(lo + 1.0, 1.5 * float(bess.mean() + max(renewable.mean(), 0.0)))
    while _evaluate_floor(bess, renewable, hi, q=q)[0]:
        hi *= 1.5
    for _ in range(iterations):
        mid = 0.5 * (lo + hi)
        if _evaluate_floor(bess, renewable, mid, q=q)[0]:
            lo = mid
        else:
            hi = mid
    _, solvency, mean_cash = _evaluate_floor(bess, renewable, lo, q=q)
    required_margin = rr.REQUIRED_MARGIN_FRACTION * float(bess.mean())
    # The discrete path constraint normally binds; classify the margin ceiling only
    # when its slack is materially smaller than one path of solvency slack.
    solvency_slack = solvency - q
    margin_slack = (mean_cash - required_margin) / rr.P_BESS_MW
    one_path = 1.0 / len(bess)
    binding = "expected margin" if abs(margin_slack) < 0.25 and solvency_slack > 2.0 * one_path else "path solvency"
    return {
        "floor_gbp_per_bess_mw_year": lo / rr.P_BESS_MW,
        "solvency_fraction": solvency,
        "mean_provider_cash_gbp_per_bess_mw_year": mean_cash / rr.P_BESS_MW,
        "required_margin_gbp_per_bess_mw_year": required_margin / rr.P_BESS_MW,
        "binding_constraint": binding,
    }


def alpha_min_for_target(
    bess: np.ndarray,
    residual_100: np.ndarray,
    target_floor_gbp_per_mw_year: float,
    *,
    q: float = Q,
    iterations: int = 22,
) -> dict:
    guarantee = target_floor_gbp_per_mw_year * rr.P_BESS_MW

    def feasible(alpha: float) -> tuple[bool, float, float]:
        return _evaluate_floor(bess, alpha * residual_100, guarantee, q=q)

    feasible_full, solvency_full, mean_cash_full = feasible(1.0)
    if not feasible_full:
        return {
            "reached": False,
            "alpha_min": np.nan,
            "solvency_fraction": solvency_full,
            "mean_provider_cash_gbp_per_bess_mw_year": mean_cash_full / rr.P_BESS_MW,
        }
    lo, hi = 0.0, 1.0
    for _ in range(iterations):
        mid = 0.5 * (lo + hi)
        if feasible(mid)[0]:
            hi = mid
        else:
            lo = mid
    _, solvency, mean_cash = feasible(hi)
    return {
        "reached": True,
        "alpha_min": hi,
        "solvency_fraction": solvency,
        "mean_provider_cash_gbp_per_bess_mw_year": mean_cash / rr.P_BESS_MW,
    }


def make_summary(run: pd.DataFrame) -> pd.DataFrame:
    keys = ["settlement_rule", "protected_hurdle", "access_share"]
    summary = run.groupby(keys, as_index=False).agg(
        expected_residual_before_access_gbp_per_bess_mw_year=("expected_residual_before_access_gbp_per_bess_mw_year", "mean"),
        admitted_cash_gbp_per_bess_mw_year=("admitted_cash_gbp_per_bess_mw_year", "mean"),
        residual_retained_gbp_per_bess_mw_year=("residual_retained_gbp_per_bess_mw_year", "mean"),
        bess_only_floor_gbp_per_bess_mw_year=("bess_only_floor_gbp_per_bess_mw_year", "mean"),
        backed_floor_gbp_per_bess_mw_year=("backed_floor_gbp_per_bess_mw_year", "mean"),
        backed_floor_seed_min=("backed_floor_gbp_per_bess_mw_year", "min"),
        backed_floor_seed_max=("backed_floor_gbp_per_bess_mw_year", "max"),
        absolute_uplift_gbp_per_bess_mw_year=("absolute_uplift_gbp_per_bess_mw_year", "mean"),
        percentage_uplift=("percentage_uplift", "mean"),
        gross_conversion=("gross_conversion", "mean"),
        solvency_fraction=("solvency_fraction", "mean"),
        provider_cash_gbp_per_bess_mw_year=("provider_cash_gbp_per_bess_mw_year", "mean"),
    )
    # Marginal floor gain per 5 percentage points and per additional admitted pound.
    summary = summary.sort_values(keys).reset_index(drop=True)
    summary["marginal_floor_gain_gbp_per_bess_mw_year"] = np.nan
    summary["marginal_conversion"] = np.nan
    for (_, _), idx in summary.groupby(["settlement_rule", "protected_hurdle"]).groups.items():
        idx = list(idx)
        f = summary.loc[idx, "backed_floor_gbp_per_bess_mw_year"].to_numpy(float)
        c = summary.loc[idx, "admitted_cash_gbp_per_bess_mw_year"].to_numpy(float)
        df = np.r_[np.nan, np.diff(f)]
        dc = np.r_[np.nan, np.diff(c)]
        summary.loc[idx, "marginal_floor_gain_gbp_per_bess_mw_year"] = df
        summary.loc[idx, "marginal_conversion"] = np.divide(df, dc, out=np.full_like(df, np.nan), where=np.abs(dc) > 1e-12)
    # All seeds use the same binding constraint in the publication grid; retain a clean label.
    binding = run.groupby(keys)["binding_constraint"].agg(lambda s: s.mode().iloc[0]).reset_index()
    return summary.merge(binding, on=keys, how="left")


def make_target_summary(run: pd.DataFrame) -> pd.DataFrame:
    keys = ["settlement_rule", "protected_hurdle", "target_floor_gbp_per_bess_mw_year"]
    rows = []
    for key, g in run.groupby(keys):
        reached = bool(g["reached"].all())
        row = dict(zip(keys, key))
        row["reached_all_seeds"] = reached
        if reached:
            row.update({
                "alpha_min_mean": float(g["alpha_min"].mean()),
                "alpha_min_seed_min": float(g["alpha_min"].min()),
                "alpha_min_seed_max": float(g["alpha_min"].max()),
                "admitted_cash_gbp_per_bess_mw_year": float(g["admitted_cash_gbp_per_bess_mw_year"].mean()),
                "residual_retained_gbp_per_bess_mw_year": float(g["residual_retained_gbp_per_bess_mw_year"].mean()),
                "solvency_fraction": float(g["solvency_fraction"].mean()),
            })
        else:
            row.update({
                "alpha_min_mean": np.nan,
                "alpha_min_seed_min": np.nan,
                "alpha_min_seed_max": np.nan,
                "admitted_cash_gbp_per_bess_mw_year": np.nan,
                "residual_retained_gbp_per_bess_mw_year": np.nan,
                "solvency_fraction": float(g["solvency_fraction"].mean()),
            })
        rows.append(row)
    return pd.DataFrame(rows).sort_values(keys).reset_index(drop=True)


def run(n_paths: int, alpha_step: float, out: Path) -> dict:
    start = time.time()
    out.mkdir(parents=True, exist_ok=True)
    duration_daily = rr.prepare_duration_daily(False)
    panel = rr.live_panel_for_duration(2, duration_daily)
    alphas = np.round(np.arange(0.0, 1.0 + alpha_step / 2.0, alpha_step), 10)

    frontier_rows: list[dict] = []
    target_rows: list[dict] = []
    allocation_rows: list[dict] = []

    for seed in rr.SEEDS:
        scen = draw_common_hurdle_scenarios(panel, n_paths * rr.TENOR_YEARS, seed)
        bess = scen.bess.reshape(n_paths, rr.TENOR_YEARS)
        base = solve_floor_fast(bess, np.zeros_like(bess), q=Q)

        for h in HURDLES:
            for settlement, pair in (("daily_non_carrying", scen.daily[h]), ("monthly_netted", scen.monthly[h])):
                wind, solar = pair
                residual_100 = (0.50 * wind + 0.50 * solar).reshape(n_paths, rr.TENOR_YEARS)
                residual_mean = float(residual_100.mean() / rr.P_BESS_MW)
                prior_floor = base["floor_gbp_per_bess_mw_year"] * rr.P_BESS_MW
                for alpha in alphas:
                    if abs(float(alpha)) < 1e-12:
                        result = dict(base)
                    else:
                        result = solve_floor_fast(
                            bess,
                            alpha * residual_100,
                            q=Q,
                            lo_hint=prior_floor,
                        )
                    prior_floor = result["floor_gbp_per_bess_mw_year"] * rr.P_BESS_MW
                    floor = result["floor_gbp_per_bess_mw_year"]
                    admitted = alpha * residual_mean
                    uplift = floor - base["floor_gbp_per_bess_mw_year"]
                    frontier_rows.append({
                        "seed": seed,
                        "n_paths": n_paths,
                        "q": Q,
                        "wind_equal_mean_cash_share": 0.50,
                        "opening_reserve_gbp_per_bess_mw": 0.0,
                        "settlement_rule": settlement,
                        "protected_hurdle": h,
                        "access_share": float(alpha),
                        "expected_residual_before_access_gbp_per_bess_mw_year": residual_mean,
                        "admitted_cash_gbp_per_bess_mw_year": admitted,
                        "residual_retained_gbp_per_bess_mw_year": (1.0 - alpha) * residual_mean,
                        "bess_only_floor_gbp_per_bess_mw_year": base["floor_gbp_per_bess_mw_year"],
                        "backed_floor_gbp_per_bess_mw_year": floor,
                        "absolute_uplift_gbp_per_bess_mw_year": uplift,
                        "percentage_uplift": floor / base["floor_gbp_per_bess_mw_year"] - 1.0,
                        "gross_conversion": np.nan if admitted <= 1e-12 else uplift / admitted,
                        "solvency_fraction": result["solvency_fraction"],
                        "provider_cash_gbp_per_bess_mw_year": result["mean_provider_cash_gbp_per_bess_mw_year"],
                        "binding_constraint": result["binding_constraint"],
                    })

                if abs(h - 0.70) < 1e-12:
                    target_iter = TARGET_FLOORS
                else:
                    target_iter = ()
                for target in target_iter:
                    amin = alpha_min_for_target(bess, residual_100, target, q=Q)
                    alpha = amin["alpha_min"]
                    target_rows.append({
                        "seed": seed,
                        "n_paths": n_paths,
                        "q": Q,
                        "wind_equal_mean_cash_share": 0.50,
                        "opening_reserve_gbp_per_bess_mw": 0.0,
                        "settlement_rule": settlement,
                        "protected_hurdle": h,
                        "target_floor_gbp_per_bess_mw_year": target,
                        **amin,
                        "admitted_cash_gbp_per_bess_mw_year": np.nan if not amin["reached"] else float(alpha * residual_mean),
                        "residual_retained_gbp_per_bess_mw_year": np.nan if not amin["reached"] else float((1.0 - alpha) * residual_mean),
                    })

        # Publication cash-allocation cases at the reference hurdle.
        h = 0.70
        daily_residual = (0.50 * scen.daily[h][0] + 0.50 * scen.daily[h][1]).reshape(n_paths, rr.TENOR_YEARS)
        monthly_residual = (0.50 * scen.monthly[h][0] + 0.50 * scen.monthly[h][1]).reshape(n_paths, rr.TENOR_YEARS)
        daily_mean = float(daily_residual.mean() / rr.P_BESS_MW)
        monthly_mean = float(monthly_residual.mean() / rr.P_BESS_MW)
        matched_alpha = rr.ACCESS_REFERENCE * daily_mean / monthly_mean
        cases = [
            ("Daily non-carrying residual", "daily_non_carrying", rr.ACCESS_REFERENCE, daily_residual),
            ("Monthly-netted residual", "monthly_netted", rr.ACCESS_REFERENCE, monthly_residual),
            ("Monthly, cash-matched to daily", "monthly_netted", matched_alpha, monthly_residual),
        ]
        for label, settlement, alpha, residual in cases:
            result = solve_floor_fast(bess, alpha * residual, q=Q, lo_hint=base["floor_gbp_per_bess_mw_year"] * rr.P_BESS_MW)
            residual_mean = float(residual.mean() / rr.P_BESS_MW)
            admitted = alpha * residual_mean
            uplift = result["floor_gbp_per_bess_mw_year"] - base["floor_gbp_per_bess_mw_year"]
            allocation_rows.append({
                "seed": seed,
                "case": label,
                "settlement_rule": settlement,
                "protected_hurdle": h,
                "access_share": alpha,
                "expected_residual_before_access_gbp_per_bess_mw_year": residual_mean,
                "admitted_cash_gbp_per_bess_mw_year": admitted,
                "residual_retained_gbp_per_bess_mw_year": (1.0 - alpha) * residual_mean,
                "bess_only_floor_gbp_per_bess_mw_year": base["floor_gbp_per_bess_mw_year"],
                "backed_floor_gbp_per_bess_mw_year": result["floor_gbp_per_bess_mw_year"],
                "absolute_uplift_gbp_per_bess_mw_year": uplift,
                "percentage_uplift": result["floor_gbp_per_bess_mw_year"] / base["floor_gbp_per_bess_mw_year"] - 1.0,
                "gross_conversion": uplift / admitted,
                "binding_constraint": result["binding_constraint"],
            })

    frontier = pd.DataFrame(frontier_rows)
    targets = pd.DataFrame(target_rows)
    allocation = pd.DataFrame(allocation_rows)
    frontier_summary = make_summary(frontier)
    target_summary = make_target_summary(targets)
    allocation_summary = allocation.groupby(["case", "settlement_rule"], as_index=False).agg(
        protected_hurdle=("protected_hurdle", "mean"),
        access_share=("access_share", "mean"),
        expected_residual_before_access_gbp_per_bess_mw_year=("expected_residual_before_access_gbp_per_bess_mw_year", "mean"),
        admitted_cash_gbp_per_bess_mw_year=("admitted_cash_gbp_per_bess_mw_year", "mean"),
        residual_retained_gbp_per_bess_mw_year=("residual_retained_gbp_per_bess_mw_year", "mean"),
        bess_only_floor_gbp_per_bess_mw_year=("bess_only_floor_gbp_per_bess_mw_year", "mean"),
        backed_floor_gbp_per_bess_mw_year=("backed_floor_gbp_per_bess_mw_year", "mean"),
        absolute_uplift_gbp_per_bess_mw_year=("absolute_uplift_gbp_per_bess_mw_year", "mean"),
        percentage_uplift=("percentage_uplift", "mean"),
        gross_conversion=("gross_conversion", "mean"),
    )
    allocation_summary["binding_constraint"] = "path solvency"

    frontier.to_csv(out / "access_hurdle_grid_run_level.csv", index=False)
    frontier_summary.to_csv(out / "Table_S32_access_hurdle_surface.csv", index=False)
    targets.to_csv(out / "target_floor_alpha_min_run_level.csv", index=False)
    target_summary.to_csv(out / "Table_S33_minimum_access_targets.csv", index=False)
    allocation.to_csv(out / "cash_allocation_cases_run_level.csv", index=False)
    allocation_summary.to_csv(out / "Table_S34_cash_allocation_cases.csv", index=False)

    meta = {
        "status": "PASS",
        "n_paths_per_seed": n_paths,
        "seeds": list(rr.SEEDS),
        "q": Q,
        "alpha_step": alpha_step,
        "hurdles": list(HURDLES),
        "settlement_rules": ["daily_non_carrying", "monthly_netted"],
        "wind_equal_mean_cash_share": 0.50,
        "opening_reserve_gbp_per_bess_mw": 0.0,
        "target_floors_gbp_per_bess_mw_year": list(TARGET_FLOORS),
        "runtime_seconds": time.time() - start,
        "outputs": [
            "access_hurdle_grid_run_level.csv",
            "Table_S32_access_hurdle_surface.csv",
            "target_floor_alpha_min_run_level.csv",
            "Table_S33_minimum_access_targets.csv",
            "cash_allocation_cases_run_level.csv",
            "Table_S34_cash_allocation_cases.csv",
        ],
    }
    (out / "access_frontier_metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return meta


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-paths", type=int, default=20_000)
    ap.add_argument("--alpha-step", type=float, default=0.10)
    ap.add_argument("--output-dir", type=Path, default=DEFAULT_OUT)
    args = ap.parse_args()
    meta = run(args.n_paths, args.alpha_step, args.output_dir)
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
