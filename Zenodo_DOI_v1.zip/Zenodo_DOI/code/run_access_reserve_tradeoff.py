#!/usr/bin/env python3
"""Target-specific access-opening-reserve frontier for the £30,000 BESS floor.

This is a direct extension of the paper's existing solver, not a new objective.
For each stated opening reserve it calculates the least daily or monthly
positive-residual access share needed to support the fixed target under the
same q95 and expected-margin rules.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))

import run_access_frontier as raf  # noqa: E402
import run_retained_reserve_analysis as rr  # noqa: E402

Q = 0.95
HURDLE = 0.70
TARGET = 30_000.0
OPENING_RESERVES = (0.0, 500.0, 1_000.0, 1_500.0, 2_500.0, 5_000.0)
DEFAULT_OUT = ROOT / "results" / "retained_reserve"
TOL = 1e-8


def metrics(bess: np.ndarray, residual: np.ndarray, alpha: float, opening_reserve_per_mw: float) -> tuple[bool, float, float]:
    guarantee = TARGET * rr.P_BESS_MW
    cash = (
        alpha * residual
        + rr.PROVIDER_UPSIDE_SHARE * np.maximum(bess - guarantee, 0.0)
        - np.maximum(guarantee - bess, 0.0)
    )
    opening = opening_reserve_per_mw * rr.P_BESS_MW
    solvent = (opening + np.cumsum(cash, axis=1)).min(axis=1) >= -TOL
    solvency = float(solvent.mean())
    mean_cash = float(cash.mean())
    required_margin = rr.REQUIRED_MARGIN_FRACTION * float(bess.mean())
    return bool(solvency >= Q - 1e-12 and mean_cash >= required_margin - 1e-7), solvency, mean_cash


def solve_alpha(bess: np.ndarray, residual: np.ndarray, opening_reserve_per_mw: float, iterations: int = 25) -> dict:
    ok, solvency, mean_cash = metrics(bess, residual, 1.0, opening_reserve_per_mw)
    if not ok:
        return {
            "reached": False,
            "alpha_min": np.nan,
            "solvency_fraction": solvency,
            "mean_provider_cash_gbp_per_bess_mw_year": mean_cash / rr.P_BESS_MW,
        }
    lo, hi = 0.0, 1.0
    for _ in range(iterations):
        mid = 0.5 * (lo + hi)
        if metrics(bess, residual, mid, opening_reserve_per_mw)[0]:
            hi = mid
        else:
            lo = mid
    _, solvency, mean_cash = metrics(bess, residual, hi, opening_reserve_per_mw)
    return {
        "reached": True,
        "alpha_min": hi,
        "solvency_fraction": solvency,
        "mean_provider_cash_gbp_per_bess_mw_year": mean_cash / rr.P_BESS_MW,
    }


def run(n_paths: int, out: Path) -> dict:
    out.mkdir(parents=True, exist_ok=True)
    start = time.time()
    duration_daily = rr.prepare_duration_daily(False)
    panel = rr.live_panel_for_duration(2, duration_daily)
    rows: list[dict] = []

    for seed in rr.SEEDS:
        scen = raf.draw_common_hurdle_scenarios(panel, n_paths * rr.TENOR_YEARS, seed, hurdles=(HURDLE,))
        bess = scen.bess.reshape(n_paths, rr.TENOR_YEARS)
        for settlement, pair in (("daily_non_carrying", scen.daily[HURDLE]), ("monthly_netted", scen.monthly[HURDLE])):
            wind, solar = pair
            residual = (0.5 * wind + 0.5 * solar).reshape(n_paths, rr.TENOR_YEARS)
            residual_mean = float(residual.mean() / rr.P_BESS_MW)
            for opening in OPENING_RESERVES:
                result = solve_alpha(bess, residual, opening)
                alpha = result["alpha_min"]
                rows.append({
                    "seed": seed,
                    "settlement_rule": settlement,
                    "target_floor_gbp_per_bess_mw_year": TARGET,
                    "opening_reserve_gbp_per_bess_mw": opening,
                    "reached": result["reached"],
                    "alpha_min": alpha,
                    "transferred_cash_gbp_per_bess_mw_year": alpha * residual_mean if np.isfinite(alpha) else np.nan,
                    "residual_before_access_gbp_per_bess_mw_year": residual_mean,
                    "residual_retained_gbp_per_bess_mw_year": (1.0 - alpha) * residual_mean if np.isfinite(alpha) else np.nan,
                    "solvency_fraction": result["solvency_fraction"],
                    "mean_provider_cash_gbp_per_bess_mw_year": result["mean_provider_cash_gbp_per_bess_mw_year"],
                })

    run_level = pd.DataFrame(rows)
    summary_rows: list[dict] = []
    for (settlement, opening), g in run_level.groupby(["settlement_rule", "opening_reserve_gbp_per_bess_mw"], sort=True):
        reached = bool(g["reached"].all())
        summary_rows.append({
            "settlement_rule": settlement,
            "opening_reserve_gbp_per_bess_mw": opening,
            "target_floor_gbp_per_bess_mw_year": TARGET,
            "reached_all_seeds": reached,
            "alpha_min_mean": float(g["alpha_min"].mean()) if reached else np.nan,
            "alpha_min_seed_min": float(g["alpha_min"].min()) if reached else np.nan,
            "alpha_min_seed_max": float(g["alpha_min"].max()) if reached else np.nan,
            "transferred_cash_gbp_per_bess_mw_year": float(g["transferred_cash_gbp_per_bess_mw_year"].mean()) if reached else np.nan,
            "residual_retained_gbp_per_bess_mw_year": float(g["residual_retained_gbp_per_bess_mw_year"].mean()) if reached else np.nan,
            "solvency_fraction": float(g["solvency_fraction"].mean()),
        })
    summary = pd.DataFrame(summary_rows).sort_values(["opening_reserve_gbp_per_bess_mw", "settlement_rule"]).reset_index(drop=True)
    run_level.to_csv(out / "access_reserve_tradeoff_run_level.csv", index=False)
    summary.to_csv(out / "Table_S45_access_reserve_tradeoff.csv", index=False)
    meta = {
        "status": "PASS",
        "release": "1.9.1",
        "n_paths_per_seed": n_paths,
        "seeds": list(rr.SEEDS),
        "q": Q,
        "target_floor_gbp_per_bess_mw_year": TARGET,
        "protected_hurdle": HURDLE,
        "wind_equal_mean_cash_share": 0.5,
        "renewable_cash_scale_mw_equivalent_per_100mw_bess": rr.RENEWABLE_REFERENCE_MW,
        "opening_reserve_grid_gbp_per_bess_mw": list(OPENING_RESERVES),
        "outputs": ["access_reserve_tradeoff_run_level.csv", "Table_S45_access_reserve_tradeoff.csv"],
        "runtime_seconds": time.time() - start,
    }
    (out / "access_reserve_tradeoff_metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return meta


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--paths", type=int, default=20_000)
    ap.add_argument("--output-dir", type=Path, default=DEFAULT_OUT)
    args = ap.parse_args()
    meta = run(args.paths, args.output_dir)
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
