#!/usr/bin/env python3
"""Focused specification checks for the residual-renewable-cash floor paper.

This script rebuilds four manuscript-facing checks without changing the central
contract model:

1. circular versus non-circular, calendar-contiguous within-month blocks;
2. equal-mean cash-scale translation into observed-sample physical MW;
3. cash-level and adverse annual BESS-renewable dependence stresses; and
4. a confidence-mismatch matrix for standalone and renewable-backed floors.

The main comparison remains the same-percentile diagonal. Off-diagonal cells are
reported only to quantify the bias created by applying different confidence
standards to the standalone and renewable-backed contracts.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
CODE = BASE / "code"
sys.path.insert(0, str(CODE))

import phase_model as pm  # noqa: E402
import run_retained_reserve_analysis as rr  # noqa: E402

OUT = BASE / "results" / "retained_reserve"
OUT.mkdir(parents=True, exist_ok=True)
Q_LEVELS = (0.90, 0.95, 0.99)


@dataclass
class NonCircularBlockSet:
    b: np.ndarray
    w: np.ndarray
    s: np.ndarray
    source_days: np.ndarray
    target_days: int


def build_non_circular_blocks(panel: pd.DataFrame, block_days: int = 14) -> Dict[int, NonCircularBlockSet]:
    """Build exact-calendar blocks with no month-end wrap and no missing-day adjacency."""
    out: Dict[int, NonCircularBlockSet] = {}
    for month in range(1, 13):
        sub = panel.loc[panel["month"] == month].sort_values(["year", "date"])
        b_rows: list[np.ndarray] = []
        w_rows: list[np.ndarray] = []
        s_rows: list[np.ndarray] = []
        source_days: list[float] = []
        for _, group in sub.groupby("year"):
            g = group.sort_values("date").reset_index(drop=True)
            n = len(g)
            for start in range(0, n - block_days + 1):
                dates = pd.DatetimeIndex(g.loc[start : start + block_days - 1, "date"])
                if len(dates) != block_days:
                    continue
                if not np.all(np.diff(dates.values).astype("timedelta64[D]") == np.timedelta64(1, "D")):
                    continue
                sl = slice(start, start + block_days)
                b_rows.append(g["bess_cash_gbp"].to_numpy(float)[sl])
                w_rows.append(g["wind_gross"].to_numpy(float)[sl])
                s_rows.append(g["solar_gross"].to_numpy(float)[sl])
                source_days.append(float(n))
        if not b_rows:
            raise RuntimeError(f"No non-circular {block_days}-day blocks for month {month}")
        out[month] = NonCircularBlockSet(
            b=np.stack(b_rows),
            w=np.stack(w_rows),
            s=np.stack(s_rows),
            source_days=np.asarray(source_days, dtype=float),
            target_days=pm.MONTH_DAYS[month],
        )
    return out


def draw_non_circular_surplus(
    blocks: Dict[int, NonCircularBlockSet],
    panel: pd.DataFrame,
    n: int,
    seed: int,
    *,
    wind_weight: float = 0.50,
    access_share: float = rr.ACCESS_REFERENCE,
) -> tuple[np.ndarray, np.ndarray]:
    hurdle_w, hurdle_s = pm.historical_hurdle(panel, rr.HURDLE_FRACTION)
    rng = np.random.default_rng(seed)
    B = np.zeros(n, dtype=float)
    W = np.zeros(n, dtype=float)
    S = np.zeros(n, dtype=float)
    for month in range(1, 13):
        z = blocks[month]
        n_blocks = math.ceil(z.target_days / z.b.shape[1])
        choices = rng.integers(0, len(z.b), size=(n, n_blocks))
        bdays = z.b[choices].reshape(n, -1)[:, : z.target_days]
        wdays = z.w[choices].reshape(n, -1)[:, : z.target_days]
        sdays = z.s[choices].reshape(n, -1)[:, : z.target_days]
        div = np.repeat(z.source_days[choices], z.b.shape[1], axis=1)[:, : z.target_days]
        B += bdays.sum(axis=1)
        W += np.maximum(wdays - hurdle_w[month - 1] / div, 0.0).sum(axis=1)
        S += np.maximum(sdays - hurdle_s[month - 1] / div, 0.0).sum(axis=1)

    target = 0.5 * (float(W.mean()) + float(S.mean()))
    W = rr.RENEWABLE_REFERENCE_MW * target / float(W.mean()) * W
    S = rr.RENEWABLE_REFERENCE_MW * target / float(S.mean()) * S
    R = access_share * (wind_weight * W + (1.0 - wind_weight) * S)
    return B, R


def run_non_circular(panel: pd.DataFrame, n_paths: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    blocks = build_non_circular_blocks(panel)
    rows: list[dict] = []
    for seed in rr.SEEDS:
        ref = rr.draw_both_rights(panel, n_paths * rr.TENOR_YEARS, seed)
        B_ref = rr.reshape_paths(ref.bess, n_paths)
        _, R_ref = rr.path_arrays(ref, n_paths, "surplus_only", 0.50)
        b, r = draw_non_circular_surplus(
            blocks, panel, n_paths * rr.TENOR_YEARS, seed
        )
        B_alt = b.reshape(n_paths, rr.TENOR_YEARS)
        R_alt = r.reshape(n_paths, rr.TENOR_YEARS)
        # Mean-match the alternative component streams to isolate block adjacency.
        B_alt *= float(B_ref.mean() / B_alt.mean())
        R_alt *= float(R_ref.mean() / R_alt.mean())

        for construction, B, R in (
            ("circular_within_source_month", B_ref, R_ref),
            ("non_circular_calendar_contiguous_mean_matched", B_alt, R_alt),
        ):
            base = rr.solve_path_floor(B, np.zeros_like(B), 0.95)
            backed = rr.solve_path_floor(B, R, 0.95)
            rows.append(
                {
                    "seed": seed,
                    "n_paths": n_paths,
                    "construction": construction,
                    "bess_only_floor_gbp_per_bess_mw_year": base["floor_gbp_per_bess_mw_year"],
                    "surplus_backed_floor_gbp_per_bess_mw_year": backed["floor_gbp_per_bess_mw_year"],
                    "absolute_uplift_gbp_per_bess_mw_year": backed["floor_gbp_per_bess_mw_year"] - base["floor_gbp_per_bess_mw_year"],
                    "uplift_pct": 100.0 * (backed["floor_gbp_per_bess_mw_year"] / base["floor_gbp_per_bess_mw_year"] - 1.0),
                    "mean_bess_cash_gbp_per_bess_mw_year": float(B.mean() / rr.P_BESS_MW),
                    "mean_admitted_renewable_cash_gbp_per_bess_mw_year": float(R.mean() / rr.P_BESS_MW),
                    "solvency_fraction": backed["solvency_fraction"],
                }
            )
    run_level = pd.DataFrame(rows)
    summary = (
        run_level.groupby("construction", as_index=False)
        .agg(
            bess_only_floor_gbp_per_bess_mw_year=("bess_only_floor_gbp_per_bess_mw_year", "mean"),
            surplus_backed_floor_gbp_per_bess_mw_year=("surplus_backed_floor_gbp_per_bess_mw_year", "mean"),
            absolute_uplift_gbp_per_bess_mw_year=("absolute_uplift_gbp_per_bess_mw_year", "mean"),
            uplift_pct=("uplift_pct", "mean"),
            mean_bess_cash_gbp_per_bess_mw_year=("mean_bess_cash_gbp_per_bess_mw_year", "mean"),
            mean_admitted_renewable_cash_gbp_per_bess_mw_year=("mean_admitted_renewable_cash_gbp_per_bess_mw_year", "mean"),
        )
    )
    return run_level, summary


def observed_scale_translation(panel: pd.DataFrame) -> pd.DataFrame:
    x = panel.copy()
    x["year"] = x["date"].dt.year
    x["month"] = x["date"].dt.month
    mt = x.groupby(["year", "month"])[["wind_gross", "solar_gross"]].sum()
    climatology = mt.groupby("month").mean().reindex(range(1, 13))
    hurdles = rr.HURDLE_FRACTION * climatology

    rows: list[dict] = []
    for right in ("signed", "surplus_only"):
        annualised: dict[str, float] = {}
        for tech, col in (("wind", "wind_gross"), ("solar", "solar_gross")):
            daily = x[["date", "year", "month", col]].copy()
            source_days = daily.groupby(["year", "month"])["date"].transform("count").astype(float)
            residual = daily[col].to_numpy(float) - hurdles.loc[daily["month"], col].to_numpy(float) / source_days.to_numpy(float)
            if right == "surplus_only":
                residual = np.maximum(residual, 0.0)
            annualised[tech] = float(residual.mean() * 365.25)
        target = 0.5 * (annualised["wind"] + annualised["solar"])
        for tech in ("wind", "solar"):
            multiplier = target / annualised[tech]
            rows.append(
                {
                    "right": right,
                    "technology": tech,
                    "observed_annual_right_gbp_per_physical_mw": annualised[tech],
                    "equal_mean_target_gbp_per_reference_mw": target,
                    "equal_mean_scale_multiplier": multiplier,
                    "physical_mw_equivalent_of_25_mw_reference_scale": rr.RENEWABLE_REFERENCE_MW * multiplier,
                    "physical_mw_in_50_50_equal_mean_mix": 0.5 * rr.RENEWABLE_REFERENCE_MW * multiplier,
                    "sample_start": str(x["date"].min().date()),
                    "sample_end": str(x["date"].max().date()),
                    "matched_days": int(len(x)),
                }
            )
    return pd.DataFrame(rows)


def adverse_same_rank(R: np.ndarray, B: np.ndarray) -> np.ndarray:
    """Pair low annual renewable support with low annual BESS cash in each contract year."""
    out = np.empty_like(R)
    for t in range(B.shape[1]):
        b_order = np.argsort(B[:, t], kind="mergesort")
        r_sorted = np.sort(R[:, t], kind="mergesort")
        out[b_order, t] = r_sorted
    return out


def binding_constraint(result: dict, *, q: float = 0.95) -> str:
    solvency_slack = result["solvency_fraction"] - q
    margin_slack = result["mean_provider_profit_gbp_per_bess_mw_year"] - result["required_margin_gbp_per_bess_mw_year"]
    if abs(solvency_slack) <= 1.0 / 20_000 + 1e-6 and margin_slack > 1e-3:
        return "path_solvency"
    if margin_slack <= 1e-3 and solvency_slack > 1e-5:
        return "expected_margin"
    if abs(solvency_slack) <= 1.0 / 20_000 + 1e-6 and margin_slack <= 1e-3:
        return "both"
    return "path_solvency" if solvency_slack < margin_slack else "expected_margin"


def run_structural_stress(panel: pd.DataFrame, n_paths: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    stress_defs = (
        ("reference", 1.00, 1.00, "observed_alignment"),
        ("renewable_cash_minus_10pct", 1.00, 0.90, "observed_alignment"),
        ("renewable_cash_minus_20pct", 1.00, 0.80, "observed_alignment"),
        ("bess_minus_10pct_renewable_minus_20pct", 0.90, 0.80, "observed_alignment"),
        ("both_cash_streams_minus_20pct", 0.80, 0.80, "observed_alignment"),
        ("adverse_annual_same_rank_dependence", 1.00, 1.00, "adverse_same_rank"),
    )
    rows: list[dict] = []
    for seed in rr.SEEDS:
        scen = rr.draw_both_rights(panel, n_paths * rr.TENOR_YEARS, seed)
        B0, R0 = rr.path_arrays(scen, n_paths, "surplus_only", 0.50)
        for name, b_scale, r_scale, dependence in stress_defs:
            B = B0 * b_scale
            R = R0 * r_scale
            if dependence == "adverse_same_rank":
                R = adverse_same_rank(R, B)
            base = rr.solve_path_floor(B, np.zeros_like(B), 0.95)
            backed = rr.solve_path_floor(B, R, 0.95)
            rows.append(
                {
                    "seed": seed,
                    "n_paths": n_paths,
                    "stress": name,
                    "bess_cash_scale": b_scale,
                    "renewable_cash_scale": r_scale,
                    "annual_dependence": dependence,
                    "bess_only_floor_gbp_per_bess_mw_year": base["floor_gbp_per_bess_mw_year"],
                    "surplus_backed_floor_gbp_per_bess_mw_year": backed["floor_gbp_per_bess_mw_year"],
                    "absolute_uplift_gbp_per_bess_mw_year": backed["floor_gbp_per_bess_mw_year"] - base["floor_gbp_per_bess_mw_year"],
                    "uplift_pct": 100.0 * (backed["floor_gbp_per_bess_mw_year"] / base["floor_gbp_per_bess_mw_year"] - 1.0),
                    "binding_constraint": binding_constraint(backed),
                    "solvency_fraction": backed["solvency_fraction"],
                    "mean_provider_profit_gbp_per_bess_mw_year": backed["mean_provider_profit_gbp_per_bess_mw_year"],
                    "required_margin_gbp_per_bess_mw_year": backed["required_margin_gbp_per_bess_mw_year"],
                }
            )
    run_level = pd.DataFrame(rows)
    order = [x[0] for x in stress_defs]
    summary = (
        run_level.groupby("stress", as_index=False)
        .agg(
            bess_cash_scale=("bess_cash_scale", "first"),
            renewable_cash_scale=("renewable_cash_scale", "first"),
            annual_dependence=("annual_dependence", "first"),
            bess_only_floor_gbp_per_bess_mw_year=("bess_only_floor_gbp_per_bess_mw_year", "mean"),
            surplus_backed_floor_gbp_per_bess_mw_year=("surplus_backed_floor_gbp_per_bess_mw_year", "mean"),
            absolute_uplift_gbp_per_bess_mw_year=("absolute_uplift_gbp_per_bess_mw_year", "mean"),
            uplift_pct=("uplift_pct", "mean"),
            binding_constraint=("binding_constraint", lambda x: ";".join(sorted(set(x)))),
        )
    )
    summary["_order"] = summary["stress"].map({name: i for i, name in enumerate(order)})
    summary = summary.sort_values("_order").drop(columns="_order").reset_index(drop=True)
    return run_level, summary


def run_confidence_mismatch(panel: pd.DataFrame, n_paths: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    run_rows: list[dict] = []
    for seed in rr.SEEDS:
        scen = rr.draw_both_rights(panel, n_paths * rr.TENOR_YEARS, seed)
        B, R = rr.path_arrays(scen, n_paths, "surplus_only", 0.50)
        base = {q: rr.solve_path_floor(B, np.zeros_like(B), q)["floor_gbp_per_bess_mw_year"] for q in Q_LEVELS}
        backed = {q: rr.solve_path_floor(B, R, q)["floor_gbp_per_bess_mw_year"] for q in Q_LEVELS}
        for q_backed in Q_LEVELS:
            for q_bess in Q_LEVELS:
                absolute = backed[q_backed] - base[q_bess]
                run_rows.append(
                    {
                        "seed": seed,
                        "n_paths": n_paths,
                        "bess_only_solvency_requirement": q_bess,
                        "renewable_backed_solvency_requirement": q_backed,
                        "bess_only_floor_gbp_per_bess_mw_year": base[q_bess],
                        "surplus_backed_floor_gbp_per_bess_mw_year": backed[q_backed],
                        "apparent_absolute_uplift_gbp_per_bess_mw_year": absolute,
                        "apparent_uplift_pct": 100.0 * absolute / base[q_bess],
                        "like_for_like_same_percentile": bool(q_bess == q_backed),
                    }
                )
    run_level = pd.DataFrame(run_rows)
    summary = (
        run_level.groupby(
            ["renewable_backed_solvency_requirement", "bess_only_solvency_requirement"],
            as_index=False,
        )
        .agg(
            bess_only_floor_gbp_per_bess_mw_year=("bess_only_floor_gbp_per_bess_mw_year", "mean"),
            surplus_backed_floor_gbp_per_bess_mw_year=("surplus_backed_floor_gbp_per_bess_mw_year", "mean"),
            apparent_absolute_uplift_gbp_per_bess_mw_year=("apparent_absolute_uplift_gbp_per_bess_mw_year", "mean"),
            apparent_uplift_pct=("apparent_uplift_pct", "mean"),
            like_for_like_same_percentile=("like_for_like_same_percentile", "first"),
        )
    )
    return run_level, summary


def write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def main() -> None:
    global OUT
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-paths", type=int, default=20_000)
    parser.add_argument("--output-dir", type=Path, default=OUT, help="Directory for generated outputs")
    args = parser.parse_args()
    OUT = args.output_dir.resolve()
    OUT.mkdir(parents=True, exist_ok=True)
    start = time.perf_counter()

    duration_daily = rr.prepare_duration_daily(False)
    panel = rr.live_panel_for_duration(2, duration_daily)

    nc_run, nc_summary = run_non_circular(panel, args.n_paths)
    scale = observed_scale_translation(panel)
    stress_run, stress_summary = run_structural_stress(panel, args.n_paths)
    mismatch_run, mismatch_summary = run_confidence_mismatch(panel, args.n_paths)

    nc_run.to_csv(OUT / "non_circular_block_sensitivity_run_level.csv", index=False)
    nc_summary.to_csv(OUT / "Table_S27_non_circular_block_sensitivity.csv", index=False)
    scale.to_csv(OUT / "Table_S28_equal_mean_cash_scale_translation.csv", index=False)
    stress_run.to_csv(OUT / "structural_cash_stress_run_level.csv", index=False)
    stress_summary.to_csv(OUT / "Table_S29_structural_cash_level_and_dependence_stress.csv", index=False)
    mismatch_run.to_csv(OUT / "confidence_mismatch_run_level.csv", index=False)
    mismatch_summary.to_csv(OUT / "Table_S30_confidence_mismatch_matrix.csv", index=False)

    metadata = {
        "version": "1.9.1",
        "script": "code/run_focused_specification_checks.py",
        "n_paths_per_seed": args.n_paths,
        "tenor_years": rr.TENOR_YEARS,
        "seeds": list(rr.SEEDS),
        "reference_wind_equal_mean_cash_weight": 0.50,
        "reference_renewable_access_share": rr.ACCESS_REFERENCE,
        "reference_protected_hurdle_fraction": rr.HURDLE_FRACTION,
        "reference_path_solvency": 0.95,
        "sample_start": str(panel["date"].min().date()),
        "sample_end": str(panel["date"].max().date()),
        "matched_days": int(len(panel)),
        "runtime_seconds": time.perf_counter() - start,
        "outputs": [
            "results/retained_reserve/non_circular_block_sensitivity_run_level.csv",
            "results/retained_reserve/Table_S27_non_circular_block_sensitivity.csv",
            "results/retained_reserve/Table_S28_equal_mean_cash_scale_translation.csv",
            "results/retained_reserve/structural_cash_stress_run_level.csv",
            "results/retained_reserve/Table_S29_structural_cash_level_and_dependence_stress.csv",
            "results/retained_reserve/confidence_mismatch_run_level.csv",
            "results/retained_reserve/Table_S30_confidence_mismatch_matrix.csv",
        ],
    }
    write_json(OUT / "focused_specification_checks_metadata.json", metadata)
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
