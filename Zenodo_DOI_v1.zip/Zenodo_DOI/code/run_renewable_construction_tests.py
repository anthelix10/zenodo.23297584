#!/usr/bin/env python3
"""Renewable-index construction robustness from frozen daily BMU cash.

This minimal-deposit version starts from the archived daily per-MW cash for the
six retained renewable BM Units. It reproduces the equal-weight, registered-
capacity-weighted and leave-one-wind-unit-out cases with the article's central
ten-year retained-reserve solver.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / 'data' / 'renewable_construction'
DEFAULT_OUT = ROOT / 'results' / 'renewable_construction'
TABLE_OUT = ROOT / 'results' / 'retained_reserve'
VALIDATION = ROOT / 'validation'
sys.path.insert(0, str(ROOT / 'code'))
import run_retained_reserve_analysis as rr  # noqa: E402

Q = 0.95
RIGHT = 'surplus_only'
WIND_WEIGHT = 0.50
ACCESS = 0.50


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def load_common_panel() -> tuple[pd.DataFrame, dict[str, np.ndarray], dict]:
    daily_path = INPUT / 'individual_bmu_daily_cash.csv.gz'
    manifest_path = INPUT / 'bmu_manifest.csv'
    bess_path = ROOT / 'data' / 'operating' / 'reference_daily_cash.csv.gz'
    live_path = ROOT / 'data' / 'operating' / 'live_technology_indices_daily.csv'

    daily = pd.read_csv(daily_path, parse_dates=['date'])
    manifest = pd.read_csv(manifest_path, encoding='utf-8-sig')
    manifest.columns = [c.lstrip('\ufeff') for c in manifest.columns]
    manifest['capacityMW'] = pd.to_numeric(manifest['capacityMW'])
    wind_units = manifest.loc[manifest['technology'].eq('offshore wind'), 'bmUnit'].tolist()
    capacities = manifest.set_index('bmUnit')['capacityMW'].to_dict()
    all_units = manifest['bmUnit'].tolist()

    periods = daily.pivot(index='date', columns='bmUnit', values='periods')
    cash = daily.pivot(index='date', columns='bmUnit', values='cash_per_mw_gbp')

    bess = pd.read_csv(bess_path, parse_dates=['date'])[['date', 'bess_cash_gbp']]
    bess['date'] = pd.to_datetime(bess['date'], utc=True).dt.tz_localize(None)
    live = pd.read_csv(live_path, parse_dates=['date'])
    live['date'] = pd.to_datetime(live['date']).dt.tz_localize(None)
    canonical = bess.merge(live, on='date', how='inner').set_index('date').sort_index()
    canonical = canonical.loc[
        (canonical.index >= pd.Timestamp('2023-05-01'))
        & (canonical.index <= pd.Timestamp('2025-11-30'))
        & (canonical['periods'] >= 48)
    ]
    canonical = canonical.rename(columns={
        'live_wind_index_cash_per_mw_gbp': 'wind_gross',
        'live_solar_primary_cash_per_mw_gbp': 'solar_gross',
    })

    valid = periods.index[(periods[all_units].min(axis=1) >= 48) & periods.index.isin(canonical.index)].sort_values()
    if len(valid) != 939:
        raise RuntimeError(f'Expected 939 common dates, found {len(valid)}')

    wind_equal = cash.loc[valid, wind_units].mean(axis=1)
    solar = cash.loc[valid, 'T_LARKS-1']
    max_w = float((wind_equal - canonical.loc[valid, 'wind_gross']).abs().max())
    max_s = float((solar - canonical.loc[valid, 'solar_gross']).abs().max())
    if max_w > 1e-8 or max_s > 1e-8:
        raise RuntimeError(f'Reference-index reconstruction failed: wind={max_w}, solar={max_s}')

    cap = np.array([capacities[u] for u in wind_units], dtype=float)
    wind_capacity = (cash.loc[valid, wind_units].to_numpy() * cap[None, :]).sum(axis=1) / cap.sum()

    constructions: dict[str, np.ndarray] = {
        'Five-unit equal-weight reference': wind_equal.to_numpy(),
        'Registered-capacity-weighted five-unit index': wind_capacity,
    }
    for unit in wind_units:
        keep = [u for u in wind_units if u != unit]
        constructions[f'Leave out {unit}'] = cash.loc[valid, keep].mean(axis=1).to_numpy()

    base = canonical.loc[valid, ['bess_cash_gbp']].copy()
    base['solar_gross'] = solar.to_numpy()
    base['periods'] = 48
    base = base.reset_index()
    base['year'] = base['date'].dt.year
    base['month'] = base['date'].dt.month

    provenance = {
        'daily_bmu_cash': {'path': str(daily_path.relative_to(ROOT)), 'sha256': sha256(daily_path)},
        'manifest': {'path': str(manifest_path.relative_to(ROOT)), 'sha256': sha256(manifest_path)},
        'bess_daily': {'path': str(bess_path.relative_to(ROOT)), 'sha256': sha256(bess_path)},
        'live_indices_daily': {'path': str(live_path.relative_to(ROOT)), 'sha256': sha256(live_path)},
        'reference_reconstruction_max_abs_difference': {'wind': max_w, 'solar': max_s},
        'valid_dates': {'count': len(valid), 'start': str(valid.min().date()), 'end': str(valid.max().date())},
    }
    return base, constructions, provenance


def run_fixed_design(base: pd.DataFrame, constructions: dict[str, np.ndarray], n_paths: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows: list[dict] = []
    for label, wind in constructions.items():
        panel = base.copy()
        panel['wind_gross'] = wind
        for seed in rr.SEEDS:
            scen = rr.draw_both_rights(panel, n_paths * rr.TENOR_YEARS, seed)
            B, R = rr.path_arrays(scen, n_paths, RIGHT, WIND_WEIGHT, access_share=ACCESS)
            standalone = rr.solve_path_floor(B, np.zeros_like(B), Q)
            backed = rr.solve_path_floor(B, R, Q)
            rows.append({
                'renewable_construction': label,
                'common_days': len(panel),
                'seed': seed,
                'n_paths': n_paths,
                'backed_floor_gbp_per_bess_mw_year': backed['floor_gbp_per_bess_mw_year'],
                'bess_only_floor_gbp_per_bess_mw_year': standalone['floor_gbp_per_bess_mw_year'],
                'absolute_uplift_gbp_per_bess_mw_year': backed['floor_gbp_per_bess_mw_year'] - standalone['floor_gbp_per_bess_mw_year'],
                'uplift_fraction': backed['floor_gbp_per_bess_mw_year'] / standalone['floor_gbp_per_bess_mw_year'] - 1.0,
                'mean_admitted_renewable_cash_gbp_per_bess_mw_year': backed['mean_admitted_renewable_cash_gbp_per_bess_mw_year'],
            })
    run = pd.DataFrame(rows)
    summary = run.groupby(['renewable_construction', 'common_days'], as_index=False).agg(
        backed_floor_gbp_per_bess_mw_year=('backed_floor_gbp_per_bess_mw_year', 'mean'),
        backed_floor_seed_sd_gbp_per_bess_mw_year=('backed_floor_gbp_per_bess_mw_year', 'std'),
        bess_only_floor_gbp_per_bess_mw_year=('bess_only_floor_gbp_per_bess_mw_year', 'mean'),
        absolute_uplift_gbp_per_bess_mw_year=('absolute_uplift_gbp_per_bess_mw_year', 'mean'),
        uplift_fraction=('uplift_fraction', 'mean'),
        mean_admitted_renewable_cash_gbp_per_bess_mw_year=('mean_admitted_renewable_cash_gbp_per_bess_mw_year', 'mean'),
    )
    order = list(constructions)
    summary['_order'] = summary['renewable_construction'].map({v: i for i, v in enumerate(order)})
    summary = summary.sort_values('_order').drop(columns='_order').reset_index(drop=True)
    ref = float(summary.loc[summary['renewable_construction'].eq('Five-unit equal-weight reference'), 'backed_floor_gbp_per_bess_mw_year'].iloc[0])
    summary['difference_from_equal_weight_reference_gbp_per_bess_mw_year'] = summary['backed_floor_gbp_per_bess_mw_year'] - ref
    return run, summary


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--paths', type=int, default=20_000)
    ap.add_argument('--output-dir', type=Path, default=DEFAULT_OUT)
    args = ap.parse_args()
    out = args.output_dir
    out.mkdir(parents=True, exist_ok=True)
    TABLE_OUT.mkdir(parents=True, exist_ok=True)
    VALIDATION.mkdir(parents=True, exist_ok=True)

    base, constructions, provenance = load_common_panel()
    run, summary = run_fixed_design(base, constructions, args.paths)
    run.to_csv(out / 'renewable_construction_fixed_design_run_level.csv', index=False)
    summary.to_csv(out / 'renewable_construction_robustness.csv', index=False)
    summary.to_csv(TABLE_OUT / 'Table_S38_renewable_construction_robustness.csv', index=False)
    meta = {'status': 'PASS', 'n_paths_per_seed': args.paths, 'seeds': list(rr.SEEDS), 'provenance': provenance}
    (out / 'renewable_construction_run_metadata.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
    print(summary.to_string(index=False))


if __name__ == '__main__':
    main()
