#!/usr/bin/env python3
"""Validate the reference 100 MW/200 MWh BESS operating envelope against
Pillswood and Clay Tye on common complete UTC days.

The named-asset data are Elexon B1610 metered MWh per settlement period. They
are used only as an operating-envelope check; they are not treated as a
complete commercial revenue account and do not enter the retained-reserve
floor solver.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / "data" / "contract" / "reference_halfhour_dispatch.csv.gz"
B1610 = ROOT / "data" / "named_bess_operating" / "b1610_pillswood_claytye_site_aggregated.csv.gz"
SELECTED_BMUS = ROOT / "data" / "named_bess_operating" / "selected_bmu_reference.csv"
RESULTS = ROOT / "results" / "operating_phase"
VALIDATION = ROOT / "validation"

DT_H = 0.5
ETA = math.sqrt(0.93)
DAYS_PER_YEAR = 365.25
ENVELOPE_TOLERANCE = 0.02

# Public project ratings. The B1610 reference file separately records the BMU
# registered capacities used to audit the mappings.
RATINGS = {
    "Reference model": {"power_mw": 100.0, "energy_mwh": 200.0, "source": "paper reference design"},
    "Pillswood": {"power_mw": 98.0, "energy_mwh": 196.0, "source": "Harmony Energy project rating"},
    "Clay Tye": {"power_mw": 99.0, "energy_mwh": 198.0, "source": "Harmony Energy project rating"},
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_inputs() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    reference = pd.read_csv(REFERENCE)
    reference["start_time"] = pd.to_datetime(reference["start_time"], utc=True)
    required_reference = {"start_time", "net_external_mw"}
    missing_reference = required_reference.difference(reference.columns)
    if missing_reference:
        raise RuntimeError(f"Reference dispatch is missing columns: {sorted(missing_reference)}")
    if reference["start_time"].duplicated().any():
        raise RuntimeError("Reference dispatch contains duplicate timestamps")

    b1610 = pd.read_csv(B1610)
    required_b1610 = {"site", "halfHourEndTime", "quantityMWh", "contributingBmUnitCount"}
    missing_b1610 = required_b1610.difference(b1610.columns)
    if missing_b1610:
        raise RuntimeError(f"B1610 input is missing columns: {sorted(missing_b1610)}")
    b1610["halfHourEndTime"] = pd.to_datetime(b1610["halfHourEndTime"], utc=True)
    b1610["start_time"] = b1610["halfHourEndTime"] - pd.Timedelta(minutes=30)
    if b1610.duplicated(["site", "start_time"]).any():
        raise RuntimeError("B1610 input contains duplicate site-timestamp rows")
    if set(b1610["site"].unique()) != {"Pillswood", "Clay Tye"}:
        raise RuntimeError(f"Unexpected named sites: {sorted(b1610['site'].unique())}")
    if (b1610["contributingBmUnitCount"] != 2).any():
        raise RuntimeError("At least one site-period does not contain both selected BM Units")

    selected = pd.read_csv(SELECTED_BMUS)
    expected = {
        "Pillswood": {"E_PILLB-1", "E_PILLB-2"},
        "Clay Tye": {"E_CLAYB-1", "E_CLAYB-2"},
    }
    found = {site: set(g["elexonBmUnit"]) for site, g in selected.groupby("site")}
    if found != expected:
        raise RuntimeError(f"Selected BMU mapping differs from expected mapping: {found}")
    return reference, b1610, selected


def build_common_period_panel(reference: pd.DataFrame, b1610: pd.DataFrame) -> tuple[pd.DataFrame, list[pd.Timestamp]]:
    actual = b1610.pivot(index="start_time", columns="site", values="quantityMWh")
    reference_period = reference.set_index("start_time")[["net_external_mw"]].copy()
    reference_period["Reference model"] = reference_period["net_external_mw"] * DT_H
    combined = actual.join(reference_period[["Reference model"]], how="inner")
    combined = combined.dropna(subset=["Pillswood", "Clay Tye", "Reference model"]).sort_index()
    combined["utc_date"] = combined.index.floor("D")

    counts = combined.groupby("utc_date")[["Pillswood", "Clay Tye", "Reference model"]].count()
    complete_dates = counts.index[(counts == 48).all(axis=1)].tolist()
    panel = combined[combined["utc_date"].isin(complete_dates)].copy()
    expected_rows = len(complete_dates) * 48
    if len(panel) != expected_rows:
        raise RuntimeError(f"Expected {expected_rows} common rows but found {len(panel)}")
    if len(complete_dates) < 800:
        raise RuntimeError(f"Unexpectedly short common complete-day panel: {len(complete_dates)} days")
    return panel, complete_dates


def daily_metrics(period: pd.DataFrame, case: str) -> pd.DataFrame:
    power_mw = RATINGS[case]["power_mw"]
    energy_mwh = RATINGS[case]["energy_mwh"]
    q = period[case].astype(float)
    d = pd.DataFrame(index=period.index)
    d["utc_date"] = period["utc_date"]
    d["q_mwh"] = q
    d["power_mw"] = q / DT_H
    d["absolute_power_fraction"] = d["power_mw"].abs() / power_mw
    d["delta_soc_mwh"] = np.where(q >= 0.0, -q / ETA, (-q) * ETA)

    rows: list[dict] = []
    for date, g in d.groupby("utc_date", sort=True):
        cumulative = np.r_[0.0, g["delta_soc_mwh"].cumsum().to_numpy(float)]
        energy_range = float(cumulative.max() - cumulative.min())
        throughput = float(g["q_mwh"].abs().sum())
        max_power_fraction = float(g["absolute_power_fraction"].max())
        rows.append(
            {
                "case": case,
                "utc_date": date,
                "periods": int(len(g)),
                "maximum_absolute_power_fraction": max_power_fraction,
                "throughput_mwh": throughput,
                "equivalent_full_cycles": throughput / (2.0 * energy_mwh),
                "implied_energy_range_mwh": energy_range,
                "implied_energy_range_fraction": energy_range / energy_mwh,
                "net_export_mwh": float(g["q_mwh"].sum()),
                "discharge_mwh": float(g["q_mwh"].clip(lower=0.0).sum()),
                "charge_mwh": float(-g["q_mwh"].clip(upper=0.0).sum()),
                "power_screen_pass": bool(max_power_fraction <= 1.0 + ENVELOPE_TOLERANCE),
                "energy_screen_pass": bool(energy_range / energy_mwh <= 1.0 + ENVELOPE_TOLERANCE),
            }
        )
    out = pd.DataFrame(rows)
    out["combined_envelope_pass"] = out["power_screen_pass"] & out["energy_screen_pass"]
    return out


def summarise_case(period: pd.DataFrame, daily: pd.DataFrame, case: str) -> dict:
    power_mw = RATINGS[case]["power_mw"]
    energy_mwh = RATINGS[case]["energy_mwh"]
    period_power_fraction = (period[case].abs() / DT_H) / power_mw
    n_days = len(daily)
    return {
        "case": case,
        "rating_mw": power_mw,
        "rating_mwh": energy_mwh,
        "common_complete_days": n_days,
        "first_utc_date": daily["utc_date"].min().date().isoformat(),
        "last_utc_date": daily["utc_date"].max().date().isoformat(),
        "p99_absolute_halfhour_power_fraction": float(period_power_fraction.quantile(0.99)),
        "annualised_throughput_mwh_per_mw_year": float(daily["throughput_mwh"].sum() / power_mw * DAYS_PER_YEAR / n_days),
        "annualised_equivalent_full_cycles": float(daily["equivalent_full_cycles"].sum() * DAYS_PER_YEAR / n_days),
        "median_daily_implied_energy_range_fraction": float(daily["implied_energy_range_fraction"].median()),
        "p95_daily_implied_energy_range_fraction": float(daily["implied_energy_range_fraction"].quantile(0.95)),
        "p99_daily_implied_energy_range_fraction": float(daily["implied_energy_range_fraction"].quantile(0.99)),
        "combined_envelope_pass_fraction": float(daily["combined_envelope_pass"].mean()),
        "days_above_one_equivalent_cycle_fraction": float((daily["equivalent_full_cycles"] > 1.0).mean()),
    }


def annual_summary(daily: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict] = []
    for (case, year), g in daily.groupby(["case", daily["utc_date"].dt.year], sort=True):
        rating = RATINGS[case]
        rows.append(
            {
                "case": case,
                "year": int(year),
                "complete_utc_days": int(len(g)),
                "annualised_throughput_mwh_per_mw_year": float(g["throughput_mwh"].sum() / rating["power_mw"] * DAYS_PER_YEAR / len(g)),
                "annualised_equivalent_full_cycles": float(g["equivalent_full_cycles"].sum() * DAYS_PER_YEAR / len(g)),
                "p95_daily_implied_energy_range_fraction": float(g["implied_energy_range_fraction"].quantile(0.95)),
                "combined_envelope_pass_fraction": float(g["combined_envelope_pass"].mean()),
            }
        )
    return pd.DataFrame(rows)


def main() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    VALIDATION.mkdir(parents=True, exist_ok=True)
    reference, b1610, selected = load_inputs()
    period, complete_dates = build_common_period_panel(reference, b1610)

    daily_parts = []
    summaries = []
    for case in ["Reference model", "Pillswood", "Clay Tye"]:
        d = daily_metrics(period, case)
        daily_parts.append(d)
        summaries.append(summarise_case(period, d, case))

    daily = pd.concat(daily_parts, ignore_index=True)
    summary = pd.DataFrame(summaries)
    annual = annual_summary(daily)

    daily.to_csv(
        RESULTS / "named_bess_operating_validation_daily.csv.gz",
        index=False,
        compression={"method": "gzip", "mtime": 0},
    )
    summary.to_csv(RESULTS / "Table_S40_named_BESS_operating_envelope.csv", index=False)
    annual.to_csv(RESULTS / "named_bess_operating_validation_annual.csv", index=False)

    audit = {
        "analysis": "Date-matched operating-envelope validation against Pillswood and Clay Tye",
        "role": "physical operating validation only; named-asset metering is not used as complete revenue and does not enter the q95 floor solver",
        "reference_input": str(REFERENCE.relative_to(ROOT)),
        "reference_sha256": sha256(REFERENCE),
        "b1610_input": str(B1610.relative_to(ROOT)),
        "b1610_sha256": sha256(B1610),
        "selected_bmu_input": str(SELECTED_BMUS.relative_to(ROOT)),
        "selected_bmu_sha256": sha256(SELECTED_BMUS),
        "selected_bmus": selected[["site", "nationalGridBmUnit", "elexonBmUnit", "bmUnitName"]].to_dict(orient="records"),
        "common_complete_utc_days": len(complete_dates),
        "first_complete_utc_date": complete_dates[0].date().isoformat(),
        "last_complete_utc_date": complete_dates[-1].date().isoformat(),
        "common_half_hours": int(len(period)),
        "period_duration_hours": DT_H,
        "round_trip_efficiency_for_implied_energy_range": 0.93,
        "charge_and_discharge_efficiency": ETA,
        "equivalent_full_cycle_formula": "sum(abs(grid_metered_MWh)) / (2 * project_energy_MWh)",
        "implied_energy_range_formula": "range of cumulative internal-energy change using eta_c=eta_d=sqrt(0.93)",
        "envelope_tolerance_fraction": ENVELOPE_TOLERANCE,
        "ratings": RATINGS,
        "summary_records": summary.to_dict(orient="records"),
    }
    (VALIDATION / "named_bess_operating_validation_audit.json").write_text(
        json.dumps(audit, indent=2), encoding="utf-8"
    )

    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
