#!/usr/bin/env python3
"""Regenerate data-driven diagnostics for standalone Main Figures 2 and 3.

The script uses the frozen operating inputs and the paper's principal 20,000-path,
10-year, surplus-only reference contract (seed 20260805; q=95%; 50% access;
50% equal-mean wind exposure; zero opening reserve). It writes:

* an illustrative near-boundary solvent reserve path, decomposed into annual
  transferred residual, retained BESS upside and BESS shortfall payments; and
* standalone-versus-backed path-solvency curves over candidate guarantees,
  including the common q=95% intersection and expected-margin ceilings.

These outputs are figure diagnostics only; they do not replace the three-seed
headline tables.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))

import phase_model as pm  # noqa: E402
import run_retained_reserve_analysis as rr  # noqa: E402

DEFAULT_OUT = ROOT / "results" / "retained_reserve"
SEED = 20260805
N_PATHS = 20_000
Q = 0.95
WIND_WEIGHT = 0.50
ACCESS = 0.50
TOL = 1e-8


def diagnostics(bess: np.ndarray, renewable: np.ndarray, guarantee: float) -> dict:
    upside = rr.PROVIDER_UPSIDE_SHARE * np.maximum(bess - guarantee, 0.0)
    shortfall = np.maximum(guarantee - bess, 0.0)
    cash = renewable + upside - shortfall
    cumulative = np.cumsum(cash, axis=1)
    minimum = cumulative.min(axis=1)
    return {
        "upside": upside,
        "shortfall": shortfall,
        "cash": cash,
        "cumulative": cumulative,
        "minimum": minimum,
        "solvency": float((minimum >= -TOL).mean()),
        "mean_cash": float(cash.mean()),
    }


def margin_ceiling(bess: np.ndarray, renewable: np.ndarray) -> float:
    required = rr.REQUIRED_MARGIN_FRACTION * float(bess.mean())

    def slack(g: float) -> float:
        d = diagnostics(bess, renewable, g)
        return float(d["mean_cash"] - required)

    lo = 0.0
    hi = 1.5 * float(bess.mean() + max(float(renewable.mean()), 0.0))
    while slack(hi) >= 0.0:
        hi *= 1.5
    for _ in range(48):
        mid = 0.5 * (lo + hi)
        if slack(mid) >= 0.0:
            lo = mid
        else:
            hi = mid
    return lo


def choose_boundary_path(d: dict) -> int:
    minimum = np.asarray(d["minimum"], dtype=float)
    cash = np.asarray(d["cash"], dtype=float)
    solvent = np.flatnonzero(minimum >= -TOL)
    if len(solvent) == 0:
        raise RuntimeError("No solvent path available for illustrative reserve path")
    # Prefer a solvent path close to the reserve boundary that contains both a
    # positive and a negative annual provider-cash observation.
    upside = np.asarray(d["upside"], dtype=float)
    shortfall = np.asarray(d["shortfall"], dtype=float)
    candidates = [
        i for i in solvent
        if (cash[i] < 0).any() and (cash[i] > 0).any()
        and upside[i].max() > 50_000.0 and (shortfall[i] > 0).any()
    ]
    if not candidates:
        candidates = solvent.tolist()
    return int(min(candidates, key=lambda i: abs(minimum[i])))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output-dir", type=Path, default=DEFAULT_OUT)
    ap.add_argument("--n-paths", type=int, default=N_PATHS)
    ap.add_argument("--seed", type=int, default=SEED)
    args = ap.parse_args()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    t0 = time.time()

    panel = pm.load_live_panel()
    scen = rr.draw_both_rights(panel, args.n_paths * rr.TENOR_YEARS, args.seed)
    bess, residual = rr.path_arrays(
        scen,
        args.n_paths,
        "surplus_only",
        WIND_WEIGHT,
        access_share=ACCESS,
    )
    zero = np.zeros_like(residual)

    standalone = rr.solve_path_floor(bess, zero, Q)
    backed = rr.solve_path_floor(bess, residual, Q)
    g_bess = float(standalone["guarantee_gbp_year"])
    g_backed = float(backed["guarantee_gbp_year"])

    # Figure 2: a near-boundary solvent path at the backed q95 floor.
    d_backed = diagnostics(bess, residual, g_backed)
    path_index = choose_boundary_path(d_backed)
    reserve_path = pd.DataFrame({
        "contract_year": np.arange(1, rr.TENOR_YEARS + 1, dtype=int),
        "bess_revenue_gbp_per_bess_mw": bess[path_index] / rr.P_BESS_MW,
        "transferred_residual_gbp_per_bess_mw": residual[path_index] / rr.P_BESS_MW,
        "provider_bess_upside_gbp_per_bess_mw": d_backed["upside"][path_index] / rr.P_BESS_MW,
        "bess_shortfall_paid_gbp_per_bess_mw": d_backed["shortfall"][path_index] / rr.P_BESS_MW,
        "net_provider_cash_gbp_per_bess_mw": d_backed["cash"][path_index] / rr.P_BESS_MW,
        "cumulative_reserve_gbp_per_bess_mw": d_backed["cumulative"][path_index] / rr.P_BESS_MW,
    })
    reserve_path.to_csv(out / "Figure_2_reference_reserve_path.csv", index=False)

    # Figure 3: common-q solvency curves. Candidate guarantees are per BESS MW.
    grid_per_mw = np.arange(15_000.0, 32_000.0 + 1e-9, 100.0)
    rows: list[dict] = []
    for case, ren in [("bess_only", zero), ("residual_backed", residual)]:
        for g_per_mw in grid_per_mw:
            g = g_per_mw * rr.P_BESS_MW
            d = diagnostics(bess, ren, g)
            rows.append({
                "case": case,
                "candidate_guarantee_gbp_per_bess_mw_year": g_per_mw,
                "path_solvency_fraction": d["solvency"],
                "mean_provider_cash_gbp_per_bess_mw_year": d["mean_cash"] / rr.P_BESS_MW,
            })
    pd.DataFrame(rows).to_csv(out / "Figure_3_same_q_feasibility_curve.csv", index=False)

    meta = {
        "release": "1.9.1",
        "seed": args.seed,
        "paths": args.n_paths,
        "tenor_years": rr.TENOR_YEARS,
        "q": Q,
        "wind_equal_mean_cash_share": WIND_WEIGHT,
        "residual_access_share": ACCESS,
        "opening_reserve_gbp_per_bess_mw": 0.0,
        "standalone_floor_gbp_per_bess_mw_year": g_bess / rr.P_BESS_MW,
        "backed_floor_gbp_per_bess_mw_year": g_backed / rr.P_BESS_MW,
        "standalone_margin_ceiling_gbp_per_bess_mw_year": margin_ceiling(bess, zero) / rr.P_BESS_MW,
        "backed_margin_ceiling_gbp_per_bess_mw_year": margin_ceiling(bess, residual) / rr.P_BESS_MW,
        "illustrative_path_index_zero_based": path_index,
        "illustrative_path_minimum_reserve_gbp_per_bess_mw": float(d_backed["minimum"][path_index] / rr.P_BESS_MW),
        "illustrative_path_terminal_reserve_gbp_per_bess_mw": float(d_backed["cumulative"][path_index, -1] / rr.P_BESS_MW),
        "elapsed_seconds": time.time() - t0,
        "status": "PASS",
    }
    (out / "main_figure_diagnostics_metadata.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(meta, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
