#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import py_compile
from pathlib import Path

import pandas as pd


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    args = ap.parse_args()
    root = args.root.resolve()
    checks: dict[str, object] = {}

    required = [
        'README.md', 'DATA_SOURCES.md', 'RESULTS_INDEX.md', 'CITATION.cff',
        'LICENSE_CODE.txt', 'LICENSE_DOCUMENTATION.txt', 'requirements.txt',
        'FILE_MANIFEST.csv', 'SHA256SUMS.txt', 'zenodo.json',
        'data/operating/reference_daily_cash.csv.gz',
        'data/operating/live_technology_indices_daily.csv',
        'data/contract/reference_halfhour_dispatch.csv.gz',
        'data/retained_reserve/duration_daily_cash.csv.gz',
        'data/renewable_construction/individual_bmu_daily_cash.csv.gz',
        'data/renewable_construction/bmu_manifest.csv',
        'data/named_bess_operating/b1610_pillswood_claytye_site_aggregated.csv.gz',
        'data/named_bess_operating/selected_bmu_reference.csv',
        'results/operating_phase/alternative_bess_daily_cash.csv',
        'results/operating_phase/Table_S40_named_BESS_operating_envelope.csv',
        'results/retained_reserve/Table_4_q95_50k_confirmation.csv',
        'results/retained_reserve/Table_S33_minimum_access_targets.csv',
        'results/retained_reserve/Table_S44_heldout_fixed_access_validation.csv',
        'results/retained_reserve/Table_S45_access_reserve_tradeoff.csv',
    ]
    missing = [p for p in required if not (root / p).exists()]
    checks['required_files'] = {'status': 'PASS' if not missing else 'FAIL', 'missing': missing}

    forbidden_parts = {'__pycache__', 'manuscript', 'figures', 'review', 'redline', 'qa_sheets'}
    forbidden_names = {'raw_download_bundle.zip', 'reference_daily_cash_regenerated.csv.gz'}
    forbidden = []
    for p in root.rglob('*'):
        rel = p.relative_to(root)
        if any(part in forbidden_parts for part in rel.parts) or p.name in forbidden_names or p.suffix == '.pyc':
            forbidden.append(str(rel))
    checks['minimal_inventory'] = {'status': 'PASS' if not forbidden else 'FAIL', 'forbidden': forbidden}

    compile_errors = []
    for p in sorted((root / 'code').glob('*.py')):
        try:
            py_compile.compile(str(p), doraise=True)
        except Exception as exc:
            compile_errors.append({'file': str(p.relative_to(root)), 'error': str(exc)})
    checks['python_compilation'] = {'status': 'PASS' if not compile_errors else 'FAIL', 'errors': compile_errors}

    manifest_errors = []
    manifest = root / 'FILE_MANIFEST.csv'
    if manifest.exists():
        with manifest.open(newline='', encoding='utf-8') as f:
            for row in csv.DictReader(f):
                p = root / row['path']
                if not p.exists():
                    manifest_errors.append({'path': row['path'], 'error': 'missing'})
                    continue
                if p.stat().st_size != int(row['size_bytes']):
                    manifest_errors.append({'path': row['path'], 'error': 'size'})
                if sha256(p) != row['sha256']:
                    manifest_errors.append({'path': row['path'], 'error': 'sha256'})
    checks['manifest'] = {'status': 'PASS' if not manifest_errors else 'FAIL', 'errors': manifest_errors}

    checksum_errors = []
    checksum_file = root / 'SHA256SUMS.txt'
    if checksum_file.exists():
        for line in checksum_file.read_text(encoding='utf-8').splitlines():
            if not line.strip():
                continue
            digest, rel = line.split('  ', 1)
            p = root / rel
            if not p.exists() or sha256(p) != digest:
                checksum_errors.append(rel)
    checks['checksums'] = {'status': 'PASS' if not checksum_errors else 'FAIL', 'errors': checksum_errors}

    sentinel_errors = []
    q = pd.read_csv(root / 'results/retained_reserve/Table_4_q95_50k_confirmation.csv')
    surplus = q[q['right'].eq('surplus_only')].iloc[0]
    if abs(float(surplus['bess_only_floor']) - 19712.289085) > 1e-3:
        sentinel_errors.append('bess_only_floor')
    if abs(float(surplus['renewable_backed_floor']) - 28389.199613) > 1e-3:
        sentinel_errors.append('backed_floor')

    targets = pd.read_csv(root / 'results/retained_reserve/Table_S33_minimum_access_targets.csv')
    daily = targets[(targets['settlement_rule'].eq('daily_non_carrying')) & (targets['target_floor_gbp_per_bess_mw_year'].eq(30000))].iloc[0]
    monthly = targets[(targets['settlement_rule'].eq('monthly_netted')) & (targets['target_floor_gbp_per_bess_mw_year'].eq(30000))].iloc[0]
    if abs(float(daily['alpha_min_mean']) - 0.594610) > 5e-6:
        sentinel_errors.append('daily_alpha')
    if abs(float(monthly['alpha_min_mean']) - 0.802728) > 5e-6:
        sentinel_errors.append('monthly_alpha')

    held = pd.read_csv(root / 'results/retained_reserve/Table_S44_heldout_fixed_access_validation.csv')
    hd = held[(held['term_type'].eq('higher_resampling_fixed')) & held['settlement_rule'].eq('daily_non_carrying')].iloc[0]
    hm = held[(held['term_type'].eq('higher_resampling_fixed')) & held['settlement_rule'].eq('monthly_netted')].iloc[0]
    if int(hd['evaluation_empirical_success_count']) != 296:
        sentinel_errors.append('heldout_daily')
    if int(hm['evaluation_empirical_success_count']) != 279:
        sentinel_errors.append('heldout_monthly')
    checks['numerical_sentinels'] = {'status': 'PASS' if not sentinel_errors else 'FAIL', 'errors': sentinel_errors}

    overall = 'PASS' if all(isinstance(v, dict) and v.get('status') == 'PASS' for v in checks.values()) else 'FAIL'
    result = {'overall_status': overall, 'checks': checks}
    print(json.dumps(result, indent=2))
    return 0 if overall == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
