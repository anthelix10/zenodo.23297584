#!/usr/bin/env python3
"""Rebuild the retained-reserve analyses for the renewable-backed BESS floor paper.

The central object is the maximum annual BESS floor supported by a ring-fenced
retained reserve. The reserve receives an accessible wind-solar cash right and a share of
BESS upside, pays BESS shortfalls, and retains positive balances across a ten-year
contract. BESS-only and renewable-backed floors use the same path-solvency
confidence level.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, Tuple

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
CODE = BASE / "code"
# Keep legacy phase-model scratch files out of the archive root.
os.environ.setdefault("BESS_PHASE_WORK", str(BASE / "reproduced_results" / "_phase_work"))
os.environ.setdefault("BESS_PHASE_OUT", str(BASE / "reproduced_results" / "legacy_phase"))
sys.path.insert(0, str(CODE))
import phase_model as pm  # noqa: E402
import renewable_bess_full_pool_model as dispatch_model  # noqa: E402

DEFAULT_OUT = BASE / "reproduced_results" / "retained_reserve"
OUT = DEFAULT_OUT
DURATION_DAILY = BASE / "data" / "retained_reserve" / "duration_daily_cash.csv.gz"

P_BESS_MW = 100.0
TENOR_YEARS = 10
RENEWABLE_REFERENCE_MW = 25.0
ACCESS_REFERENCE = 0.50
PROVIDER_UPSIDE_SHARE = 0.50
REQUIRED_MARGIN_FRACTION = 0.05
HURDLE_FRACTION = 0.70
SOLVENCY_LEVELS = (0.90, 0.95, 0.99)
SEEDS = (20260805, 20260806, 20260807)
DURATIONS = (1, 2, 4, 8)


@dataclass
class AnnualScenarioSet:
    bess: np.ndarray
    wind_signed: np.ndarray
    solar_signed: np.ndarray
    wind_surplus: np.ndarray
    solar_surplus: np.ndarray


def lower_tail_mean(x: np.ndarray, fraction: float = 0.05) -> float:
    arr = np.asarray(x, dtype=float)
    k = max(1, int(math.ceil(fraction * len(arr))))
    return float(np.partition(arr, k - 1)[:k].mean())


def prepare_duration_daily(force: bool = False) -> pd.DataFrame:
    """Re-optimise 1h/2h/4h/8h batteries using the archived forecast and prices."""
    if DURATION_DAILY.exists() and not force:
        return pd.read_csv(DURATION_DAILY, parse_dates=["date"])

    source = pd.read_csv(
        BASE / "data" / "contract" / "reference_halfhour_dispatch.csv.gz",
        parse_dates=["start_time"],
    )
    idx = pd.DatetimeIndex(pd.to_datetime(source["start_time"], utc=True))
    eval_frame = pd.DataFrame(index=idx)
    eval_frame["price_gbp_mwh"] = source["price_actual_gbp_mwh"].to_numpy(float)
    forecast = pd.Series(source["price_forecast_gbp_mwh"].to_numpy(float), index=idx)

    daily = None
    for duration in DURATIONS:
        disp = dispatch_model.rolling_dispatch(eval_frame, forecast, duration)
        d = (
            disp.groupby("date", as_index=False)["bess_cash_gbp"]
            .sum()
            .rename(columns={"bess_cash_gbp": f"bess_cash_{duration}h_gbp"})
        )
        d["date"] = pd.to_datetime(d["date"], utc=True).dt.tz_localize(None)
        daily = d if daily is None else daily.merge(d, on="date", validate="one_to_one")
    assert daily is not None
    DURATION_DAILY.parent.mkdir(parents=True, exist_ok=True)
    daily.to_csv(DURATION_DAILY, index=False, compression={"method": "gzip", "mtime": 0})
    return daily


def live_panel_for_duration(duration: int, duration_daily: pd.DataFrame) -> pd.DataFrame:
    b = duration_daily[["date", f"bess_cash_{duration}h_gbp"]].rename(
        columns={f"bess_cash_{duration}h_gbp": "bess_cash_gbp"}
    )
    b["date"] = pd.to_datetime(b["date"]).dt.tz_localize(None)
    return pm.load_live_panel(b)


def draw_both_rights(panel: pd.DataFrame, n: int, seed: int, chunk: int = 25_000) -> AnnualScenarioSet:
    """Draw aligned annual BESS/wind/solar scenarios and both contractual rights.

    The daily observations within each 14-day block remain aligned. Blocks are
    sampled only within the same calendar month, preserving seasonality and
    persistent weather/price episodes. Monthly hurdles are fixed from historical
    calendar-month means and prorated to daily amounts before the signed or
    positive-part transformation.
    """
    blocks = pm.build_blocks(panel)
    hurdle_w, hurdle_s = pm.historical_hurdle(panel, HURDLE_FRACTION)
    rng = np.random.default_rng(seed)

    B = np.zeros(n, dtype=float)
    Ws = np.zeros(n, dtype=float)
    Ss = np.zeros(n, dtype=float)
    Wp = np.zeros(n, dtype=float)
    Sp = np.zeros(n, dtype=float)

    for month in range(1, 13):
        z = blocks[month]
        n_blocks = math.ceil(z.target_days / z.b.shape[1])
        for lo in range(0, n, chunk):
            hi = min(n, lo + chunk)
            rows = hi - lo
            choices = rng.integers(0, len(z.b), size=(rows, n_blocks))
            bdays = z.b[choices].reshape(rows, -1)[:, : z.target_days]
            wdays = z.w[choices].reshape(rows, -1)[:, : z.target_days]
            sdays = z.s[choices].reshape(rows, -1)[:, : z.target_days]
            source_days = np.repeat(
                z.source_days[choices], z.b.shape[1], axis=1
            )[:, : z.target_days]
            wr = wdays - hurdle_w[month - 1] / source_days
            sr = sdays - hurdle_s[month - 1] / source_days
            B[lo:hi] += bdays.sum(axis=1)
            Ws[lo:hi] += wr.sum(axis=1)
            Ss[lo:hi] += sr.sum(axis=1)
            Wp[lo:hi] += np.maximum(wr, 0.0).sum(axis=1)
            Sp[lo:hi] += np.maximum(sr, 0.0).sum(axis=1)

    def equalise(w: np.ndarray, s: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        target = 0.5 * (float(w.mean()) + float(s.mean()))
        return (
            RENEWABLE_REFERENCE_MW * target / float(w.mean()) * w,
            RENEWABLE_REFERENCE_MW * target / float(s.mean()) * s,
        )

    Ws, Ss = equalise(Ws, Ss)
    Wp, Sp = equalise(Wp, Sp)
    return AnnualScenarioSet(B, Ws, Ss, Wp, Sp)


def reshape_paths(x: np.ndarray, n_paths: int) -> np.ndarray:
    expected = n_paths * TENOR_YEARS
    if len(x) != expected:
        raise ValueError(f"Expected {expected} annual scenarios; received {len(x)}")
    return np.asarray(x, dtype=float).reshape(n_paths, TENOR_YEARS)


def solve_path_floor(
    bess: np.ndarray,
    renewable: np.ndarray,
    solvency_level: float,
    *,
    provider_upside_share: float = PROVIDER_UPSIDE_SHARE,
    required_margin_fraction: float = REQUIRED_MARGIN_FRACTION,
) -> dict:
    """Maximum annual guarantee satisfying path solvency and expected margin."""
    bess = np.asarray(bess, dtype=float)
    renewable = np.asarray(renewable, dtype=float)
    mean_bess = float(bess.mean())
    required_margin = required_margin_fraction * mean_bess

    def diagnostics(guarantee: float):
        cash = (
            renewable
            + provider_upside_share * np.maximum(bess - guarantee, 0.0)
            - np.maximum(guarantee - bess, 0.0)
        )
        cumulative = np.cumsum(cash, axis=1)
        minimum = cumulative.min(axis=1)
        solvent = minimum >= -1e-8
        solvency = float(solvent.mean())
        mean_profit = float(cash.mean())
        feasible = (
            solvency >= solvency_level - 1e-12
            and mean_profit >= required_margin - 1e-7
        )
        return feasible, solvency, mean_profit, cash, cumulative

    lo = 0.0
    hi = max(1.0, 1.5 * float(bess.mean() + max(renewable.mean(), 0.0)))
    while diagnostics(hi)[0]:
        hi *= 1.5
    for _ in range(42):
        mid = 0.5 * (lo + hi)
        if diagnostics(mid)[0]:
            lo = mid
        else:
            hi = mid

    _, solvency, mean_profit, cash, cumulative = diagnostics(lo)
    max_deficit = np.maximum(-cumulative.min(axis=1), 0.0)
    return {
        "floor_gbp_per_bess_mw_year": float(lo / P_BESS_MW),
        "guarantee_gbp_year": float(lo),
        "solvency_fraction": solvency,
        "mean_provider_profit_gbp_per_bess_mw_year": mean_profit / P_BESS_MW,
        "first_year_deficit_fraction": float((cash[:, 0] < 0.0).mean()),
        "p95_maximum_cumulative_deficit_gbp_per_bess_mw": float(np.quantile(max_deficit, 0.95) / P_BESS_MW),
        "p99_maximum_cumulative_deficit_gbp_per_bess_mw": float(np.quantile(max_deficit, 0.99) / P_BESS_MW),
        "mean_terminal_reserve_gbp_per_bess_mw": float(cumulative[:, -1].mean() / P_BESS_MW),
        "median_terminal_reserve_gbp_per_bess_mw": float(np.median(cumulative[:, -1]) / P_BESS_MW),
        "mean_bess_revenue_gbp_per_bess_mw_year": mean_bess / P_BESS_MW,
        "mean_admitted_renewable_cash_gbp_per_bess_mw_year": float(renewable.mean() / P_BESS_MW),
        "required_margin_gbp_per_bess_mw_year": required_margin / P_BESS_MW,
    }


def right_arrays(scen: AnnualScenarioSet, right: str) -> Tuple[np.ndarray, np.ndarray]:
    if right == "signed":
        return scen.wind_signed, scen.solar_signed
    if right == "surplus_only":
        return scen.wind_surplus, scen.solar_surplus
    raise ValueError(right)


def path_arrays(
    scen: AnnualScenarioSet,
    n_paths: int,
    right: str,
    wind_weight: float,
    access_share: float = ACCESS_REFERENCE,
    renewable_scale_multiplier: float = 1.0,
) -> Tuple[np.ndarray, np.ndarray]:
    W, S = right_arrays(scen, right)
    B = reshape_paths(scen.bess, n_paths)
    R = reshape_paths(
        access_share
        * renewable_scale_multiplier
        * (wind_weight * W + (1.0 - wind_weight) * S),
        n_paths,
    )
    return B, R


def coarse_frontier(
    scen: AnnualScenarioSet,
    n_paths: int,
    right: str,
    q: float,
    *,
    access_share: float = ACCESS_REFERENCE,
    step: float = 0.05,
    renewable_scale_multiplier: float = 1.0,
) -> Tuple[pd.DataFrame, dict]:
    weights = np.round(np.arange(0.0, 1.0 + step / 2.0, step), 10)
    rows = []
    for weight in weights:
        B, R = path_arrays(
            scen, n_paths, right, float(weight), access_share, renewable_scale_multiplier
        )
        result = solve_path_floor(B, R, q)
        rows.append({"wind_revenue_exposure": float(weight), **result})
    df = pd.DataFrame(rows)
    i = int(df["floor_gbp_per_bess_mw_year"].idxmax())
    best = df.loc[i].to_dict()
    endpoints = max(df.iloc[0]["floor_gbp_per_bess_mw_year"], df.iloc[-1]["floor_gbp_per_bess_mw_year"])
    best["mix_premium_gbp_per_bess_mw_year"] = best["floor_gbp_per_bess_mw_year"] - endpoints
    near = df[df["floor_gbp_per_bess_mw_year"] >= 0.999 * best["floor_gbp_per_bess_mw_year"]]
    best["near_optimal_wind_min"] = float(near["wind_revenue_exposure"].min())
    best["near_optimal_wind_max"] = float(near["wind_revenue_exposure"].max())
    return df, best


def run_central(duration_daily: pd.DataFrame, n_paths: int) -> Tuple[pd.DataFrame, pd.DataFrame]:
    panel = live_panel_for_duration(2, duration_daily)
    all_rows = []
    frontier_rows = []
    for seed in SEEDS:
        scen = draw_both_rights(panel, n_paths * TENOR_YEARS, seed)
        B = reshape_paths(scen.bess, n_paths)
        standalone = {
            q: solve_path_floor(B, np.zeros_like(B), q) for q in SOLVENCY_LEVELS
        }
        for right in ("signed", "surplus_only"):
            for q in SOLVENCY_LEVELS:
                Bp, R50 = path_arrays(scen, n_paths, right, 0.50)
                result50 = solve_path_floor(Bp, R50, q)
                _, best = coarse_frontier(scen, n_paths, right, q, step=0.05)
                row = {
                    "seed": seed,
                    "n_paths": n_paths,
                    "duration_h": 2,
                    "right": right,
                    "solvency_level": q,
                    "bess_only_floor_gbp_per_bess_mw_year": standalone[q]["floor_gbp_per_bess_mw_year"],
                    "reference_wind_exposure": 0.50,
                    "reference_floor_gbp_per_bess_mw_year": result50["floor_gbp_per_bess_mw_year"],
                    "reference_uplift_gbp_per_bess_mw_year": result50["floor_gbp_per_bess_mw_year"] - standalone[q]["floor_gbp_per_bess_mw_year"],
                    "reference_uplift_fraction": result50["floor_gbp_per_bess_mw_year"] / standalone[q]["floor_gbp_per_bess_mw_year"] - 1.0,
                    "best_wind_exposure": best["wind_revenue_exposure"],
                    "best_floor_gbp_per_bess_mw_year": best["floor_gbp_per_bess_mw_year"],
                    "best_uplift_gbp_per_bess_mw_year": best["floor_gbp_per_bess_mw_year"] - standalone[q]["floor_gbp_per_bess_mw_year"],
                    "best_uplift_fraction": best["floor_gbp_per_bess_mw_year"] / standalone[q]["floor_gbp_per_bess_mw_year"] - 1.0,
                    "mix_premium_gbp_per_bess_mw_year": best["mix_premium_gbp_per_bess_mw_year"],
                    "near_optimal_wind_min": best["near_optimal_wind_min"],
                    "near_optimal_wind_max": best["near_optimal_wind_max"],
                    **{f"reference_{k}": v for k, v in result50.items() if k not in {"floor_gbp_per_bess_mw_year"}},
                }
                all_rows.append(row)
            frontier, _ = coarse_frontier(scen, n_paths, right, 0.95, step=0.01)
            frontier.insert(0, "right", right)
            frontier.insert(0, "seed", seed)
            frontier_rows.append(frontier)
    return pd.DataFrame(all_rows), pd.concat(frontier_rows, ignore_index=True)


def run_q95_confirmation(duration_daily: pd.DataFrame, n_paths: int = 50_000) -> pd.DataFrame:
    """Higher-path q95 replication at the fixed 50% wind reference design.

    The main paper uses one master contract specification for the headline,
    access, reserve and construction analyses. Wind-solar exposure is therefore
    fixed at 50% equal-mean cash exposure. Exposure optimisation remains a
    secondary composition sensitivity rather than part of the headline.
    """
    panel = live_panel_for_duration(2, duration_daily)
    rows = []
    for seed in SEEDS:
        scen = draw_both_rights(panel, n_paths * TENOR_YEARS, seed)
        B = reshape_paths(scen.bess, n_paths)
        standalone = solve_path_floor(B, np.zeros_like(B), 0.95)
        for right in ("signed", "surplus_only"):
            Bp, R = path_arrays(
                scen, n_paths, right, 0.50, ACCESS_REFERENCE
            )
            result = solve_path_floor(Bp, R, 0.95)
            floor = result["floor_gbp_per_bess_mw_year"]
            rows.append({
                "seed": seed,
                "n_paths": n_paths,
                "right": right,
                "wind_equal_mean_cash_share": 0.50,
                "bess_only_floor_gbp_per_bess_mw_year": standalone["floor_gbp_per_bess_mw_year"],
                "renewable_backed_floor_gbp_per_bess_mw_year": floor,
                "uplift_gbp_per_bess_mw_year": floor - standalone["floor_gbp_per_bess_mw_year"],
                "uplift_fraction": floor / standalone["floor_gbp_per_bess_mw_year"] - 1.0,
                **{
                    k: v for k, v in result.items()
                    if k not in {"floor_gbp_per_bess_mw_year"}
                },
            })
    return pd.DataFrame(rows)


def run_q95_exposure_optimised_sensitivity(
    duration_daily: pd.DataFrame, n_paths: int = 50_000
) -> pd.DataFrame:
    """Secondary 1-percentage-point wind-solar composition sensitivity."""
    panel = live_panel_for_duration(2, duration_daily)
    rows = []
    for seed in SEEDS:
        scen = draw_both_rights(panel, n_paths * TENOR_YEARS, seed)
        B = reshape_paths(scen.bess, n_paths)
        standalone = solve_path_floor(B, np.zeros_like(B), 0.95)
        for right in ("signed", "surplus_only"):
            _, best = coarse_frontier(scen, n_paths, right, 0.95, step=0.01)
            floor = best["floor_gbp_per_bess_mw_year"]
            rows.append({
                "seed": seed,
                "n_paths": n_paths,
                "right": right,
                "best_wind_revenue_exposure": best["wind_revenue_exposure"],
                "bess_only_floor_gbp_per_bess_mw_year": standalone["floor_gbp_per_bess_mw_year"],
                "renewable_backed_floor_gbp_per_bess_mw_year": floor,
                "uplift_gbp_per_bess_mw_year": floor - standalone["floor_gbp_per_bess_mw_year"],
                "uplift_fraction": floor / standalone["floor_gbp_per_bess_mw_year"] - 1.0,
                "mix_premium_gbp_per_bess_mw_year": best["mix_premium_gbp_per_bess_mw_year"],
                "near_optimal_wind_min": best["near_optimal_wind_min"],
                "near_optimal_wind_max": best["near_optimal_wind_max"],
            })
    return pd.DataFrame(rows)

def run_access_sensitivity(duration_daily: pd.DataFrame, n_paths: int = 20_000) -> pd.DataFrame:
    panel = live_panel_for_duration(2, duration_daily)
    rows = []
    for seed in SEEDS:
        scen = draw_both_rights(panel, n_paths * TENOR_YEARS, seed)
        B = reshape_paths(scen.bess, n_paths)
        standalone = solve_path_floor(B, np.zeros_like(B), 0.95)
        for right in ("signed", "surplus_only"):
            for access in (0.25, 0.50, 0.75):
                Bp, R = path_arrays(scen, n_paths, right, 0.50, access)
                result = solve_path_floor(Bp, R, 0.95)
                rows.append({
                    "seed": seed,
                    "right": right,
                    "access_share": access,
                    "bess_only_floor_gbp_per_bess_mw_year": standalone["floor_gbp_per_bess_mw_year"],
                    "renewable_backed_floor_gbp_per_bess_mw_year": result["floor_gbp_per_bess_mw_year"],
                    "uplift_gbp_per_bess_mw_year": result["floor_gbp_per_bess_mw_year"] - standalone["floor_gbp_per_bess_mw_year"],
                    "uplift_fraction": result["floor_gbp_per_bess_mw_year"] / standalone["floor_gbp_per_bess_mw_year"] - 1.0,
                    **{k: v for k, v in result.items() if k != "floor_gbp_per_bess_mw_year"},
                })
    return pd.DataFrame(rows)


def run_mean_matched_rights(duration_daily: pd.DataFrame, n_paths: int = 20_000) -> pd.DataFrame:
    panel = live_panel_for_duration(2, duration_daily)
    rows = []
    for seed in SEEDS:
        scen = draw_both_rights(panel, n_paths * TENOR_YEARS, seed)
        B, Rs = path_arrays(scen, n_paths, "signed", 0.50, ACCESS_REFERENCE)
        _, Rp = path_arrays(scen, n_paths, "surplus_only", 0.50, ACCESS_REFERENCE)
        matched_multiplier = float(Rs.mean() / Rp.mean())
        standalone = solve_path_floor(B, np.zeros_like(B), 0.95)
        signed = solve_path_floor(B, Rs, 0.95)
        surplus_raw = solve_path_floor(B, Rp, 0.95)
        surplus_matched = solve_path_floor(B, Rp * matched_multiplier, 0.95)
        for label, result, effective_access in [
            ("signed_reference", signed, ACCESS_REFERENCE),
            ("surplus_only_reference", surplus_raw, ACCESS_REFERENCE),
            ("surplus_only_mean_matched", surplus_matched, ACCESS_REFERENCE * matched_multiplier),
        ]:
            rows.append({
                "seed": seed,
                "case": label,
                "effective_access_share": effective_access,
                "mean_cash_match_multiplier": 1.0 if label != "surplus_only_mean_matched" else matched_multiplier,
                "bess_only_floor_gbp_per_bess_mw_year": standalone["floor_gbp_per_bess_mw_year"],
                "floor_gbp_per_bess_mw_year": result["floor_gbp_per_bess_mw_year"],
                "uplift_gbp_per_bess_mw_year": result["floor_gbp_per_bess_mw_year"] - standalone["floor_gbp_per_bess_mw_year"],
                "uplift_fraction": result["floor_gbp_per_bess_mw_year"] / standalone["floor_gbp_per_bess_mw_year"] - 1.0,
                **{k: v for k, v in result.items() if k != "floor_gbp_per_bess_mw_year"},
            })
    return pd.DataFrame(rows)


def run_duration_sensitivity(duration_daily: pd.DataFrame, n_paths: int = 20_000) -> Tuple[pd.DataFrame, pd.DataFrame]:
    fixed_rows = []
    normalised_rows = []
    for seed in SEEDS:
        scenario_by_duration: Dict[int, AnnualScenarioSet] = {}
        for duration in DURATIONS:
            panel = live_panel_for_duration(duration, duration_daily)
            scenario_by_duration[duration] = draw_both_rights(
                panel, n_paths * TENOR_YEARS, seed
            )

        for right in ("signed", "surplus_only"):
            ref_B, ref_R = path_arrays(
                scenario_by_duration[2], n_paths, right, 0.50, ACCESS_REFERENCE
            )
            target_ratio = float(ref_R.mean() / ref_B.mean())
            for duration in DURATIONS:
                scen = scenario_by_duration[duration]
                B, R = path_arrays(scen, n_paths, right, 0.50, ACCESS_REFERENCE)
                standalone = solve_path_floor(B, np.zeros_like(B), 0.95)
                fixed = solve_path_floor(B, R, 0.95)
                fixed_frontier, fixed_best = coarse_frontier(
                    scen, n_paths, right, 0.95, step=0.05
                )
                del fixed_frontier
                fixed_rows.append({
                    "seed": seed,
                    "duration_h": duration,
                    "right": right,
                    "renewable_reference_mw_per_100mw_bess": RENEWABLE_REFERENCE_MW,
                    "mean_renewable_to_bess_cash_ratio": float(R.mean() / B.mean()),
                    "bess_only_floor_gbp_per_bess_mw_year": standalone["floor_gbp_per_bess_mw_year"],
                    "reference_50_50_floor_gbp_per_bess_mw_year": fixed["floor_gbp_per_bess_mw_year"],
                    "reference_uplift_gbp_per_bess_mw_year": fixed["floor_gbp_per_bess_mw_year"] - standalone["floor_gbp_per_bess_mw_year"],
                    "reference_uplift_fraction": fixed["floor_gbp_per_bess_mw_year"] / standalone["floor_gbp_per_bess_mw_year"] - 1.0,
                    "best_wind_exposure": fixed_best["wind_revenue_exposure"],
                    "best_floor_gbp_per_bess_mw_year": fixed_best["floor_gbp_per_bess_mw_year"],
                    "mix_premium_gbp_per_bess_mw_year": fixed_best["mix_premium_gbp_per_bess_mw_year"],
                    "mean_bess_revenue_gbp_per_bess_mw_year": float(B.mean() / P_BESS_MW),
                })

                scale = target_ratio * float(B.mean()) / float(R.mean())
                normalised = solve_path_floor(B, R * scale, 0.95)
                normalised_rows.append({
                    "seed": seed,
                    "duration_h": duration,
                    "right": right,
                    "renewable_scale_multiplier": scale,
                    "effective_renewable_reference_mw_per_100mw_bess": RENEWABLE_REFERENCE_MW * scale,
                    "target_mean_renewable_to_bess_cash_ratio": target_ratio,
                    "actual_mean_renewable_to_bess_cash_ratio": float((R * scale).mean() / B.mean()),
                    "bess_only_floor_gbp_per_bess_mw_year": standalone["floor_gbp_per_bess_mw_year"],
                    "renewable_backed_floor_gbp_per_bess_mw_year": normalised["floor_gbp_per_bess_mw_year"],
                    "uplift_gbp_per_bess_mw_year": normalised["floor_gbp_per_bess_mw_year"] - standalone["floor_gbp_per_bess_mw_year"],
                    "uplift_fraction": normalised["floor_gbp_per_bess_mw_year"] / standalone["floor_gbp_per_bess_mw_year"] - 1.0,
                })
    return pd.DataFrame(fixed_rows), pd.DataFrame(normalised_rows)


def run_combined_lower_tail(duration_daily: pd.DataFrame, n: int = 100_000) -> pd.DataFrame:
    panel = live_panel_for_duration(2, duration_daily)
    rows = []
    for seed in SEEDS:
        scen = draw_both_rights(panel, n, seed)
        for right in ("signed", "surplus_only"):
            W, S = right_arrays(scen, right)
            R = ACCESS_REFERENCE * (0.50 * W + 0.50 * S)
            b_floor = lower_tail_mean(scen.bess) / P_BESS_MW
            r_floor = lower_tail_mean(R) / P_BESS_MW
            combined = lower_tail_mean(scen.bess + R) / P_BESS_MW
            total = combined - b_floor
            pooling = combined - b_floor - r_floor
            rows.append({
                "seed": seed,
                "right": right,
                "wind_revenue_exposure": 0.50,
                "bess_es05_floor_gbp_per_bess_mw_year": b_floor,
                "renewable_right_es05_floor_gbp_per_bess_mw_year": r_floor,
                "combined_es05_floor_gbp_per_bess_mw_year": combined,
                "total_combined_floor_increase_gbp_per_bess_mw_year": total,
                "incremental_pooling_gain_gbp_per_bess_mw_year": pooling,
                "pooling_share_of_total_increase": pooling / total,
                "mean_bess_revenue_gbp_per_bess_mw_year": float(scen.bess.mean() / P_BESS_MW),
                "mean_renewable_cash_gbp_per_bess_mw_year": float(R.mean() / P_BESS_MW),
            })
    return pd.DataFrame(rows)


def solve_strict_one_year(bess: np.ndarray, renewable: np.ndarray) -> dict:
    B = np.asarray(bess, dtype=float)
    R = np.asarray(renewable, dtype=float)
    required = REQUIRED_MARGIN_FRACTION * float(B.mean())

    def feasible(g: float) -> bool:
        cash = R + PROVIDER_UPSIDE_SHARE * np.maximum(B - g, 0.0) - np.maximum(g - B, 0.0)
        return float(cash.min()) >= -1e-8 and float(cash.mean()) >= required - 1e-7

    lo = 0.0
    hi = 1.5 * float(B.mean() + max(R.mean(), 0.0))
    while feasible(hi):
        hi *= 1.5
    for _ in range(45):
        mid = 0.5 * (lo + hi)
        if feasible(mid):
            lo = mid
        else:
            hi = mid
    return {"floor_gbp_per_bess_mw_year": lo / P_BESS_MW}


def run_strict_stress(duration_daily: pd.DataFrame, n: int = 20_000) -> Tuple[pd.DataFrame, pd.DataFrame]:
    panel = live_panel_for_duration(2, duration_daily)
    rows = []
    frontiers = []
    for seed in SEEDS:
        scen = draw_both_rights(panel, n, seed)
        standalone = solve_strict_one_year(scen.bess, np.zeros_like(scen.bess))
        for right in ("signed", "surplus_only"):
            W, S = right_arrays(scen, right)
            weight_rows = []
            for weight in np.round(np.arange(0.0, 1.0001, 0.01), 10):
                R = ACCESS_REFERENCE * (weight * W + (1.0 - weight) * S)
                result = solve_strict_one_year(scen.bess, R)
                weight_rows.append({
                    "seed": seed,
                    "right": right,
                    "wind_revenue_exposure": float(weight),
                    "floor_gbp_per_bess_mw_year": result["floor_gbp_per_bess_mw_year"],
                })
            f = pd.DataFrame(weight_rows)
            frontiers.append(f)
            best = f.loc[f["floor_gbp_per_bess_mw_year"].idxmax()]
            endpoints = max(f.iloc[0]["floor_gbp_per_bess_mw_year"], f.iloc[-1]["floor_gbp_per_bess_mw_year"])
            rows.append({
                "seed": seed,
                "right": right,
                "n_scenarios": n,
                "bess_only_floor_gbp_per_bess_mw_year": standalone["floor_gbp_per_bess_mw_year"],
                "best_wind_exposure": best["wind_revenue_exposure"],
                "best_floor_gbp_per_bess_mw_year": best["floor_gbp_per_bess_mw_year"],
                "uplift_gbp_per_bess_mw_year": best["floor_gbp_per_bess_mw_year"] - standalone["floor_gbp_per_bess_mw_year"],
                "uplift_fraction": best["floor_gbp_per_bess_mw_year"] / standalone["floor_gbp_per_bess_mw_year"] - 1.0,
                "mix_premium_gbp_per_bess_mw_year": best["floor_gbp_per_bess_mw_year"] - endpoints,
            })
    return pd.DataFrame(rows), pd.concat(frontiers, ignore_index=True)


def run_correlation_and_seasonality(duration_daily: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    panel = live_panel_for_duration(2, duration_daily).copy()
    hurdle_w, hurdle_s = pm.historical_hurdle(panel, HURDLE_FRACTION)
    # Apply the same daily-prorated historical hurdle to observed days.
    days = panel.groupby(["year", "month"])["date"].transform("count").to_numpy(float)
    month_ix = panel["month"].to_numpy(int) - 1
    panel["wind_signed"] = panel["wind_gross"] - hurdle_w[month_ix] / days
    panel["solar_signed"] = panel["solar_gross"] - hurdle_s[month_ix] / days
    panel["wind_surplus_only"] = np.maximum(panel["wind_signed"], 0.0)
    panel["solar_surplus_only"] = np.maximum(panel["solar_signed"], 0.0)

    rows = []
    for right, wc, sc in [
        ("gross", "wind_gross", "solar_gross"),
        ("signed", "wind_signed", "solar_signed"),
        ("surplus_only", "wind_surplus_only", "solar_surplus_only"),
    ]:
        for tech, col in [("wind", wc), ("solar", sc)]:
            demeaned_b = panel["bess_cash_gbp"] - panel.groupby("month")["bess_cash_gbp"].transform("mean")
            demeaned_r = panel[col] - panel.groupby("month")[col].transform("mean")
            rows.append({
                "level": "daily",
                "right": right,
                "technology": tech,
                "pearson_correlation_with_bess": float(panel["bess_cash_gbp"].corr(panel[col], method="pearson")),
                "spearman_correlation_with_bess": float(panel["bess_cash_gbp"].corr(panel[col], method="spearman")),
                "calendar_month_demeaned_pearson": float(demeaned_b.corr(demeaned_r)),
            })

    bottom = panel["bess_cash_gbp"] <= panel["bess_cash_gbp"].quantile(0.10)
    for right, wc, sc in [
        ("gross", "wind_gross", "solar_gross"),
        ("signed", "wind_signed", "solar_signed"),
        ("surplus_only", "wind_surplus_only", "solar_surplus_only"),
    ]:
        for tech, col in [("wind", wc), ("solar", sc)]:
            rows.append({
                "level": "bottom_decile_support",
                "right": right,
                "technology": tech,
                "pearson_correlation_with_bess": np.nan,
                "spearman_correlation_with_bess": np.nan,
                "calendar_month_demeaned_pearson": np.nan,
                "support_on_bottom_decile_bess_days_divided_by_full_sample_mean": float(panel.loc[bottom, col].mean() / panel[col].mean()),
            })

    monthly = (
        panel.groupby("month")[["bess_cash_gbp", "wind_gross", "solar_gross"]]
        .mean()
        .reset_index()
    )
    for c in ["bess_cash_gbp", "wind_gross", "solar_gross"]:
        monthly[f"{c}_normalised"] = monthly[c] / monthly[c].mean()
    return pd.DataFrame(rows), monthly


def write_summary_tables() -> None:
    # Produce concise manuscript-facing summaries from run-level results.
    def mean_sd(path: Path, group: list[str], cols: list[str], out_name: str):
        df = pd.read_csv(path)
        agg = df.groupby(group)[cols].agg(["mean", "std"]).reset_index()
        agg.columns = ["_".join([str(v) for v in c if v]) if isinstance(c, tuple) else str(c) for c in agg.columns]
        agg.to_csv(OUT / out_name, index=False)

    mean_sd(
        OUT / "path_solvency_q_grid_run_level.csv",
        ["right", "solvency_level"],
        [
            "bess_only_floor_gbp_per_bess_mw_year",
            "reference_floor_gbp_per_bess_mw_year",
            "reference_uplift_gbp_per_bess_mw_year",
            "reference_uplift_fraction",
            "best_floor_gbp_per_bess_mw_year",
            "mix_premium_gbp_per_bess_mw_year",
            "reference_p99_maximum_cumulative_deficit_gbp_per_bess_mw",
            "reference_mean_terminal_reserve_gbp_per_bess_mw",
        ],
        "path_solvency_q_grid_summary.csv",
    )
    mean_sd(
        OUT / "duration_fixed_support_run_level.csv",
        ["duration_h", "right"],
        [
            "bess_only_floor_gbp_per_bess_mw_year",
            "reference_50_50_floor_gbp_per_bess_mw_year",
            "reference_uplift_gbp_per_bess_mw_year",
            "reference_uplift_fraction",
            "mix_premium_gbp_per_bess_mw_year",
            "mean_bess_revenue_gbp_per_bess_mw_year",
        ],
        "duration_fixed_support_summary.csv",
    )
    mean_sd(
        OUT / "duration_mean_normalised_support_run_level.csv",
        ["duration_h", "right"],
        [
            "effective_renewable_reference_mw_per_100mw_bess",
            "bess_only_floor_gbp_per_bess_mw_year",
            "renewable_backed_floor_gbp_per_bess_mw_year",
            "uplift_gbp_per_bess_mw_year",
            "uplift_fraction",
        ],
        "duration_mean_normalised_support_summary.csv",
    )
    mean_sd(
        OUT / "combined_lower_tail_decomposition_run_level.csv",
        ["right"],
        [
            "bess_es05_floor_gbp_per_bess_mw_year",
            "renewable_right_es05_floor_gbp_per_bess_mw_year",
            "combined_es05_floor_gbp_per_bess_mw_year",
            "total_combined_floor_increase_gbp_per_bess_mw_year",
            "incremental_pooling_gain_gbp_per_bess_mw_year",
            "pooling_share_of_total_increase",
        ],
        "combined_lower_tail_decomposition_summary.csv",
    )


def run_smoke(duration_daily: pd.DataFrame, n_paths: int, seed: int) -> dict:
    """Fast integrity test of loading, scenario generation and the core floor solver."""
    panel = live_panel_for_duration(2, duration_daily)
    scen = draw_both_rights(panel, n_paths * TENOR_YEARS, seed)
    B = reshape_paths(scen.bess, n_paths)
    standalone = solve_path_floor(B, np.zeros_like(B), 0.95)
    out = {
        "mode": "smoke",
        "seed": seed,
        "n_paths": n_paths,
        "panel_days": int(len(panel)),
        "bess_only_floor_gbp_per_bess_mw_year": standalone["floor_gbp_per_bess_mw_year"],
    }
    for right in ("signed", "surplus_only"):
        Bp, R = path_arrays(scen, n_paths, right, 0.50)
        result = solve_path_floor(Bp, R, 0.95)
        out[f"{right}_floor_gbp_per_bess_mw_year"] = result["floor_gbp_per_bess_mw_year"]
        out[f"{right}_uplift_pct"] = 100.0 * (
            result["floor_gbp_per_bess_mw_year"] /
            standalone["floor_gbp_per_bess_mw_year"] - 1.0
        )
    return out


def main() -> None:
    global OUT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--smoke", action="store_true",
        help="Run a fast integrity test instead of the full manuscript analysis",
    )
    parser.add_argument(
        "--smoke-paths", type=int, default=500,
        help="Number of ten-year paths used by --smoke (default: 500)",
    )
    parser.add_argument(
        "--output-dir", type=Path, default=DEFAULT_OUT,
        help="Directory for reproduced outputs",
    )
    parser.add_argument("--force-duration-dispatch", action="store_true")
    args = parser.parse_args()
    OUT = args.output_dir.resolve()
    OUT.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    duration_daily = prepare_duration_daily(force=args.force_duration_dispatch)

    if args.smoke:
        result = run_smoke(duration_daily, max(50, args.smoke_paths), SEEDS[0])
        result["elapsed_seconds"] = time.time() - t0
        (OUT / "smoke_test_summary.json").write_text(
            json.dumps(result, indent=2), encoding="utf-8"
        )
        print(json.dumps(result, indent=2))
        return

    n_main, n_confirm, n_combined, n_strict = 20_000, 50_000, 100_000, 20_000

    central, frontiers = run_central(duration_daily, n_main)
    central.to_csv(OUT / "path_solvency_q_grid_run_level.csv", index=False)
    frontiers.to_csv(OUT / "q95_wind_solar_frontiers.csv", index=False)

    confirm = run_q95_confirmation(duration_daily, n_confirm)
    confirm.to_csv(OUT / "path_solvency_q95_fixed_confirmation_run_level.csv", index=False)

    # Exposure optimisation is retained only as a secondary composition check.
    optimised = run_q95_exposure_optimised_sensitivity(duration_daily, n_confirm)
    optimised.to_csv(OUT / "path_solvency_q95_exposure_optimised_run_level.csv", index=False)

    access = run_access_sensitivity(duration_daily, n_main)
    access.to_csv(OUT / "access_share_sensitivity_run_level.csv", index=False)

    matched = run_mean_matched_rights(duration_daily, n_main)
    matched.to_csv(OUT / "signed_surplus_mean_matched_run_level.csv", index=False)

    duration_fixed, duration_norm = run_duration_sensitivity(duration_daily, n_main)
    duration_fixed.to_csv(OUT / "duration_fixed_support_run_level.csv", index=False)
    duration_norm.to_csv(OUT / "duration_mean_normalised_support_run_level.csv", index=False)

    combined = run_combined_lower_tail(duration_daily, n_combined)
    combined.to_csv(OUT / "combined_lower_tail_decomposition_run_level.csv", index=False)

    strict, strict_frontiers = run_strict_stress(duration_daily, n_strict)
    strict.to_csv(OUT / "strict_one_year_zero_topup_run_level.csv", index=False)
    strict_frontiers.to_csv(OUT / "strict_one_year_zero_topup_frontiers.csv", index=False)

    correlation, seasonality = run_correlation_and_seasonality(duration_daily)
    correlation.to_csv(OUT / "correlation_lower_tail_diagnostics.csv", index=False)
    seasonality.to_csv(OUT / "monthly_seasonality_profiles.csv", index=False)

    write_summary_tables()
    metadata = {
        "version": "1.9.1",
        "run_timestamp_utc": pd.Timestamp.utcnow().isoformat(),
        "tenor_years": TENOR_YEARS,
        "solvency_definition": "fraction of paths whose cumulative reserve never falls below zero at annual settlement dates",
        "reference_solvency_level": 0.95,
        "reference_bess_power_mw": P_BESS_MW,
        "reference_bess_duration_h": 2,
        "renewable_reference_mw_per_100mw_bess": RENEWABLE_REFERENCE_MW,
        "reference_access_share": ACCESS_REFERENCE,
        "provider_upside_share": PROVIDER_UPSIDE_SHARE,
        "expected_margin_fraction_of_mean_bess_revenue": REQUIRED_MARGIN_FRACTION,
        "monthly_hurdle_fraction": HURDLE_FRACTION,
        "calendar_month_block_days": pm.CFG.block_days,
        "main_path_count_per_seed": n_main,
        "q95_confirmation_path_count_per_seed": n_confirm,
        "main_q_grid_wind_exposure_step": 0.05,
        "q95_confirmation_wind_exposure": 0.50,
        "secondary_q95_composition_grid_step": 0.01,
        "mechanism_reference_wind_exposure": 0.50,
        "wind_exposure_definition": "share of equal-mean renewable revenue exposure assigned to wind, not installed capacity",
        "combined_floor_annual_scenario_count_per_seed": n_combined,
        "strict_stress_annual_scenario_count_per_seed": n_strict,
        "seeds": list(SEEDS),
        "elapsed_seconds": time.time() - t0,
    }
    (OUT / "retained_reserve_analysis_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
