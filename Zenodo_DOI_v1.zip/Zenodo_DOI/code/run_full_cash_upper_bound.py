#!/usr/bin/env python3
"""Build the supplementary full-cross-collateralisation upper-bound diagnostic.

The diagnostic applies the paper's common q95 path-solvency and expected-margin
solver to (i) standalone BESS cash, (ii) the full gross renewable-cash stream at
the 25 MW-equivalent reference scale, and (iii) their fully pooled cash stream.
It is an upper bound on integrated contract capacity, not the paper's principal
BESS-specific residual-access contract and not a jointly enforceable pair of
standalone payment obligations.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / "code"))

import phase_model as pm  # noqa: E402
import run_retained_reserve_analysis as rr  # noqa: E402

DEFAULT_OUT = BASE / "reproduced_results" / "retained_reserve"


def binding_condition(result: dict, q: float) -> str:
    margin_slack = (
        result["mean_provider_profit_gbp_per_bess_mw_year"]
        - result["required_margin_gbp_per_bess_mw_year"]
    )
    if abs(margin_slack) <= 1e-4 and result["solvency_fraction"] > q + 1e-5:
        return "Margin"
    if abs(result["solvency_fraction"] - q) <= 1e-5:
        return "Solvency"
    return "Margin and solvency" if abs(margin_slack) <= 1e-4 else "Solvency"


def run(output_dir: Path, n_paths: int = 20_000, q: float = 0.95) -> tuple[pd.DataFrame, pd.DataFrame]:
    output_dir.mkdir(parents=True, exist_ok=True)
    panel = pm.load_live_panel()
    blocks = pm.build_blocks(panel)
    hurdle_w, hurdle_s = pm.historical_hurdle(panel, rr.HURDLE_FRACTION)

    rows: list[dict] = []
    for seed in rr.SEEDS:
        bess_annual, wind_gross, solar_gross = pm.draw_annual_right(
            blocks,
            n_paths * rr.TENOR_YEARS,
            seed,
            hurdle_w,
            hurdle_s,
            "gross",
        )

        # Equal-mean renewable scaling matches the reference contract design.
        target_per_mw = 0.5 * (float(wind_gross.mean()) + float(solar_gross.mean()))
        wind_scaled = (
            rr.RENEWABLE_REFERENCE_MW
            * target_per_mw
            / float(wind_gross.mean())
            * wind_gross
        )
        solar_scaled = (
            rr.RENEWABLE_REFERENCE_MW
            * target_per_mw
            / float(solar_gross.mean())
            * solar_gross
        )
        renewable_gross = 0.5 * wind_scaled + 0.5 * solar_scaled

        bess = rr.reshape_paths(bess_annual, n_paths)
        renewable = rr.reshape_paths(renewable_gross, n_paths)
        pooled = bess + renewable
        zero = np.zeros_like(bess)

        case_arrays = {
            "Standalone BESS": bess,
            "Standalone gross renewable cash": renewable,
            "Fully pooled BESS + renewable cash": pooled,
        }
        case_results: dict[str, dict] = {}
        for case, cash in case_arrays.items():
            result = rr.solve_path_floor(cash, zero, q)
            case_results[case] = result
            rows.append({
                "seed": seed,
                "n_paths": n_paths,
                "tenor_years": rr.TENOR_YEARS,
                "path_solvency_requirement": q,
                "cash_arrangement": case,
                "mean_cash_gbp_per_bess_mw_year": float(cash.mean() / rr.P_BESS_MW),
                "floor_gbp_per_bess_mw_year": result["floor_gbp_per_bess_mw_year"],
                "empirical_solvency_fraction": result["solvency_fraction"],
                "mean_provider_profit_gbp_per_bess_mw_year": result["mean_provider_profit_gbp_per_bess_mw_year"],
                "required_margin_gbp_per_bess_mw_year": result["required_margin_gbp_per_bess_mw_year"],
                "binding_condition": binding_condition(result, q),
            })

        separate_floor_sum = (
            case_results["Standalone BESS"]["floor_gbp_per_bess_mw_year"]
            + case_results["Standalone gross renewable cash"]["floor_gbp_per_bess_mw_year"]
        )
        pooled_floor = case_results["Fully pooled BESS + renewable cash"]["floor_gbp_per_bess_mw_year"]
        rows.append({
            "seed": seed,
            "n_paths": n_paths,
            "tenor_years": rr.TENOR_YEARS,
            "path_solvency_requirement": q,
            "cash_arrangement": "Sum of separately calculated floors",
            "mean_cash_gbp_per_bess_mw_year": float(pooled.mean() / rr.P_BESS_MW),
            "floor_gbp_per_bess_mw_year": separate_floor_sum,
            "empirical_solvency_fraction": np.nan,
            "mean_provider_profit_gbp_per_bess_mw_year": np.nan,
            "required_margin_gbp_per_bess_mw_year": np.nan,
            "binding_condition": "Not a joint contract",
        })
        rows.append({
            "seed": seed,
            "n_paths": n_paths,
            "tenor_years": rr.TENOR_YEARS,
            "path_solvency_requirement": q,
            "cash_arrangement": "Pooled contract-capacity increment",
            "mean_cash_gbp_per_bess_mw_year": 0.0,
            "floor_gbp_per_bess_mw_year": pooled_floor - separate_floor_sum,
            "empirical_solvency_fraction": np.nan,
            "mean_provider_profit_gbp_per_bess_mw_year": np.nan,
            "required_margin_gbp_per_bess_mw_year": np.nan,
            "binding_condition": "Upper-bound diagnostic",
        })

    run_level = pd.DataFrame(rows)
    order = [
        "Standalone BESS",
        "Standalone gross renewable cash",
        "Sum of separately calculated floors",
        "Fully pooled BESS + renewable cash",
        "Pooled contract-capacity increment",
    ]
    summary_rows: list[dict] = []
    for case in order:
        sub = run_level[run_level.cash_arrangement == case]
        summary_rows.append({
            "cash_arrangement": case,
            "mean_cash_gbp_per_bess_mw_year": float(sub.mean_cash_gbp_per_bess_mw_year.mean()),
            "floor_gbp_per_bess_mw_year": float(sub.floor_gbp_per_bess_mw_year.mean()),
            "empirical_solvency_pct": (
                float(100 * sub.empirical_solvency_fraction.mean())
                if sub.empirical_solvency_fraction.notna().any()
                else np.nan
            ),
            "binding_condition": sub.binding_condition.mode().iloc[0],
        })
    summary = pd.DataFrame(summary_rows)
    increment = float(summary.loc[
        summary.cash_arrangement == "Pooled contract-capacity increment",
        "floor_gbp_per_bess_mw_year",
    ].iloc[0])
    separate_sum = float(summary.loc[
        summary.cash_arrangement == "Sum of separately calculated floors",
        "floor_gbp_per_bess_mw_year",
    ].iloc[0])
    summary["increment_pct_of_separate_floor_sum"] = np.nan
    summary.loc[
        summary.cash_arrangement == "Pooled contract-capacity increment",
        "increment_pct_of_separate_floor_sum",
    ] = 100 * increment / separate_sum

    run_level.to_csv(output_dir / "full_cash_upper_bound_run_level.csv", index=False)
    summary.to_csv(output_dir / "Table_S39_full_cash_upper_bound.csv", index=False)
    metadata = {
        "description": "Supplementary full-cross-collateralisation upper-bound diagnostic",
        "n_paths_per_seed": n_paths,
        "seeds": list(rr.SEEDS),
        "tenor_years": rr.TENOR_YEARS,
        "path_solvency_requirement": q,
        "renewable_cash_scale_mw_equivalent_per_100_mw_bess": rr.RENEWABLE_REFERENCE_MW,
        "wind_equal_mean_cash_exposure": 0.5,
        "provider_upside_share": rr.PROVIDER_UPSIDE_SHARE,
        "required_margin_fraction": rr.REQUIRED_MARGIN_FRACTION,
        "interpretive_boundary": (
            "The separate sum is not a jointly enforceable pair of obligations. "
            "Gross renewable cash is used only as a full-cross-collateralisation upper bound."
        ),
    }
    (output_dir / "full_cash_upper_bound_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    return run_level, summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--paths", type=int, default=20_000)
    parser.add_argument("--q", type=float, default=0.95)
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    _, table = run(args.output_dir, args.paths, args.q)
    print(table.to_string(index=False))
