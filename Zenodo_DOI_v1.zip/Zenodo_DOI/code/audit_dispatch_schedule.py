#!/usr/bin/env python3
"""Audit the exact rolling-Ridge dispatch and reconcile its daily BESS revenue.

The input is the retained period-level schedule used to create the canonical
headline BESS daily revenue series. The script does not reconstruct or
substitute another schedule. It reports simultaneous operation at a stated
numerical tolerance, writes flagged periods if any, and reconciles regenerated
daily revenue against the packaged canonical daily series.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import hashlib

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = BASE / "data" / "contract" / "reference_halfhour_dispatch.csv.gz"
DEFAULT_DAILY = BASE / "data" / "operating" / "reference_daily_cash.csv.gz"
DEFAULT_REGENERATED_DAILY = BASE / "data" / "contract" / "reference_daily_cash_regenerated.csv.gz"
DEFAULT_OUTPUT = BASE / "reproduced_results" / "dispatch" / "canonical_ridge_dispatch_audit.csv"


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dispatch", type=Path, default=DEFAULT_INPUT)
    p.add_argument("--canonical-daily", type=Path, default=DEFAULT_DAILY)
    p.add_argument("--regenerated-daily", type=Path, default=DEFAULT_REGENERATED_DAILY)
    p.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    p.add_argument("--tolerance-mw", type=float, default=1e-8)
    p.add_argument("--interval-hours", type=float, default=0.5)
    return p.parse_args()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    a = parse_args()
    if not a.dispatch.exists():
        raise FileNotFoundError(f"Canonical rolling-Ridge schedule is missing: {a.dispatch}")
    if not a.canonical_daily.exists():
        raise FileNotFoundError(f"Canonical daily revenue series is missing: {a.canonical_daily}")

    f = pd.read_csv(a.dispatch)
    required = {"charge_mw", "discharge_mw", "bess_cash_gbp"}
    missing = required.difference(f.columns)
    if missing:
        raise ValueError(f"Missing required dispatch columns: {sorted(missing)}")

    charge = pd.to_numeric(f["charge_mw"], errors="raise").to_numpy(float)
    discharge = pd.to_numeric(f["discharge_mw"], errors="raise").to_numpy(float)
    simultaneous = np.minimum(np.maximum(charge, 0.0), np.maximum(discharge, 0.0))
    flagged = simultaneous > a.tolerance_mw

    start = pd.to_datetime(f["start_time"], utc=True, errors="raise") if "start_time" in f else pd.Series(pd.NaT, index=f.index)
    result = {
        "canonical_dispatch": "yearly rolling Ridge; 48 h horizon; first 24 h executed",
        "periods": int(len(f)),
        "start_time": start.min().isoformat() if start.notna().any() else "",
        "end_time": start.max().isoformat() if start.notna().any() else "",
        "tolerance_mw": float(a.tolerance_mw),
        "simultaneous_periods": int(flagged.sum()),
        "maximum_simultaneous_mw": float(simultaneous.max(initial=0.0)),
        "simultaneous_mwh": float(simultaneous.sum() * a.interval_hours),
        "simultaneous_fraction_of_throughput": float(
            (simultaneous.sum() * a.interval_hours) /
            max(float(pd.to_numeric(f.get("throughput_mwh", pd.Series(0.0, index=f.index)), errors="coerce").fillna(0).sum()), 1e-30)
        ),
        "max_charge_mw": float(np.max(charge, initial=0.0)),
        "max_discharge_mw": float(np.max(discharge, initial=0.0)),
        "max_combined_power_mw": float(np.max(charge + discharge, initial=0.0)),
        "min_soc_mwh": float(pd.to_numeric(f.get("soc_mwh", pd.Series(np.nan, index=f.index)), errors="coerce").min()),
        "max_soc_mwh": float(pd.to_numeric(f.get("soc_mwh", pd.Series(np.nan, index=f.index)), errors="coerce").max()),
        "forecast_periods_below_minus_total_cost": int((pd.to_numeric(f.get("price_forecast_gbp_mwh", pd.Series(np.nan, index=f.index)), errors="coerce") < -4.25).sum()),
        "actual_periods_below_minus_total_cost": int((pd.to_numeric(f.get("price_actual_gbp_mwh", pd.Series(np.nan, index=f.index)), errors="coerce") < -4.25).sum()),
        "total_bess_cash_gbp": float(pd.to_numeric(f["bess_cash_gbp"], errors="raise").sum()),
        "annualised_bess_cash_gbp": float(pd.to_numeric(f["bess_cash_gbp"], errors="raise").sum() / 6.0),
        "zero_simultaneous_result": bool(flagged.sum() == 0),
        "schedule_sha256": sha256(a.dispatch),
    }
    a.output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame([result]).to_csv(a.output, index=False)

    flagged_path = a.output.with_name(a.output.stem + "_flagged_periods.csv")
    if flagged.any():
        cols = [c for c in ("start_time", "date", "settlement_period_utc", "charge_mw", "discharge_mw") if c in f.columns]
        details = f.loc[flagged, cols].copy()
        details["simultaneous_mw"] = simultaneous[flagged]
        details["simultaneous_mwh"] = simultaneous[flagged] * a.interval_hours
        details.to_csv(flagged_path, index=False)
    elif flagged_path.exists():
        flagged_path.unlink()

    # Daily reconciliation. The period schedule is re-aggregated independently;
    # the retained regenerated daily file is also compared because it preserves
    # the exact summation order used by the schedule-export run.
    if "date" in f.columns:
        dispatch_dates = pd.to_datetime(f["date"], utc=True, errors="raise").dt.normalize()
    elif "start_time" in f.columns:
        dispatch_dates = pd.to_datetime(f["start_time"], utc=True, errors="raise").dt.normalize()
    else:
        raise ValueError("Dispatch must contain date or start_time for daily reconciliation")
    schedule_daily = pd.DataFrame({"date": dispatch_dates, "bess_cash_schedule_aggregated_gbp": pd.to_numeric(f["bess_cash_gbp"], errors="raise")}).groupby("date", as_index=False, sort=True).sum()
    canonical = pd.read_csv(a.canonical_daily, usecols=["date", "bess_cash_gbp"])
    canonical["date"] = pd.to_datetime(canonical["date"], utc=True, errors="raise").dt.normalize()
    canonical = canonical.rename(columns={"bess_cash_gbp": "bess_cash_canonical_gbp"})
    merged_schedule = canonical.merge(schedule_daily, on="date", how="outer", indicator=True)
    both_schedule = merged_schedule[merged_schedule["_merge"] == "both"].copy()
    diff_schedule = both_schedule["bess_cash_schedule_aggregated_gbp"] - both_schedule["bess_cash_canonical_gbp"]

    retained_max = float("nan")
    retained_mean = float("nan")
    retained_rmse = float("nan")
    retained_total = float("nan")
    retained_rows = 0
    retained_only = 0
    canonical_only_retained = 0
    if a.regenerated_daily.exists():
        retained = pd.read_csv(a.regenerated_daily, usecols=["date", "bess_cash_gbp"])
        retained["date"] = pd.to_datetime(retained["date"], utc=True, errors="raise").dt.normalize()
        retained = retained.rename(columns={"bess_cash_gbp": "bess_cash_retained_regenerated_gbp"})
        merged_retained = canonical.merge(retained, on="date", how="outer", indicator=True)
        both_retained = merged_retained[merged_retained["_merge"] == "both"].copy()
        diff_retained = both_retained["bess_cash_retained_regenerated_gbp"] - both_retained["bess_cash_canonical_gbp"]
        retained_max = float(diff_retained.abs().max())
        retained_mean = float(diff_retained.abs().mean())
        retained_rmse = float(np.sqrt(np.mean(diff_retained.to_numpy(float) ** 2)))
        retained_total = float(diff_retained.sum())
        retained_rows = int(len(retained))
        canonical_only_retained = int((merged_retained["_merge"] == "left_only").sum())
        retained_only = int((merged_retained["_merge"] == "right_only").sum())

    schedule_pass = (int((merged_schedule["_merge"] != "both").sum()) == 0 and float(diff_schedule.abs().max()) < 1e-6)
    retained_pass = (not a.regenerated_daily.exists()) or (canonical_only_retained == 0 and retained_only == 0 and retained_max < 1e-6)
    recon = {
        "status": "PASS_STRICT" if schedule_pass and retained_pass else "FAIL",
        "reconciliation_tolerance_gbp": 1e-6,
        "canonical_rows": int(len(canonical)),
        "schedule_aggregated_rows": int(len(schedule_daily)),
        "retained_regenerated_rows": retained_rows,
        "matched_schedule_dates": int(len(both_schedule)),
        "canonical_only_schedule_dates": int((merged_schedule["_merge"] == "left_only").sum()),
        "schedule_only_dates": int((merged_schedule["_merge"] == "right_only").sum()),
        "schedule_aggregated_max_absolute_daily_difference_gbp": float(diff_schedule.abs().max()),
        "schedule_aggregated_total_difference_gbp": float(diff_schedule.sum()),
        "retained_regenerated_max_absolute_daily_difference_gbp": retained_max,
        "retained_regenerated_mean_absolute_daily_difference_gbp": retained_mean,
        "retained_regenerated_rmse_daily_difference_gbp": retained_rmse,
        "retained_regenerated_total_difference_gbp": retained_total,
        "canonical_only_retained_dates": canonical_only_retained,
        "retained_only_dates": retained_only,
        "canonical_total_bess_cash_gbp": float(canonical["bess_cash_canonical_gbp"].sum()),
        "schedule_aggregated_total_bess_cash_gbp": float(schedule_daily["bess_cash_schedule_aggregated_gbp"].sum()),
        "canonical_daily_sha256": sha256(a.canonical_daily),
        "retained_regenerated_daily_sha256": sha256(a.regenerated_daily) if a.regenerated_daily.exists() else "",
    }
    recon_path = a.output.with_name("canonical_daily_cash_reconciliation.csv")
    pd.DataFrame([recon]).to_csv(recon_path, index=False)

    print(pd.DataFrame([result]).to_string(index=False))
    print(pd.DataFrame([recon]).to_string(index=False))
    if result["simultaneous_periods"] != 0 or recon["status"] != "PASS_STRICT":
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
