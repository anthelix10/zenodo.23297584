#!/usr/bin/env python3
"""Focused methodological extensions for the renewable-backed BESS floor paper."""
from __future__ import annotations
import argparse, json, math, sys, time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional, Tuple
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]; CODE=ROOT/'code'; sys.path.insert(0,str(CODE))
import phase_model as pm
import run_retained_reserve_analysis as rr

Q=.95; Z=1.6448536269514722
DEFAULT_OUT=ROOT/'reproduced_results'/'methodological_extensions'

@dataclass
class DrawConfig:
    hurdle_w: np.ndarray; hurdle_s: np.ndarray
    signed_scale_w: float; signed_scale_s: float
    surplus_scale_w: float; surplus_scale_s: float

def wilson_lower(successes:int,n:int,z:float=Z)->float:
    p=successes/n; z2=z*z
    return (p+z2/(2*n)-z*math.sqrt(p*(1-p)/n+z2/(4*n*n)))/(1+z2/n)

def draw_configured(panel:pd.DataFrame,n:int,seed:int,*,hurdle_fraction:float=rr.HURDLE_FRACTION,frozen:Optional[DrawConfig]=None,chunk:int=25000):
    blocks=pm.build_blocks(panel)
    if frozen is None: hw,hs=pm.historical_hurdle(panel,hurdle_fraction)
    else: hw,hs=frozen.hurdle_w,frozen.hurdle_s
    rng=np.random.default_rng(seed)
    B=np.zeros(n); Ws=np.zeros(n); Ss=np.zeros(n); Wp=np.zeros(n); Sp=np.zeros(n)
    for month in range(1,13):
        z=blocks[month]; nb=math.ceil(z.target_days/z.b.shape[1])
        for lo in range(0,n,chunk):
            hi=min(n,lo+chunk); rows=hi-lo
            ch=rng.integers(0,len(z.b),size=(rows,nb))
            bd=z.b[ch].reshape(rows,-1)[:,:z.target_days]
            wd=z.w[ch].reshape(rows,-1)[:,:z.target_days]
            sd=z.s[ch].reshape(rows,-1)[:,:z.target_days]
            source=np.repeat(z.source_days[ch],z.b.shape[1],axis=1)[:,:z.target_days]
            wr=wd-hw[month-1]/source; sr=sd-hs[month-1]/source
            B[lo:hi]+=bd.sum(1); Ws[lo:hi]+=wr.sum(1); Ss[lo:hi]+=sr.sum(1)
            Wp[lo:hi]+=np.maximum(wr,0).sum(1); Sp[lo:hi]+=np.maximum(sr,0).sum(1)
    if frozen is None:
        def scale(w,s):
            target=.5*(float(w.mean())+float(s.mean()))
            return rr.RENEWABLE_REFERENCE_MW*target/float(w.mean()), rr.RENEWABLE_REFERENCE_MW*target/float(s.mean())
        ssw,sss=scale(Ws,Ss); spw,sps=scale(Wp,Sp)
        frozen=DrawConfig(np.asarray(hw),np.asarray(hs),ssw,sss,spw,sps)
    scen=rr.AnnualScenarioSet(B,frozen.signed_scale_w*Ws,frozen.signed_scale_s*Ss,frozen.surplus_scale_w*Wp,frozen.surplus_scale_s*Sp)
    return scen,frozen

def reserve_diag(B,R,g,*,opening=0.,schedule=None,cap=None,annual_fee=0.):
    B=np.asarray(B,float); R=np.asarray(R,float); n,T=B.shape
    schedule=np.ones(T) if schedule is None else np.asarray(schedule,float)
    G=g*schedule[None,:]
    cash=R-annual_fee+rr.PROVIDER_UPSIDE_SHARE*np.maximum(B-G,0)-np.maximum(G-B,0)
    reserve=np.full(n,opening); hist=np.empty_like(cash); prehist=np.empty_like(cash); dist=np.zeros_like(cash)
    for t in range(T):
        pre=reserve+cash[:,t]; prehist[:,t]=pre
        if cap is not None:
            dist[:,t]=np.maximum(pre-cap,0); reserve=pre-dist[:,t]
        else: reserve=pre
        hist[:,t]=reserve
    mind=prehist.min(1); solvent=mind>=-1e-8
    return dict(cash=cash,reserve=hist,pre=prehist,dist=dist,solvent=solvent,maxdef=np.maximum(-mind,0),mean_cash=float(cash.mean()))

def solve_floor(B,R,q=Q,*,opening=0.,schedule=None,cap=None,wilson=False):
    B=np.asarray(B,float); R=np.asarray(R,float); req=rr.REQUIRED_MARGIN_FRACTION*float(B.mean())
    def test(g):
        d=reserve_diag(B,R,g,opening=opening,schedule=schedule,cap=cap)
        succ=int(d['solvent'].sum()); p=succ/len(d['solvent']); lb=wilson_lower(succ,len(d['solvent']))
        ok=(lb>=q-1e-12 if wilson else p>=q-1e-12) and d['mean_cash']>=req-1e-7
        return ok,d,p,lb
    lo=0.; hi=max(1.,1.5*float(B.mean()+max(R.mean(),0)))
    while test(hi)[0]: hi*=1.5
    for _ in range(44):
        mid=.5*(lo+hi)
        if test(mid)[0]: lo=mid
        else: hi=mid
    _,d,p,lb=test(lo); sch=np.ones(B.shape[1]) if schedule is None else np.asarray(schedule,float)
    return dict(floor=lo/rr.P_BESS_MW,average_floor=lo*sch.mean()/rr.P_BESS_MW,solvency=p,wilson_lower=lb,
                mean_profit=d['mean_cash']/rr.P_BESS_MW,first_year_deficit=float((d['cash'][:,0]<0).mean()),
                p99_bridge=float(np.quantile(d['maxdef'],.99)/rr.P_BESS_MW),terminal=float(d['reserve'][:,-1].mean()/rr.P_BESS_MW),
                annual_distribution=float(d['dist'].mean()/rr.P_BESS_MW),total_distribution=float(d['dist'].sum(1).mean()/rr.P_BESS_MW))

def evaluate(B,R,floor):
    d=reserve_diag(B,R,floor*rr.P_BESS_MW); succ=int(d['solvent'].sum()); n=len(d['solvent']); p=succ/n; lb=wilson_lower(succ,n)
    req=rr.REQUIRED_MARGIN_FRACTION*float(B.mean())
    return dict(eval_solvency=p,eval_wilson_lower=lb,eval_empirical_pass=float(p>=Q),eval_wilson_pass=float(lb>=Q),eval_margin_pass=float(d['mean_cash']>=req-1e-7),eval_p99_bridge=float(np.quantile(d['maxdef'],.99)/rr.P_BESS_MW))

def summary(df,groups,cols):
    out=[]
    for keys,g in df.groupby(groups,dropna=False):
        if not isinstance(keys,tuple): keys=(keys,)
        r=dict(zip(groups,keys))
        for c in cols:
            x=pd.to_numeric(g[c],errors='coerce').dropna().to_numpy(float)
            if not len(x): continue
            r[c+'_mean']=float(x.mean()); r[c+'_sd']=float(x.std(ddof=1)) if len(x)>1 else 0.; r[c+'_p025']=float(np.quantile(x,.025)); r[c+'_median']=float(np.median(x)); r[c+'_p975']=float(np.quantile(x,.975))
        out.append(r)
    return pd.DataFrame(out)

def bootstrap_panel(panel,rng):
    pieces=[]; targets=list(panel.groupby(['year','month'],sort=True).groups.keys()); bym={}
    for y,m in targets: bym.setdefault(int(m),[]).append((int(y),int(m)))
    for ty,m in targets:
        sy,sm=bym[int(m)][int(rng.integers(0,len(bym[int(m)])))]
        g=panel[(panel.year==sy)&(panel.month==sm)].copy().sort_values('date').reset_index(drop=True)
        g['year']=int(ty); g['month']=int(m); base=pd.Timestamp(2100+(int(ty)-2020),int(m),1); g['date']=base+pd.to_timedelta(np.arange(len(g)),unit='D')
        pieces.append(g)
    return pd.concat(pieces,ignore_index=True)

def base_scen(panel,npaths,seed):
    scen=rr.draw_both_rights(panel,npaths*rr.TENOR_YEARS,seed); B=rr.reshape_paths(scen.bess,npaths)
    rights={'bess_only':np.zeros_like(B),'signed':rr.path_arrays(scen,npaths,'signed',.5)[1],'surplus_only':rr.path_arrays(scen,npaths,'surplus_only',.5)[1]}
    return scen,B,rights

def run_frontier(panel,npaths):
    rows=[]
    for seed in rr.SEEDS:
        _,B,rights=base_scen(panel,npaths,seed)
        for case,R in rights.items():
            for k in [0,250,500,1000,1500,2500,5000,10000]:
                r=solve_floor(B,R,opening=k*rr.P_BESS_MW); rows.append(dict(seed=seed,case=case,opening_reserve=k,**r))
    return pd.DataFrame(rows)

def run_tenor(panel,npaths):
    rows=[]; schedules={'one_year_immediate':np.ones(1),'ten_year_immediate':np.ones(10),'ten_year_50pct_first_year':np.r_[.5,np.ones(9)],'ten_year_reserve_build_year':np.r_[0.,np.ones(9)]}
    for seed in rr.SEEDS:
        _,B10,rights=base_scen(panel,npaths,seed)
        for name,sch in schedules.items():
            B=B10[:,:1] if len(sch)==1 else B10
            for case,R10 in rights.items():
                R=R10[:,:1] if len(sch)==1 else R10; r=solve_floor(B,R,schedule=sch); rows.append(dict(seed=seed,case=case,schedule_case=name,years=len(sch),first_year_fraction=sch[0],mean_fraction=sch.mean(),**r))
    return pd.DataFrame(rows)

def run_caps(panel,npaths):
    rows=[]
    for seed in rr.SEEDS:
        _,B,rights=base_scen(panel,npaths,seed)
        for right in ['signed','surplus_only']:
            for cap in [1000,1500,2500,5000,10000,None]:
                r=solve_floor(B,rights[right],cap=None if cap is None else cap*rr.P_BESS_MW); rows.append(dict(seed=seed,right=right,target='unlimited' if cap is None else str(cap),**r))
    return pd.DataFrame(rows)

def max_fee(B,R,G):
    req=rr.REQUIRED_MARGIN_FRACTION*float(B.mean()); g=G*rr.P_BESS_MW
    def ok(f):
        d=reserve_diag(B,R,g,annual_fee=f); return d['solvent'].mean()>=Q-1e-12 and d['mean_cash']>=req-1e-7
    lo=0.; hi=max(1.,2*max(float(R.mean()),0))
    while ok(hi): hi*=1.5
    for _ in range(44):
        mid=.5*(lo+hi)
        if ok(mid): lo=mid
        else: hi=mid
    return lo/rr.P_BESS_MW

def run_fees(panel,npaths):
    rows=[]
    for seed in rr.SEEDS:
        scen,B,rights=base_scen(panel,npaths,seed); G=rr.solve_path_floor(B,np.zeros_like(B),Q)['floor_gbp_per_bess_mw_year']; Rs=rights['signed']; Rp=rights['surplus_only']; mult=float(Rs.mean()/Rp.mean())
        for case,R,access in [('signed_50pct',Rs,.5),('surplus_only_50pct',Rp,.5),('surplus_only_mean_matched',Rp*mult,.5*mult)]:
            fee=max_fee(B,R,G); rows.append(dict(seed=seed,case=case,effective_access=access,standalone_floor=G,admitted_cash=float(R.mean()/rr.P_BESS_MW),max_fee=fee,fee_fraction=fee/(float(R.mean()/rr.P_BESS_MW))))
    return pd.DataFrame(rows)

def run_hurdle(panel,npaths):
    rows=[]
    for seed in rr.SEEDS:
        for h in [.5,.7,.9]:
            scen,_=draw_configured(panel,npaths*10,seed,hurdle_fraction=h); B=rr.reshape_paths(scen.bess,npaths); base=rr.solve_path_floor(B,np.zeros_like(B),Q)['floor_gbp_per_bess_mw_year']
            for right in ['signed','surplus_only']:
                R=rr.path_arrays(scen,npaths,right,.5)[1]; res=rr.solve_path_floor(B,R,Q); f=res['floor_gbp_per_bess_mw_year']; rows.append(dict(seed=seed,right=right,hurdle_fraction=h,bess_only=base,floor=f,uplift=f-base,uplift_fraction=f/base-1,admitted_cash=float(R.mean()/rr.P_BESS_MW)))
    return pd.DataFrame(rows)

def run_alt(panel_canonical,duration_daily,npaths):
    alt=pd.read_csv(ROOT/'results'/'operating_phase'/'alternative_bess_daily_cash.csv',parse_dates=['date']); panels={'canonical_ridge':panel_canonical}
    for s,g in alt.groupby('strategy'): panels[str(s)]=pm.load_live_panel(g[['date','bess_cash_gbp']])
    rows=[]
    for strategy,panel in panels.items():
        for seed in rr.SEEDS:
            scen=rr.draw_both_rights(panel,npaths*10,seed); B=rr.reshape_paths(scen.bess,npaths); base=rr.solve_path_floor(B,np.zeros_like(B),Q)['floor_gbp_per_bess_mw_year']
            for right in ['signed','surplus_only']:
                R=rr.path_arrays(scen,npaths,right,.5)[1]; f=rr.solve_path_floor(B,R,Q)['floor_gbp_per_bess_mw_year']; rows.append(dict(seed=seed,strategy=strategy,right=right,panel_days=len(panel),bess_only=base,floor=f,uplift=f-base,uplift_fraction=f/base-1))
    return pd.DataFrame(rows)

def run_nested(panel,reps,ntrain,neval,seed=20260815):
    rows=[]; master=np.random.default_rng(seed)
    for rep in range(reps):
        boot=bootstrap_panel(panel,np.random.default_rng(int(master.integers(0,2**32-1)))); ts=int(master.integers(0,2**32-1)); es=int(master.integers(0,2**32-1))
        train,cfg=draw_configured(boot,ntrain*10,ts); ev,_=draw_configured(boot,neval*10,es,frozen=cfg); Bt=rr.reshape_paths(train.bess,ntrain); Be=rr.reshape_paths(ev.bess,neval)
        Rt={'bess_only':np.zeros_like(Bt),'signed':rr.path_arrays(train,ntrain,'signed',.5)[1],'surplus_only':rr.path_arrays(train,ntrain,'surplus_only',.5)[1]}; Re={'bess_only':np.zeros_like(Be),'signed':rr.path_arrays(ev,neval,'signed',.5)[1],'surplus_only':rr.path_arrays(ev,neval,'surplus_only',.5)[1]}
        selected={}
        for rule,w in [('empirical_q',False),('wilson_lower_bound',True)]:
            for case in ['bess_only','signed','surplus_only']:
                res=solve_floor(Bt,Rt[case],wilson=w); selected[(rule,case)]=res['floor']; rows.append(dict(replication=rep,calibration_rule=rule,case=case,selected_floor=res['floor'],training_solvency=res['solvency'],training_wilson_lower=res['wilson_lower'],**evaluate(Be,Re[case],res['floor'])))
        for rule in ['empirical_q','wilson_lower_bound']:
            base=selected[(rule,'bess_only')]
            for case in ['signed','surplus_only']:
                for row in reversed(rows):
                    if row['replication']==rep and row['calibration_rule']==rule and row['case']==case:
                        row['paired_uplift']=selected[(rule,case)]-base; row['paired_uplift_fraction']=(selected[(rule,case)]-base)/base; break
        if (rep+1)%max(1,reps//10)==0: print(f'nested {rep+1}/{reps}',flush=True)
    return pd.DataFrame(rows)

def save_all(out,panel,duration_daily,npaths,reps,ntrain,neval):
    out.mkdir(parents=True,exist_ok=True)
    f=run_frontier(panel,npaths); f.to_csv(out/'guarantee_opening_reserve_frontier_run_level.csv',index=False); summary(f,['case','opening_reserve'],['floor','solvency','mean_profit','terminal']).to_csv(out/'guarantee_opening_reserve_frontier_summary.csv',index=False)
    t=run_tenor(panel,npaths); t.to_csv(out/'tenor_and_staged_floor_run_level.csv',index=False); summary(t,['case','schedule_case'],['floor','average_floor','p99_bridge','terminal']).to_csv(out/'tenor_and_staged_floor_summary.csv',index=False)
    c=run_caps(panel,npaths); c.to_csv(out/'reserve_target_distribution_run_level.csv',index=False); summary(c,['right','target'],['floor','annual_distribution','terminal','p99_bridge']).to_csv(out/'reserve_target_distribution_summary.csv',index=False)
    fee=run_fees(panel,npaths); fee.to_csv(out/'access_fee_run_level.csv',index=False); summary(fee,['case'],['max_fee','fee_fraction','admitted_cash']).to_csv(out/'access_fee_summary.csv',index=False)
    h=run_hurdle(panel,npaths); h.to_csv(out/'renewable_hurdle_sensitivity_run_level.csv',index=False); summary(h,['right','hurdle_fraction'],['floor','uplift','uplift_fraction','admitted_cash']).to_csv(out/'renewable_hurdle_sensitivity_summary.csv',index=False)
    a=run_alt(panel,duration_daily,npaths); a.to_csv(out/'alternative_bess_schedule_run_level.csv',index=False); summary(a,['strategy','right'],['bess_only','floor','uplift','uplift_fraction']).to_csv(out/'alternative_bess_schedule_summary.csv',index=False)
    n=run_nested(panel,reps,ntrain,neval); n.to_csv(out/'frozen_contract_nested_bootstrap_run_level.csv',index=False); summary(n,['calibration_rule','case'],['selected_floor','paired_uplift','paired_uplift_fraction','eval_solvency','eval_wilson_lower','eval_empirical_pass','eval_wilson_pass','eval_margin_pass','eval_p99_bridge']).to_csv(out/'frozen_contract_nested_bootstrap_summary.csv',index=False)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output-dir',type=Path,default=DEFAULT_OUT); ap.add_argument('--paths',type=int,default=20000); ap.add_argument('--nested-reps',type=int,default=120); ap.add_argument('--nested-train-paths',type=int,default=2000); ap.add_argument('--nested-eval-paths',type=int,default=5000); ap.add_argument('--nested-seed',type=int,default=20260815); ap.add_argument('--segment',choices=['core','extra','nested','all'],default='all'); args=ap.parse_args()
    out=args.output_dir.resolve(); out.mkdir(parents=True,exist_ok=True); d=rr.prepare_duration_daily(False); panel=rr.live_panel_for_duration(2,d); t=time.time()
    if args.segment in ['core','all']:
        f=run_frontier(panel,args.paths); f.to_csv(out/'guarantee_opening_reserve_frontier_run_level.csv',index=False); summary(f,['case','opening_reserve'],['floor','solvency','mean_profit','terminal']).to_csv(out/'guarantee_opening_reserve_frontier_summary.csv',index=False)
        x=run_tenor(panel,args.paths); x.to_csv(out/'tenor_and_staged_floor_run_level.csv',index=False); summary(x,['case','schedule_case'],['floor','average_floor','p99_bridge','terminal']).to_csv(out/'tenor_and_staged_floor_summary.csv',index=False)
        c=run_caps(panel,args.paths); c.to_csv(out/'reserve_target_distribution_run_level.csv',index=False); summary(c,['right','target'],['floor','annual_distribution','terminal','p99_bridge']).to_csv(out/'reserve_target_distribution_summary.csv',index=False)
        fee=run_fees(panel,args.paths); fee.to_csv(out/'access_fee_run_level.csv',index=False); summary(fee,['case'],['max_fee','fee_fraction','admitted_cash']).to_csv(out/'access_fee_summary.csv',index=False)
    if args.segment in ['extra','all']:
        h=run_hurdle(panel,args.paths); h.to_csv(out/'renewable_hurdle_sensitivity_run_level.csv',index=False); summary(h,['right','hurdle_fraction'],['floor','uplift','uplift_fraction','admitted_cash']).to_csv(out/'renewable_hurdle_sensitivity_summary.csv',index=False)
        a=run_alt(panel,d,args.paths); a.to_csv(out/'alternative_bess_schedule_run_level.csv',index=False); summary(a,['strategy','right'],['bess_only','floor','uplift','uplift_fraction']).to_csv(out/'alternative_bess_schedule_summary.csv',index=False)
    if args.segment in ['nested','all']:
        n=run_nested(panel,args.nested_reps,args.nested_train_paths,args.nested_eval_paths,seed=args.nested_seed); n.to_csv(out/'frozen_contract_nested_bootstrap_run_level.csv',index=False); summary(n,['calibration_rule','case'],['selected_floor','paired_uplift','paired_uplift_fraction','eval_solvency','eval_wilson_lower','eval_empirical_pass','eval_wilson_pass','eval_margin_pass','eval_p99_bridge']).to_csv(out/'frozen_contract_nested_bootstrap_summary.csv',index=False)
    meta={'version':'1.9.1','segment':args.segment,'paths':args.paths,'nested_reps':args.nested_reps,'nested_train_paths':args.nested_train_paths,'nested_eval_paths':args.nested_eval_paths,'nested_seed':args.nested_seed,'nested_outer_resampling':'year-month groups resampled within calendar month; independent training and evaluation scenarios from same outer bootstrap panel','reserve_yield':0.0,'settlement':'annual','cash_basis':'undiscounted historical nominal GBP; no inflation escalation','elapsed_seconds':time.time()-t}; (out/f'metadata_{args.segment}.json').write_text(json.dumps(meta,indent=2)); print(json.dumps(meta,indent=2))
if __name__=='__main__': main()
