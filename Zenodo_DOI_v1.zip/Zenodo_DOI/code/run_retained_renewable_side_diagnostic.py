#!/usr/bin/env python3
"""Retained-renewable-side diagnostic for the reference residual-cash contract.

This focused diagnostic uses the same circular month-stratified annual scenarios,
fixed 50% wind equal-mean cash exposure, 25 MW-equivalent cash scale, 70%
protected hurdle, ten-year paths, q95 reserve solver and canonical seeds as the
main contract-design analysis. It measures what remains with the renewable side
under zero access, the 50% reference access share and the minimum daily access
needed for a £30,000/MW-year BESS target.

The diagnostic does not size a renewable guarantee or introduce a project-finance
waterfall. It distinguishes cash that is senior to the sweep from a renewable-side
solvency guarantee.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))

import phase_model as pm  # noqa: E402
import run_access_frontier as af  # noqa: E402
import run_retained_reserve_analysis as rr  # noqa: E402

DEFAULT_OUT = ROOT / "results" / "retained_reserve"
Q = 0.95
H = 0.70
WIND_SHARE = 0.50
TARGET_FLOOR = 30_000.0


def lower_tail_mean(x: np.ndarray, fraction: float = 0.05) -> float:
    arr = np.asarray(x, dtype=float).ravel()
    k = max(1, int(math.ceil(fraction * arr.size)))
    return float(np.partition(arr, k - 1)[:k].mean())


def draw_gross_residual_hurdle(
    panel: pd.DataFrame,
    n: int,
    seed: int,
    *,
    chunk: int = 25_000,
) -> dict[str, np.ndarray | float]:
    """Draw aligned annual BESS, gross renewable, residual and hurdle cash.

    Wind and solar gross cash, positive residual cash and accrued hurdle cash are
    all scaled with the same technology multipliers. Those multipliers are the
    reference equal-mean residual-cash multipliers, so the pathwise identity
    retained renewable cash + transferred residual cash = gross renewable cash
    holds on the exact cash scale used by the main access frontier.
    """
    blocks = pm.build_blocks(panel)
    hurdle_w, hurdle_s = pm.historical_hurdle(panel, H)
    rng = np.random.default_rng(seed)

    bess = np.zeros(n, dtype=float)
    wind_gross = np.zeros(n, dtype=float)
    solar_gross = np.zeros(n, dtype=float)
    wind_residual = np.zeros(n, dtype=float)
    solar_residual = np.zeros(n, dtype=float)
    wind_hurdle = np.zeros(n, dtype=float)
    solar_hurdle = np.zeros(n, dtype=float)

    for month in range(1, 13):
        z = blocks[month]
        n_blocks = math.ceil(z.target_days / z.b.shape[1])
        for lo in range(0, n, chunk):
            hi = min(n, lo + chunk)
            rows = hi - lo
            choices = rng.integers(0, len(z.b), size=(rows, n_blocks))
            bdays = z.b[choices].reshape(rows, -1)[:, : z.target_days]
            wdays = z.w[choices].reshape(rows, -1)[:, : z.target_days]
            sdays = z.s[choices].reshape(rows, -1)[:, : z.target_days]
            source_days = np.repeat(z.source_days[choices], z.b.shape[1], axis=1)[:, : z.target_days]
            wh = hurdle_w[month - 1] / source_days
            sh = hurdle_s[month - 1] / source_days

            bess[lo:hi] += bdays.sum(axis=1)
            wind_gross[lo:hi] += wdays.sum(axis=1)
            solar_gross[lo:hi] += sdays.sum(axis=1)
            wind_residual[lo:hi] += np.maximum(wdays - wh, 0.0).sum(axis=1)
            solar_residual[lo:hi] += np.maximum(sdays - sh, 0.0).sum(axis=1)
            wind_hurdle[lo:hi] += wh.sum(axis=1)
            solar_hurdle[lo:hi] += sh.sum(axis=1)

    target = 0.5 * (float(wind_residual.mean()) + float(solar_residual.mean()))
    scale_w = rr.RENEWABLE_REFERENCE_MW * target / float(wind_residual.mean())
    scale_s = rr.RENEWABLE_REFERENCE_MW * target / float(solar_residual.mean())

    gross = WIND_SHARE * scale_w * wind_gross + (1.0 - WIND_SHARE) * scale_s * solar_gross
    residual = WIND_SHARE * scale_w * wind_residual + (1.0 - WIND_SHARE) * scale_s * solar_residual
    hurdle = WIND_SHARE * scale_w * wind_hurdle + (1.0 - WIND_SHARE) * scale_s * solar_hurdle

    identity_error = float(np.max(np.abs((gross - residual) - (gross - residual))))
    return {
        "bess": bess,
        "gross": gross,
        "residual": residual,
        "hurdle": hurdle,
        "wind_scale": scale_w,
        "solar_scale": scale_s,
        "identity_error": identity_error,
    }


def run(n_paths: int, out: Path) -> dict:
    start = time.time()
    out.mkdir(parents=True, exist_ok=True)
    duration_daily = rr.prepare_duration_daily(False)
    panel = rr.live_panel_for_duration(2, duration_daily)

    run_rows: list[dict] = []
    for seed in rr.SEEDS:
        drawn = draw_gross_residual_hurdle(panel, n_paths * rr.TENOR_YEARS, seed)
        bess = np.asarray(drawn["bess"]).reshape(n_paths, rr.TENOR_YEARS)
        gross = np.asarray(drawn["gross"]).reshape(n_paths, rr.TENOR_YEARS)
        residual_100 = np.asarray(drawn["residual"]).reshape(n_paths, rr.TENOR_YEARS)
        hurdle = np.asarray(drawn["hurdle"]).reshape(n_paths, rr.TENOR_YEARS)

        amin = af.alpha_min_for_target(bess, residual_100, TARGET_FLOOR, q=Q)
        if not amin["reached"]:
            raise RuntimeError(f"£30,000 target not reached for seed {seed}")

        cases = [
            ("No renewable transfer", 0.0),
            ("Reference daily access", 0.50),
            ("Minimum daily access for £30,000 target", float(amin["alpha_min"])),
        ]
        for label, alpha in cases:
            transferred = alpha * residual_100
            retained = gross - transferred
            floor_result = rr.solve_path_floor(bess, transferred, Q)
            below = retained < hurdle - 1e-8
            cash_conservation_error = float(np.max(np.abs(retained + transferred - gross)))
            run_rows.append({
                "seed": seed,
                "n_paths": n_paths,
                "structure": label,
                "access_share": alpha,
                "mean_gross_renewable_cash_gbp_per_bess_mw_year": float(gross.mean() / rr.P_BESS_MW),
                "mean_accrued_hurdle_gbp_per_bess_mw_year": float(hurdle.mean() / rr.P_BESS_MW),
                "mean_transferred_cash_gbp_per_bess_mw_year": float(transferred.mean() / rr.P_BESS_MW),
                "mean_retained_renewable_cash_gbp_per_bess_mw_year": float(retained.mean() / rr.P_BESS_MW),
                "q05_retained_renewable_cash_gbp_per_bess_mw_year": float(np.quantile(retained, 0.05) / rr.P_BESS_MW),
                "es05_retained_renewable_cash_gbp_per_bess_mw_year": float(lower_tail_mean(retained) / rr.P_BESS_MW),
                "path_years_below_accrued_hurdle_fraction": float(below.mean()),
                "paths_with_any_year_below_accrued_hurdle_fraction": float(below.any(axis=1).mean()),
                "bess_floor_gbp_per_bess_mw_year": float(floor_result["floor_gbp_per_bess_mw_year"]),
                "bess_floor_solvency_fraction": float(floor_result["solvency_fraction"]),
                "max_cash_conservation_error_gbp": cash_conservation_error,
                "wind_scale_multiplier": float(drawn["wind_scale"]),
                "solar_scale_multiplier": float(drawn["solar_scale"]),
            })

    run_df = pd.DataFrame(run_rows)
    order = [
        "No renewable transfer",
        "Reference daily access",
        "Minimum daily access for £30,000 target",
    ]
    summary = (
        run_df.groupby("structure", as_index=False)
        .agg(
            access_share=("access_share", "mean"),
            access_share_seed_min=("access_share", "min"),
            access_share_seed_max=("access_share", "max"),
            mean_gross_renewable_cash_gbp_per_bess_mw_year=("mean_gross_renewable_cash_gbp_per_bess_mw_year", "mean"),
            mean_accrued_hurdle_gbp_per_bess_mw_year=("mean_accrued_hurdle_gbp_per_bess_mw_year", "mean"),
            mean_transferred_cash_gbp_per_bess_mw_year=("mean_transferred_cash_gbp_per_bess_mw_year", "mean"),
            mean_retained_renewable_cash_gbp_per_bess_mw_year=("mean_retained_renewable_cash_gbp_per_bess_mw_year", "mean"),
            q05_retained_renewable_cash_gbp_per_bess_mw_year=("q05_retained_renewable_cash_gbp_per_bess_mw_year", "mean"),
            es05_retained_renewable_cash_gbp_per_bess_mw_year=("es05_retained_renewable_cash_gbp_per_bess_mw_year", "mean"),
            path_years_below_accrued_hurdle_fraction=("path_years_below_accrued_hurdle_fraction", "mean"),
            paths_with_any_year_below_accrued_hurdle_fraction=("paths_with_any_year_below_accrued_hurdle_fraction", "mean"),
            bess_floor_gbp_per_bess_mw_year=("bess_floor_gbp_per_bess_mw_year", "mean"),
            bess_floor_solvency_fraction=("bess_floor_solvency_fraction", "mean"),
            max_cash_conservation_error_gbp=("max_cash_conservation_error_gbp", "max"),
        )
    )
    summary["_order"] = summary["structure"].map({k: i for i, k in enumerate(order)})
    summary = summary.sort_values("_order").drop(columns="_order").reset_index(drop=True)

    run_path = out / "retained_renewable_side_diagnostic_run_level.csv"
    table_path = out / "Table_S41_retained_renewable_side_diagnostic.csv"
    metadata_path = out / "retained_renewable_side_diagnostic_metadata.json"
    run_df.to_csv(run_path, index=False)
    summary.to_csv(table_path, index=False)
    metadata = {
        "release_analysis": "retained renewable-side diagnostic",
        "n_paths_per_seed": n_paths,
        "seeds": list(rr.SEEDS),
        "tenor_years": rr.TENOR_YEARS,
        "q": Q,
        "protected_hurdle": H,
        "wind_equal_mean_cash_share": WIND_SHARE,
        "renewable_cash_scale_mw_equivalent_per_100mw_bess": rr.RENEWABLE_REFERENCE_MW,
        "target_floor_gbp_per_bess_mw_year": TARGET_FLOOR,
        "annual_distribution_definition": "all simulated path-years",
        "below_hurdle_definition": "retained annual renewable cash is below the annual sum of accrued daily hurdle amounts on the same path-year",
        "elapsed_seconds": time.time() - start,
        "outputs": [str(run_path.relative_to(ROOT)), str(table_path.relative_to(ROOT))],
    }
    metadata_path.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")

    validation_dir = ROOT / "validation"
    validation_dir.mkdir(parents=True, exist_ok=True)
    by = {row["structure"]: row for row in summary.to_dict(orient="records")}
    validation = {
        "status": "PASS" if (
            len(summary) == 3
            and max(float(r["max_cash_conservation_error_gbp"]) for r in by.values()) <= 1e-7
            and abs(float(by["Reference daily access"]["mean_transferred_cash_gbp_per_bess_mw_year"]) - 8747.280277) <= 1e-3
            and abs(float(by["Minimum daily access for £30,000 target"]["access_share"]) - 0.595232) <= 1e-5
            and abs(float(by["Minimum daily access for £30,000 target"]["bess_floor_gbp_per_bess_mw_year"]) - 30000.001918) <= 1e-3
        ) else "FAIL",
        "table_rows": len(summary),
        "max_cash_conservation_error_gbp": max(float(r["max_cash_conservation_error_gbp"]) for r in by.values()),
        "reference_transferred_cash_gbp_per_bess_mw_year": float(by["Reference daily access"]["mean_transferred_cash_gbp_per_bess_mw_year"]),
        "target_access_share": float(by["Minimum daily access for £30,000 target"]["access_share"]),
        "target_floor_gbp_per_bess_mw_year": float(by["Minimum daily access for £30,000 target"]["bess_floor_gbp_per_bess_mw_year"]),
        "target_q05_retained_gbp_per_bess_mw_year": float(by["Minimum daily access for £30,000 target"]["q05_retained_renewable_cash_gbp_per_bess_mw_year"]),
        "target_es05_retained_gbp_per_bess_mw_year": float(by["Minimum daily access for £30,000 target"]["es05_retained_renewable_cash_gbp_per_bess_mw_year"]),
        "target_path_years_below_hurdle_fraction": float(by["Minimum daily access for £30,000 target"]["path_years_below_accrued_hurdle_fraction"]),
        "target_paths_any_year_below_hurdle_fraction": float(by["Minimum daily access for £30,000 target"]["paths_with_any_year_below_accrued_hurdle_fraction"]),
    }
    validation_path = validation_dir / "retained_renewable_side_diagnostic_audit.json"
    validation_path.write_text(json.dumps(validation, indent=2) + "\n", encoding="utf-8")
    metadata["validation"] = str(validation_path.relative_to(ROOT))
    return metadata


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--paths", type=int, default=20_000)
    ap.add_argument("--output-dir", type=Path, default=DEFAULT_OUT)
    args = ap.parse_args()
    meta = run(args.paths, args.output_dir)
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
