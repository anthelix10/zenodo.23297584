#!/usr/bin/env python3
"""GB renewable and BESS reference-model utilities used by the reproducibility workflow."""
from __future__ import annotations

import argparse
import json
import math
import os
from dataclasses import dataclass, asdict
from functools import lru_cache
from pathlib import Path
from typing import Dict, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
from scipy.optimize import linprog
from scipy.sparse import lil_matrix, csr_matrix
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import HistGradientBoostingRegressor
import matplotlib.pyplot as plt


PACKAGE_ROOT = Path(__file__).resolve().parents[1]


@dataclass(frozen=True)
class Config:
    # Portable defaults used by the archive's dispatch-rebuild wrapper.
    data_dir: str = os.environ.get(
        "BESS_MODEL_DATA_DIR",
        str(PACKAGE_ROOT / "_work" / "reference_dispatch_bundle"),
    )
    output_dir: str = os.environ.get(
        "BESS_MODEL_OUTPUT_DIR",
        str(PACKAGE_ROOT / "reproduced_results" / "legacy_full_pool"),
    )
    warmup_start: str = "2019-01-01 00:00:00+00:00"
    evaluation_start: str = "2020-01-01 00:00:00+00:00"
    evaluation_end: str = "2025-12-31 23:30:00+00:00"
    dt_h: float = 0.5
    bess_power_mw: float = 100.0
    round_trip_efficiency: float = 0.93
    purchase_access_mw: float = 60.0
    sale_access_mw: float = 70.0
    throughput_cost_gbp_mwh: float = 4.0
    external_trade_fee_gbp_mwh: float = 0.25
    forecast_horizon_days: int = 2
    execute_days: int = 1
    renewable_reference_mw: float = 100.0
    renewable_fixed_obligation_fraction: float = 0.70
    renewable_cash_availability: float = 1.0
    provider_upside_share: float = 0.50
    required_margin_fraction: float = 0.05
    risk_capacity_fraction: float = 0.10
    collateral_fraction: float = 2.00
    es_alpha: float = 0.95
    n_scenarios: int = 30000
    block_days: int = 7
    random_seed: int = 20260803
    cap_fraction_of_mid_volume: float = 0.02
    named_bmu_start: str = "2023-01-01 00:00:00+00:00"

CFG = Config()


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data-dir", type=Path, default=Path(CFG.data_dir))
    p.add_argument("--output-dir", type=Path, default=Path(CFG.output_dir))
    p.add_argument("--scenarios", type=int, default=CFG.n_scenarios)
    p.add_argument("--skip-gradient-boosting", action="store_true")
    return p.parse_args()


def fill_time_series(s: pd.Series, sp: pd.Series, max_interp: int = 4) -> pd.Series:
    """Fill sparse public-data gaps using information available strictly earlier.

    Observed values are unchanged. A missing value first receives the most recent
    earlier observation from the same UTC settlement period and then, if needed,
    the most recent earlier observation from the series. No interpolation,
    backward fill, full-month statistic or full-sample statistic is used. The
    ``max_interp`` argument is retained only for backward API compatibility.
    """
    del max_interp
    out = pd.to_numeric(s, errors="coerce").copy()
    same_period_previous = out.groupby(sp, sort=False).ffill()
    out = out.fillna(same_period_previous)
    out = out.ffill()
    return out


def load_and_prepare_panel(data_dir: Path) -> pd.DataFrame:
    path = data_dir / "processed" / "renewable_bess_master_panel_all_rows.csv.gz"
    usecols = [
        "start_time", "settlement_date", "settlement_period",
        "mid_combined_price_gbp_mwh", "mid_combined_volume_mwh",
        "system_sell_price", "system_buy_price", "net_imbalance_volume",
        "neso_transmission_system_demand_mw",
        "neso_embedded_wind_generation_mw", "neso_embedded_wind_capacity_mw",
        "neso_embedded_solar_generation_mw", "neso_embedded_solar_capacity_mw",
        "neso_embedded_wind_cf", "neso_embedded_solar_cf",
        "agws_actual_wind_total_mw", "agws_actual_solar_total_mw",
        "dgws_day_ahead_wind_total_mw", "dgws_day_ahead_solar_total_mw",
        "agws_known_issue_window", "core_complete",
    ]
    raw = pd.read_csv(path, usecols=usecols, parse_dates=["start_time"])
    raw = raw.loc[raw["start_time"] <= pd.Timestamp(CFG.evaluation_end)].copy()
    raw = raw.sort_values("start_time").drop_duplicates("start_time", keep="last")
    raw = raw.set_index("start_time")
    grid = pd.date_range(CFG.warmup_start, CFG.evaluation_end, freq="30min", tz="UTC")
    df = raw.reindex(grid)
    df.index.name = "start_time"
    df["source_row_missing"] = ~df.index.isin(raw.index)
    df["sp_utc"] = df.index.hour * 2 + (df.index.minute // 30) + 1
    df["date_utc"] = df.index.floor("D")
    df["year"] = df.index.year
    df["month"] = df.index.month
    df["dayofweek"] = df.index.dayofweek

    # Realised price: MID when present, system price as the first fallback.
    price_raw = pd.to_numeric(df["mid_combined_price_gbp_mwh"], errors="coerce")
    sys_price = pd.concat([
        pd.to_numeric(df["system_sell_price"], errors="coerce"),
        pd.to_numeric(df["system_buy_price"], errors="coerce"),
    ], axis=1).mean(axis=1)
    df["price_mid_observed"] = price_raw.notna()
    df["price_gbp_mwh"] = price_raw.fillna(sys_price)
    df["price_gbp_mwh"] = fill_time_series(df["price_gbp_mwh"], df["sp_utc"])

    for c in [
        "mid_combined_volume_mwh", "neso_transmission_system_demand_mw",
        "neso_embedded_wind_cf", "neso_embedded_solar_cf",
        "neso_embedded_wind_generation_mw", "neso_embedded_wind_capacity_mw",
        "neso_embedded_solar_generation_mw", "neso_embedded_solar_capacity_mw",
        "agws_actual_wind_total_mw", "agws_actual_solar_total_mw",
        "dgws_day_ahead_wind_total_mw", "dgws_day_ahead_solar_total_mw",
        "net_imbalance_volume",
    ]:
        df[c] = fill_time_series(df[c], df["sp_utc"])

    df["wind_cf"] = pd.to_numeric(df["neso_embedded_wind_cf"], errors="coerce").clip(0, 1.05)
    df["solar_cf"] = pd.to_numeric(df["neso_embedded_solar_cf"], errors="coerce").clip(0, 1.05)
    df["agws_known_issue_window"] = df["agws_known_issue_window"].fillna(False).astype(bool)
    df["core_complete"] = df["core_complete"].fillna(False).astype(bool)

    # Preserve audit flags before filling.
    df["renewable_cf_imputed"] = raw.reindex(grid)[["neso_embedded_wind_cf", "neso_embedded_solar_cf"]].isna().any(axis=1)
    df["dgws_imputed"] = raw.reindex(grid)[["dgws_day_ahead_wind_total_mw", "dgws_day_ahead_solar_total_mw"]].isna().any(axis=1)
    return df


def same_period_rolling(series: pd.Series, shift_days: int, window_days: int, min_days: int = 7, statistic: str = "mean") -> pd.Series:
    """Same half-hour rolling statistic, shifted enough to be known 48 h ahead."""
    arr = series.to_numpy().reshape(-1, 48)
    tab = pd.DataFrame(arr, index=pd.date_range(series.index[0].floor("D"), periods=arr.shape[0], freq="D", tz="UTC"))
    shifted = tab.shift(shift_days)
    if statistic == "median":
        rolled = shifted.rolling(window_days, min_periods=min_days).median()
    elif statistic == "std":
        rolled = shifted.rolling(window_days, min_periods=min_days).std()
    else:
        rolled = shifted.rolling(window_days, min_periods=min_days).mean()
    return pd.Series(rolled.to_numpy().reshape(-1), index=series.index)


def make_price_features(df: pd.DataFrame) -> pd.DataFrame:
    idx = df.index
    sp0 = df["sp_utc"].to_numpy() - 1
    hour_angle = 2 * np.pi * sp0 / 48.0
    dow_angle = 2 * np.pi * df["dayofweek"].to_numpy() / 7.0
    doy_angle = 2 * np.pi * (idx.dayofyear.to_numpy() - 1) / 365.25
    X = pd.DataFrame(index=idx)
    X["tod_sin"] = np.sin(hour_angle); X["tod_cos"] = np.cos(hour_angle)
    X["dow_sin"] = np.sin(dow_angle); X["dow_cos"] = np.cos(dow_angle)
    X["doy_sin"] = np.sin(doy_angle); X["doy_cos"] = np.cos(doy_angle)
    p = df["price_gbp_mwh"]
    X["price_lag_96"] = p.shift(96)
    X["price_lag_336"] = p.shift(336)
    X["price_lag_672"] = p.shift(672)
    X["price_same_sp_mean_28d"] = same_period_rolling(p, shift_days=2, window_days=28, statistic="mean")
    X["price_same_sp_std_28d"] = same_period_rolling(p, shift_days=2, window_days=28, statistic="std")
    d = df["neso_transmission_system_demand_mw"]
    X["demand_lag_96"] = d.shift(96)
    X["demand_lag_336"] = d.shift(336)
    X["wind_cf_lag_96"] = df["wind_cf"].shift(96)
    X["solar_cf_lag_96"] = df["solar_cf"].shift(96)
    X["wind_fc_log"] = np.log1p(np.maximum(df["dgws_day_ahead_wind_total_mw"], 0.0))
    X["solar_fc_log"] = np.log1p(np.maximum(df["dgws_day_ahead_solar_total_mw"], 0.0))
    X["trend_years"] = (idx - idx[0]).total_seconds() / (365.25 * 86400)
    X["dgws_imputed"] = df["dgws_imputed"].astype(float)
    return X


def rolling_yearly_price_forecasts(
    df: pd.DataFrame,
    use_gradient_boosting: bool = True,
    clip_predictions: bool = True,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Generate yearly out-of-sample forecasts and a complete accuracy audit.

    Every test year uses at most the preceding 730 days, bounded by the start of
    the packaged warm-up panel. Test-feature gaps are filled only with medians
    estimated from that year's valid training sample. Ridge and optional gradient-
    boosting predictions may be clipped to the 0.1st and 99.9th percentiles of
    the training target; the audit reports the bounds and affected observations.
    """
    X = make_price_features(df)
    y = df["price_gbp_mwh"].copy()
    pred_ridge = pd.Series(index=df.index, dtype=float)
    pred_gb = pd.Series(index=df.index, dtype=float)
    rows: list[dict] = []

    def add_metrics(
        *, year: int | str, model: str, actual: np.ndarray, forecast: np.ndarray,
        train_start: pd.Timestamp | None = None, train_end: pd.Timestamp | None = None,
        training_rows: int | None = None, lo: float | None = None, hi: float | None = None,
        clipped_low: int = 0, clipped_high: int = 0,
    ) -> None:
        err = forecast - actual
        rows.append({
            "year": year,
            "model": model,
            "n": int(len(actual)),
            "mae_gbp_mwh": float(np.mean(np.abs(err))),
            "rmse_gbp_mwh": float(np.sqrt(np.mean(err**2))),
            "correlation": float(np.corrcoef(actual, forecast)[0, 1]),
            "mean_actual": float(np.mean(actual)),
            "mean_forecast": float(np.mean(forecast)),
            "training_start": "" if train_start is None else train_start.isoformat(),
            "training_end_exclusive": "" if train_end is None else train_end.isoformat(),
            "training_history_days": np.nan if train_start is None else int((train_end - train_start).days),
            "training_rows": np.nan if training_rows is None else int(training_rows),
            "clip_predictions": bool(clip_predictions) if model in {"ridge", "gradient_boosting"} else False,
            "clip_lower_gbp_mwh": np.nan if lo is None else float(lo),
            "clip_upper_gbp_mwh": np.nan if hi is None else float(hi),
            "clipped_low_count": int(clipped_low),
            "clipped_high_count": int(clipped_high),
            "clipped_total_count": int(clipped_low + clipped_high),
            "clipped_fraction": float((clipped_low + clipped_high) / len(actual)) if len(actual) else np.nan,
        })

    for year in range(2020, 2026):
        test_mask = df.index.year == year
        train_end = pd.Timestamp(f"{year}-01-01", tz="UTC")
        train_start = max(pd.Timestamp(CFG.warmup_start), train_end - pd.Timedelta(days=730))
        train_mask = (df.index >= train_start) & (df.index < train_end)
        cols = X.columns
        train = X.loc[train_mask, cols].copy()
        target = y.loc[train_mask]
        test = X.loc[test_mask, cols].copy()
        valid_train = train.notna().all(axis=1) & target.notna()
        med = train.loc[valid_train].median()
        train_f = train.loc[valid_train].fillna(med)
        test_f = test.fillna(med)
        if test_f.isna().any(axis=None):
            missing = test_f.columns[test_f.isna().any()].tolist()
            raise RuntimeError(f"Test features remain missing for {year}: {missing}")
        y_t = np.arcsinh(target.loc[valid_train].to_numpy() / 50.0)
        ridge = make_pipeline(StandardScaler(), Ridge(alpha=25.0))
        ridge.fit(train_f, y_t)
        pr_raw = 50.0 * np.sinh(ridge.predict(test_f))
        lo, hi = target.loc[valid_train].quantile([0.001, 0.999])
        lo_f, hi_f = float(lo), float(hi)
        ridge_low = int((pr_raw < lo_f).sum())
        ridge_high = int((pr_raw > hi_f).sum())
        pr = np.clip(pr_raw, lo_f, hi_f) if clip_predictions else pr_raw
        pred_ridge.loc[test_mask] = pr
        actual = y.loc[test_mask].to_numpy()
        add_metrics(
            year=year, model="ridge", actual=actual, forecast=pr,
            train_start=train_start, train_end=train_end,
            training_rows=int(valid_train.sum()), lo=lo_f, hi=hi_f,
            clipped_low=ridge_low, clipped_high=ridge_high,
        )
        if use_gradient_boosting:
            gb = HistGradientBoostingRegressor(
                learning_rate=0.05, max_iter=180, max_leaf_nodes=31,
                min_samples_leaf=60, l2_regularization=10.0, random_state=year,
            )
            gb.fit(train_f, y_t)
            pg_raw = 50.0 * np.sinh(gb.predict(test_f))
            gb_low = int((pg_raw < lo_f).sum())
            gb_high = int((pg_raw > hi_f).sum())
            pg = np.clip(pg_raw, lo_f, hi_f) if clip_predictions else pg_raw
            pred_gb.loc[test_mask] = pg
            add_metrics(
                year=year, model="gradient_boosting", actual=actual, forecast=pg,
                train_start=train_start, train_end=train_end,
                training_rows=int(valid_train.sum()), lo=lo_f, hi=hi_f,
                clipped_low=gb_low, clipped_high=gb_high,
            )

    naive = df["price_gbp_mwh"].shift(96)
    seasonal = same_period_rolling(
        df["price_gbp_mwh"], shift_days=2, window_days=28, statistic="median"
    )
    pred = pd.DataFrame({"ridge": pred_ridge, "naive_lag_2d": naive, "seasonal_28d": seasonal})
    if use_gradient_boosting:
        pred["gradient_boosting"] = pred_gb
    eval_mask = (df.index >= pd.Timestamp(CFG.evaluation_start)) & (df.index <= pd.Timestamp(CFG.evaluation_end))
    pred.loc[eval_mask] = pred.loc[eval_mask].apply(
        lambda col: col.fillna(pred.loc[eval_mask, "ridge"])
    )
    aa_all = y.loc[eval_mask].to_numpy()
    for name in ["naive_lag_2d", "seasonal_28d"]:
        pp_all = pred.loc[eval_mask, name].to_numpy()
        for year in range(2020, 2026):
            mask_year = df.loc[eval_mask].index.year == year
            add_metrics(
                year=year, model=name,
                actual=aa_all[mask_year], forecast=pp_all[mask_year],
            )

    for name in pred.columns:
        pp_all = pred.loc[eval_mask, name].to_numpy()
        model_rows = [r for r in rows if r["model"] == name and isinstance(r["year"], int)]
        add_metrics(
            year="2020-2025 pooled", model=name,
            actual=aa_all, forecast=pp_all,
            clipped_low=sum(int(r["clipped_low_count"]) for r in model_rows),
            clipped_high=sum(int(r["clipped_high_count"]) for r in model_rows),
        )
    return pred, pd.DataFrame(rows)


@lru_cache(maxsize=None)
def battery_lp_matrices(T: int, energy_mwh: float, purchase_mw: float, sale_mw: float) -> tuple:
    dt = CFG.dt_h
    eta = math.sqrt(CFG.round_trip_efficiency)
    P = CFG.bess_power_mw
    n = 3 * T
    Aeq = lil_matrix((T + 1, n)); beq = np.zeros(T + 1)
    for t in range(T):
        Aeq[t, t] = -eta * dt
        Aeq[t, T + t] = dt / eta
        Aeq[t, 2*T + t] = 1.0
        if t > 0:
            Aeq[t, 2*T + t - 1] = -1.0
    Aeq[T, 3*T - 1] = 1.0
    Aub = lil_matrix((T, n)); bub = np.full(T, P)
    for t in range(T):
        Aub[t, t] = 1.0; Aub[t, T+t] = 1.0
    bounds = [(0.0, purchase_mw)] * T + [(0.0, sale_mw)] * T + [(0.0, energy_mwh)] * T
    return csr_matrix(Aeq), beq, csr_matrix(Aub), bub, bounds


def solve_battery_horizon(price_forecast: np.ndarray, initial_soc: float, energy_mwh: float,
                          purchase_mw: float = CFG.purchase_access_mw, sale_mw: float = CFG.sale_access_mw) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    p = np.asarray(price_forecast, dtype=float)
    T = len(p); dt = CFG.dt_h
    Aeq, beq0, Aub, bub, bounds = battery_lp_matrices(T, float(energy_mwh), float(purchase_mw), float(sale_mw))
    beq = beq0.copy(); beq[0] = initial_soc; beq[T] = initial_soc
    obj = np.r_[
        (p + CFG.throughput_cost_gbp_mwh + CFG.external_trade_fee_gbp_mwh) * dt,
        (-p + CFG.throughput_cost_gbp_mwh + CFG.external_trade_fee_gbp_mwh) * dt,
        np.zeros(T),
    ]
    res = linprog(obj, A_ub=Aub, b_ub=bub, A_eq=Aeq, b_eq=beq, bounds=bounds, method="highs")
    if not res.success:
        raise RuntimeError(res.message)
    x = res.x
    return x[:T], x[T:2*T], x[2*T:]


def rolling_dispatch(df_eval: pd.DataFrame, forecast: pd.Series, duration_h: int,
                     purchase_mw: float = CFG.purchase_access_mw, sale_mw: float = CFG.sale_access_mw) -> pd.DataFrame:
    idx = df_eval.index
    n = len(df_eval); energy = CFG.bess_power_mw * duration_h
    h = CFG.forecast_horizon_days * 48; execute = CFG.execute_days * 48
    charge = np.zeros(n); discharge = np.zeros(n); soc_out = np.zeros(n)
    p_fc = forecast.reindex(idx).to_numpy(dtype=float)
    p_actual = df_eval["price_gbp_mwh"].to_numpy(dtype=float)
    soc0 = 0.5 * energy
    for start in range(0, n, execute):
        stop = min(n, start + h)
        c, d, s = solve_battery_horizon(p_fc[start:stop], soc0, energy, purchase_mw, sale_mw)
        k = min(execute, stop-start)
        charge[start:start+k] = c[:k]
        discharge[start:start+k] = d[:k]
        soc_out[start:start+k] = s[:k]
        soc0 = float(np.clip(s[k-1], 0.0, energy))
    dt = CFG.dt_h
    cash = (p_actual*(discharge-charge) - (CFG.throughput_cost_gbp_mwh+CFG.external_trade_fee_gbp_mwh)*(charge+discharge))*dt
    gross = p_actual*(discharge-charge)*dt
    out = pd.DataFrame(index=idx)
    out["charge_mw"] = charge; out["discharge_mw"] = discharge; out["soc_mwh"] = soc_out
    out["bess_cash_gbp"] = cash; out["bess_gross_cash_gbp"] = gross
    out["throughput_mwh"] = (charge+discharge)*dt
    out["simultaneous_mwh"] = np.minimum(charge,discharge)*dt
    out["net_external_mw"] = discharge-charge
    out["price_forecast_gbp_mwh"] = p_fc; out["price_actual_gbp_mwh"] = p_actual
    out["date"] = idx.floor("D"); out["year"] = idx.year; out["month"] = idx.month
    return out


def renewable_output_and_cash(df_eval: pd.DataFrame, wind_weight: float, equal_cash: bool = True,
                              reference_mw: float = CFG.renewable_reference_mw) -> tuple[pd.Series, pd.Series, dict]:
    p = df_eval["price_gbp_mwh"].to_numpy(dtype=float)
    w = df_eval["wind_cf"].to_numpy(dtype=float)
    s = df_eval["solar_cf"].to_numpy(dtype=float)
    positive_net_price = np.maximum(p - CFG.external_trade_fee_gbp_mwh, 0.0)
    wind_cash_per_mw = float(np.sum(positive_net_price*w*CFG.dt_h))
    solar_cash_per_mw = float(np.sum(positive_net_price*s*CFG.dt_h))
    if equal_cash:
        common = 0.5*(wind_cash_per_mw+solar_cash_per_mw)
        scale_w = common/max(wind_cash_per_mw,1e-9)
        scale_s = common/max(solar_cash_per_mw,1e-9)
    else:
        scale_w = scale_s = 1.0
    output_mw = reference_mw*(wind_weight*scale_w*w + (1-wind_weight)*scale_s*s)
    # Merchant renewable can curtail rather than sell at a negative net price.
    sold_mw = np.where(p > CFG.external_trade_fee_gbp_mwh, output_mw, 0.0)
    cash = positive_net_price * output_mw * CFG.dt_h
    return pd.Series(sold_mw,index=df_eval.index), pd.Series(cash,index=df_eval.index), {
        "wind_cash_per_mw_sample": wind_cash_per_mw,
        "solar_cash_per_mw_sample": solar_cash_per_mw,
        "wind_scale": scale_w, "solar_scale": scale_s,
    }


def daily_sum(series: pd.Series, name: str) -> pd.DataFrame:
    d = series.groupby(series.index.floor("D")).sum().rename(name).to_frame()
    d.index.name = "date"; return d.reset_index()


def build_bootstrap_plan(dates: pd.DatetimeIndex, n_scenarios: int, block_days: int, seed: int,
                         allowed_years: Sequence[int] | None = None) -> dict[int,np.ndarray]:
    rng = np.random.default_rng(seed)
    target_days = {1:31,2:28,3:31,4:30,5:31,6:30,7:31,8:31,9:30,10:31,11:30,12:31}
    plan = {}
    years = sorted(set(dates.year)) if allowed_years is None else sorted(set(allowed_years))
    for month in range(1,13):
        candidates=[]
        for year in years:
            idx=np.where((dates.year==year)&(dates.month==month))[0]
            if len(idx)<block_days: continue
            for st in range(0,len(idx)-block_days+1):
                block=idx[st:st+block_days]
                dd=dates[block]
                if all((dd[j]-dd[j-1]).days==1 for j in range(1,len(dd))):
                    candidates.append(block)
        if not candidates: raise RuntimeError(f"No blocks for month {month}")
        ca=np.stack(candidates)
        nb=math.ceil(target_days[month]/block_days)
        choices=rng.integers(0,len(ca),size=(n_scenarios,nb))
        plan[month]=ca[choices].reshape(n_scenarios,nb*block_days)[:,:target_days[month]]
    return plan


def scenario_cash(bess_daily: np.ndarray, ren_daily: np.ndarray, dates: pd.DatetimeIndex,
                  plan_b: Mapping[int,np.ndarray], plan_r: Mapping[int,np.ndarray] | None = None,
                  obligation_fraction: float = CFG.renewable_fixed_obligation_fraction) -> dict[str,np.ndarray]:
    if plan_r is None: plan_r=plan_b
    hist=pd.DataFrame({"date":dates,"cash":ren_daily})
    hist["year"]=hist.date.dt.year; hist["month"]=hist.date.dt.month
    monthly=hist.groupby(["year","month"])["cash"].sum().reset_index()
    obligation=monthly.groupby("month")["cash"].mean()*obligation_fraction
    n=next(iter(plan_b.values())).shape[0]
    B=np.zeros((n,12)); R=np.zeros((n,12)); Q=np.zeros((n,12))
    for m in range(1,13):
        B[:,m-1]=bess_daily[plan_b[m]].sum(axis=1)
        R[:,m-1]=ren_daily[plan_r[m]].sum(axis=1)
        Q[:,m-1]=np.maximum(R[:,m-1]-float(obligation.loc[m]),0.0)
    return {"bess_month":B,"renewable_gross_month":R,"renewable_surplus_month":Q,
            "bess_annual":B.sum(1),"renewable_gross_annual":R.sum(1),"renewable_surplus_annual":Q.sum(1),
            "obligation_month":obligation.to_numpy()}


def expected_shortfall(loss: np.ndarray, alpha: float = CFG.es_alpha) -> float:
    x=np.asarray(loss,float); n=max(1,int(math.ceil((1-alpha)*len(x))))
    return float(np.partition(x,len(x)-n)[-n:].mean())


def floor_profit(G: float, B: np.ndarray, Q: np.ndarray, omega: float=CFG.renewable_cash_availability,
                 theta: float=CFG.provider_upside_share) -> np.ndarray:
    return omega*Q + theta*np.maximum(B-G,0.0) - np.maximum(G-B,0.0)


def supportable_floor(B: np.ndarray, Q: np.ndarray, required_margin: float, risk_capacity: float,
                     collateral: float, omega: float=CFG.renewable_cash_availability,
                     theta: float=CFG.provider_upside_share) -> dict:
    B=np.asarray(B,float); Q=np.asarray(Q,float)
    def diag(G):
        prof=floor_profit(G,B,Q,omega,theta)
        mean=float(np.mean(prof)); es=expected_shortfall(np.maximum(-prof,0.0))
        coll=float(np.quantile(np.maximum(G-B,0.0),0.99))
        return mean>=required_margin-1e-7 and es<=risk_capacity+1e-7 and coll<=collateral+1e-7,mean,es,coll
    lo=0.0; hi=max(1.0,1.5*float(np.mean(B)+omega*np.mean(Q)))
    while diag(hi)[0]: hi*=1.5
    for _ in range(60):
        mid=.5*(lo+hi)
        if diag(mid)[0]: lo=mid
        else: hi=mid
    ok,mean,es,coll=diag(lo)
    slacks={"expected_margin":mean-required_margin,"risk_capacity":risk_capacity-es,"collateral":collateral-coll}
    scales={"expected_margin":max(abs(required_margin),1),"risk_capacity":max(abs(risk_capacity),1),"collateral":max(abs(collateral),1)}
    norm={k:slacks[k]/scales[k] for k in slacks}
    binding=min(norm,key=lambda k:abs(norm[k]))
    return {"guarantee_gbp":float(lo),"floor_gbp_mw_year":float(lo/CFG.bess_power_mw),
            "mean_provider_profit_gbp":mean,"es95_loss_gbp":es,"collateral_p99_gbp":coll,
            "binding_constraint":binding,**{f"{k}_slack_gbp":v for k,v in slacks.items()}}


def make_constant_scenario(base: dict) -> dict:
    out={k:(v.copy() if isinstance(v,np.ndarray) else v) for k,v in base.items()}
    qmean=base["renewable_surplus_month"].mean(axis=0)
    out["renewable_surplus_month"]=np.tile(qmean,(len(base["bess_annual"]),1))
    out["renewable_surplus_annual"]=out["renewable_surplus_month"].sum(1)
    return out


def netting_metrics(df_eval: pd.DataFrame, dispatch: pd.DataFrame, renewable_sold_mw: pd.Series) -> dict:
    b=dispatch["net_external_mw"].to_numpy(); r=renewable_sold_mw.to_numpy(); dt=CFG.dt_h
    sep=(np.abs(b)+np.abs(r))*dt; pool=np.abs(b+r)*dt
    reduction=sep-pool
    volume=df_eval["mid_combined_volume_mwh"].to_numpy()
    ctot=np.minimum(2*CFG.bess_power_mw,CFG.cap_fraction_of_mid_volume*volume/dt)
    # Best fixed split of a conserved total allowance.
    rows=[]
    for a in np.linspace(0,1,101):
        cb=a*ctot; cr=(1-a)*ctot
        exceed=(np.maximum(np.abs(b)-cb,0)+np.maximum(np.abs(r)-cr,0))*dt
        rows.append((a,float(exceed.sum())))
    best_a,best_sep=min(rows,key=lambda x:x[1])
    pooled_exceed=float((np.maximum(np.abs(b+r)-ctot,0)*dt).sum())
    repeated=float(((np.maximum(np.abs(b)-ctot,0)+np.maximum(np.abs(r)-ctot,0))*dt).sum())
    fee_saving=reduction*CFG.external_trade_fee_gbp_mwh
    return {"separate_gross_mwh":float(sep.sum()),"pooled_gross_mwh":float(pool.sum()),
            "gross_reduction_mwh":float(reduction.sum()),"gross_reduction_fraction":float(reduction.sum()/sep.sum()),
            "periods_with_netting_fraction":float(np.mean(reduction>1e-9)),"fee_saving_gbp":float(fee_saving.sum()),
            "best_fixed_bess_access_share":float(best_a),"best_fixed_conserved_exceedance_mwh":float(best_sep),
            "pooled_conserved_exceedance_mwh":pooled_exceed,
            "pooled_exceedance_reduction_fraction":float((best_sep-pooled_exceed)/best_sep) if best_sep>0 else 0.0,
            "repeated_allowance_exceedance_mwh":repeated}


def named_bmu_profiles(data_dir: Path, eval_index: pd.DatetimeIndex) -> dict[str,pd.Series]:
    wide=pd.read_csv(data_dir/"processed"/"elexon_b1610_selected_units_wide.csv.gz",parse_dates=["start_time"]).set_index("start_time")
    # Groups chosen for geographic rather than within-farm diversification.
    groups={
        "Burbo_offshore":["b1610_mwh_e_burbo"],
        "Harburnhead_onshore":["b1610_mwh_e_hbhdw-1"],
        "Hornsea_offshore":["b1610_mwh_t_howbo-1","b1610_mwh_t_howbo-2","b1610_mwh_t_howbo-3"],
        "South_Kyle_onshore":["b1610_mwh_t_sokyw-1"],
        "Seagreen_offshore":["b1610_mwh_t_sgrwo-1","b1610_mwh_t_sgrwo-6"],
    }
    out={}
    for name,cols in groups.items():
        s=wide[cols].clip(lower=0).sum(axis=1,min_count=1).reindex(eval_index)
        # Shape-normalise by year-specific high percentile to avoid treating current BMU
        # reference capacity as valid for every historical year.
        cf=pd.Series(index=eval_index,dtype=float)
        for y in sorted(set(eval_index.year)):
            yy=s.loc[s.index.year==y]
            cap=yy.quantile(.995)
            if pd.isna(cap) or cap<=0: continue
            cf.loc[yy.index]=(yy/cap).clip(0,1)
        if cf.notna().mean()>=0.95:
            cf=cf.interpolate(limit=4).groupby([cf.index.month,cf.index.hour,cf.index.minute]).transform(lambda x:x.fillna(x.median())).ffill().bfill()
            out[name]=cf
    return out


def run_named_bmu_robustness(data_dir: Path, df_eval: pd.DataFrame, dispatch_daily: pd.DataFrame,
                             required_margin: float, risk_capacity: float, collateral: float,
                             n_scenarios: int, output_dir: Path) -> pd.DataFrame:
    idx=df_eval.index[df_eval.index>=pd.Timestamp(CFG.named_bmu_start)]
    bmu=named_bmu_profiles(data_dir,idx)
    if len(bmu)<2: return pd.DataFrame()
    price=df_eval.loc[idx,"price_gbp_mwh"]
    daily_b=dispatch_daily.set_index("date").loc[pd.date_range(idx[0].floor('D'),idx[-1].floor('D'),freq='D',tz='UTC'),"bess_cash_gbp"].to_numpy()
    dates=pd.date_range(idx[0].floor('D'),idx[-1].floor('D'),freq='D',tz='UTC')
    plan=build_bootstrap_plan(dates,n_scenarios,CFG.block_days,CFG.random_seed+81)
    plan_sh=build_bootstrap_plan(dates,n_scenarios,CFG.block_days,CFG.random_seed+82)
    cash_series={}
    for name,cf in bmu.items():
        cash=np.maximum(price.to_numpy()-CFG.external_trade_fee_gbp_mwh,0)*cf.to_numpy()*CFG.renewable_reference_mw*CFG.dt_h
        # Equalise expected gross cash across site profiles.
        cash_series[name]=pd.Series(cash,index=idx)
    means={k:v.sum() for k,v in cash_series.items()}; common=np.mean(list(means.values()))
    cash_series={k:v*(common/max(means[k],1e-9)) for k,v in cash_series.items()}
    cash_series["Geographic_basket"]=sum(cash_series.values())/len(cash_series)
    rows=[]
    for name,s in cash_series.items():
        rd=s.groupby(s.index.floor('D')).sum().reindex(dates).to_numpy()
        sc=scenario_cash(daily_b,rd,dates,plan)
        sh=scenario_cash(daily_b,rd,dates,plan,plan_sh)
        f=supportable_floor(sc['bess_annual'],sc['renewable_surplus_annual'],required_margin,risk_capacity,collateral)
        fs=supportable_floor(sh['bess_annual'],sh['renewable_surplus_annual'],required_margin,risk_capacity,collateral)
        rows.append({"profile":name,"floor_gbp_mw_year":f['floor_gbp_mw_year'],"dependence_uplift_gbp_mw_year":f['floor_gbp_mw_year']-fs['floor_gbp_mw_year'],
                     "mean_renewable_surplus_gbp":float(sc['renewable_surplus_annual'].mean()),
                     "tail_support_ratio":float(sc['renewable_surplus_annual'][sc['bess_annual']<=np.quantile(sc['bess_annual'],.05)].mean()/max(sc['renewable_surplus_annual'].mean(),1e-9))})
    return pd.DataFrame(rows).sort_values('floor_gbp_mw_year',ascending=False)


def main():
    args=parse_args(); out=Path(args.output_dir); out.mkdir(parents=True,exist_ok=True)
    cfg={**asdict(CFG),"data_dir":str(args.data_dir),"output_dir":str(out),"n_scenarios":args.scenarios}
    with open(out/"model_config.json","w") as f: json.dump(cfg,f,indent=2)
    print("Loading and preparing panel...",flush=True)
    df=load_and_prepare_panel(args.data_dir)
    eval_mask=(df.index>=pd.Timestamp(CFG.evaluation_start))&(df.index<=pd.Timestamp(CFG.evaluation_end))
    df_eval=df.loc[eval_mask].copy()
    print("Forecasting prices...",flush=True)
    forecasts,forecast_audit=rolling_yearly_price_forecasts(df,use_gradient_boosting=not args.skip_gradient_boosting)
    forecast_audit.to_csv(out/"price_forecast_audit.csv",index=False)
    forecasts.loc[eval_mask].to_csv(out/"price_forecasts_evaluation.csv.gz",compression="gzip")

    dispatches={}; dispatch_summary=[]
    strategies=["ridge"]
    for duration in [2,4]:
        for strat in strategies:
            print(f"Dispatch {duration}h {strat}...",flush=True)
            disp=rolling_dispatch(df_eval,forecasts.loc[eval_mask,strat],duration)
            dispatches[(duration,strat)]=disp
            years=(disp.index[-1]-disp.index[0]).total_seconds()/(365.25*86400)
            dispatch_summary.append({"duration_h":duration,"forecast_model":strat,
                "annual_bess_cash_gbp":float(disp.bess_cash_gbp.sum()/years),
                "annual_gross_bess_cash_gbp":float(disp.bess_gross_cash_gbp.sum()/years),
                "annual_throughput_mwh":float(disp.throughput_mwh.sum()/years),
                "simultaneous_fraction":float(disp.simultaneous_mwh.sum()/max(disp.throughput_mwh.sum(),1e-9)),
                "forecast_mae_gbp_mwh":float(np.mean(np.abs(disp.price_forecast_gbp_mwh-disp.price_actual_gbp_mwh)))})
    pd.DataFrame(dispatch_summary).to_csv(out/"dispatch_summary.csv",index=False)
    print("Dispatch complete; building scenarios...",flush=True)

    # Reference is rolling ridge, 2 h BESS.
    ref=dispatches[(2,"ridge")]
    daily_ref=ref.groupby("date").agg(bess_cash_gbp=("bess_cash_gbp","sum"),throughput_mwh=("throughput_mwh","sum")).reset_index()
    dates=pd.DatetimeIndex(daily_ref.date)
    b_daily=daily_ref.bess_cash_gbp.to_numpy()
    plan=build_bootstrap_plan(dates,args.scenarios,CFG.block_days,CFG.random_seed)
    plan_sh=build_bootstrap_plan(dates,args.scenarios,CFG.block_days,CFG.random_seed+1)
    stand=scenario_cash(b_daily,np.zeros_like(b_daily),dates,plan)
    stand_mean=float(stand['bess_annual'].mean())
    required=CFG.required_margin_fraction*stand_mean
    risk=CFG.risk_capacity_fraction*stand_mean
    collateral=CFG.collateral_fraction*stand_mean
    stand_floor=supportable_floor(stand['bess_annual'],np.zeros_like(stand['bess_annual']),required,risk,collateral)

    # Portfolio grid under equal expected gross renewable cash.
    rows=[]; scenarios_by_weight={}; renewables_by_weight={}
    for ww in np.round(np.linspace(0,1,11),2):
        print(f"Equal-cash portfolio weight {ww:.1f}...",flush=True)
        sold,cash,scale=renewable_output_and_cash(df_eval,float(ww),equal_cash=True)
        rd=cash.groupby(cash.index.floor('D')).sum().reindex(dates).to_numpy()
        sc=scenario_cash(b_daily,rd,dates,plan)
        sh=scenario_cash(b_daily,rd,dates,plan,plan_sh)
        const=make_constant_scenario(sc)
        f=supportable_floor(sc['bess_annual'],sc['renewable_surplus_annual'],required,risk,collateral)
        fs=supportable_floor(sh['bess_annual'],sh['renewable_surplus_annual'],required,risk,collateral)
        fc=supportable_floor(const['bess_annual'],const['renewable_surplus_annual'],required,risk,collateral)
        q=sc['renewable_surplus_annual']; B=sc['bess_annual']; tail=B<=np.quantile(B,.05)
        rows.append({"wind_weight":float(ww),"solar_weight":float(1-ww),
            "floor_aligned_gbp_mw_year":f['floor_gbp_mw_year'],"floor_shuffled_gbp_mw_year":fs['floor_gbp_mw_year'],
            "floor_constant_cash_gbp_mw_year":fc['floor_gbp_mw_year'],"standalone_floor_gbp_mw_year":stand_floor['floor_gbp_mw_year'],
            "total_uplift_gbp_mw_year":f['floor_gbp_mw_year']-stand_floor['floor_gbp_mw_year'],
            "cash_backing_uplift_gbp_mw_year":fc['floor_gbp_mw_year']-stand_floor['floor_gbp_mw_year'],
            "renewable_volatility_effect_gbp_mw_year":fs['floor_gbp_mw_year']-fc['floor_gbp_mw_year'],
            "tail_dependence_effect_gbp_mw_year":f['floor_gbp_mw_year']-fs['floor_gbp_mw_year'],
            "mean_renewable_gross_gbp":float(sc['renewable_gross_annual'].mean()),"mean_renewable_surplus_gbp":float(q.mean()),
            "tail_support_ratio_q_bottom5_b":float(q[tail].mean()/max(q.mean(),1e-9)),
            "corr_bess_renewable_surplus":float(np.corrcoef(B,q)[0,1]),"binding_constraint":f['binding_constraint'],
            "floor_conversion_total_gbp_guarantee_per_gbp_mean_surplus":float((f['guarantee_gbp']-stand_floor['guarantee_gbp'])/max(q.mean(),1e-9)),
            "floor_conversion_cash_only":float((fc['guarantee_gbp']-stand_floor['guarantee_gbp'])/max(q.mean(),1e-9)),
        })
        scenarios_by_weight[float(ww)]=(sc,sh,const,f,fs,fc)
        renewables_by_weight[float(ww)]=(sold,cash,scale)
    frontier=pd.DataFrame(rows)
    frontier.to_csv(out/"equal_cash_portfolio_frontier.csv",index=False)
    best=frontier.loc[frontier.floor_aligned_gbp_mw_year.idxmax()]
    best_w=float(best.wind_weight)

    # Equal-nameplate comparison.
    rows_mw=[]
    for ww in np.round(np.linspace(0,1,11),2):
        sold,cash,_=renewable_output_and_cash(df_eval,float(ww),equal_cash=False)
        rd=cash.groupby(cash.index.floor('D')).sum().reindex(dates).to_numpy()
        sc=scenario_cash(b_daily,rd,dates,plan); sh=scenario_cash(b_daily,rd,dates,plan,plan_sh); const=make_constant_scenario(sc)
        f=supportable_floor(sc['bess_annual'],sc['renewable_surplus_annual'],required,risk,collateral)
        fs=supportable_floor(sh['bess_annual'],sh['renewable_surplus_annual'],required,risk,collateral)
        fc=supportable_floor(const['bess_annual'],const['renewable_surplus_annual'],required,risk,collateral)
        rows_mw.append({"wind_weight":float(ww),"floor_aligned_gbp_mw_year":f['floor_gbp_mw_year'],"floor_shuffled_gbp_mw_year":fs['floor_gbp_mw_year'],
                        "floor_constant_gbp_mw_year":fc['floor_gbp_mw_year'],"mean_renewable_surplus_gbp":float(sc['renewable_surplus_annual'].mean()),
                        "tail_dependence_effect_gbp_mw_year":f['floor_gbp_mw_year']-fs['floor_gbp_mw_year']})
    pd.DataFrame(rows_mw).to_csv(out/"equal_nameplate_portfolio_frontier.csv",index=False)

    # Main decomposition for best equal-cash mix.
    sc,sh,const,f,fs,fc=scenarios_by_weight[best_w]
    sold,cash,scale=renewables_by_weight[best_w]
    net=netting_metrics(df_eval,ref,sold)
    fee_daily=( (np.abs(ref.net_external_mw.to_numpy())+sold.to_numpy()-np.abs(ref.net_external_mw.to_numpy()+sold.to_numpy()))*CFG.dt_h*CFG.external_trade_fee_gbp_mwh )
    cash_net=cash+pd.Series(fee_daily,index=df_eval.index)
    rd_net=cash_net.groupby(cash_net.index.floor('D')).sum().reindex(dates).to_numpy()
    sc_net=scenario_cash(b_daily,rd_net,dates,plan)
    f_net=supportable_floor(sc_net['bess_annual'],sc_net['renewable_surplus_annual'],required,risk,collateral)
    decomp=pd.DataFrame([
        {"case":"A Standalone BESS","floor_gbp_mw_year":stand_floor['floor_gbp_mw_year'],"increment_gbp_mw_year":0.0,"mechanism":"Reference"},
        {"case":"B Deterministic renewable surplus","floor_gbp_mw_year":fc['floor_gbp_mw_year'],"increment_gbp_mw_year":fc['floor_gbp_mw_year']-stand_floor['floor_gbp_mw_year'],"mechanism":"Mean cash backing"},
        {"case":"C Shuffled renewable cash","floor_gbp_mw_year":fs['floor_gbp_mw_year'],"increment_gbp_mw_year":fs['floor_gbp_mw_year']-fc['floor_gbp_mw_year'],"mechanism":"Renewable cash volatility"},
        {"case":"D Actual aligned renewable cash","floor_gbp_mw_year":f['floor_gbp_mw_year'],"increment_gbp_mw_year":f['floor_gbp_mw_year']-fs['floor_gbp_mw_year'],"mechanism":"Contemporaneous tail dependence"},
        {"case":"E Fixed-schedule permitted netting","floor_gbp_mw_year":f_net['floor_gbp_mw_year'],"increment_gbp_mw_year":f_net['floor_gbp_mw_year']-f['floor_gbp_mw_year'],"mechanism":"Transaction-volume netting"},
    ])
    decomp.to_csv(out/"reference_floor_decomposition.csv",index=False)
    with open(out/"reference_netting_metrics.json","w") as fh: json.dump(net,fh,indent=2)

    # Risk-capacity and contract frontiers.
    contract_rows=[]
    for kfrac in [0.0,0.02,0.05,0.10,0.20,0.50,1.0]:
        for theta in [0.25,0.50,0.75,1.0]:
            for omega in [0.0,0.25,0.50,0.75,1.0]:
                ff=supportable_floor(sc['bess_annual'],sc['renewable_surplus_annual'],required,kfrac*stand_mean,collateral,omega=omega,theta=theta)
                contract_rows.append({"risk_capacity_fraction":kfrac,"upside_share":theta,"renewable_cash_availability":omega,**ff})
    pd.DataFrame(contract_rows).to_csv(out/"contract_risk_frontier.csv",index=False)

    # Duration and forecast-model robustness, evaluated at the selected renewable mix.
    robustness=[]
    rd=cash.groupby(cash.index.floor('D')).sum().reindex(dates).to_numpy()
    for (duration,strat),disp in dispatches.items():
        dd=disp.groupby('date').bess_cash_gbp.sum().reindex(dates).to_numpy()
        pp=build_bootstrap_plan(dates,min(args.scenarios,8000),CFG.block_days,CFG.random_seed+duration*100+sum(map(ord,strat)))
        pps=build_bootstrap_plan(dates,min(args.scenarios,8000),CFG.block_days,CFG.random_seed+duration*100+sum(map(ord,strat))+1)
        st=scenario_cash(dd,np.zeros_like(dd),dates,pp); ss=scenario_cash(dd,rd,dates,pp); shh=scenario_cash(dd,rd,dates,pp,pps); cc=make_constant_scenario(ss)
        meanb=float(st['bess_annual'].mean()); req=CFG.required_margin_fraction*meanb; kk=CFG.risk_capacity_fraction*meanb; col=CFG.collateral_fraction*meanb
        fst=supportable_floor(st['bess_annual'],np.zeros_like(st['bess_annual']),req,kk,col)
        fa=supportable_floor(ss['bess_annual'],ss['renewable_surplus_annual'],req,kk,col)
        fsh=supportable_floor(shh['bess_annual'],shh['renewable_surplus_annual'],req,kk,col)
        fco=supportable_floor(cc['bess_annual'],cc['renewable_surplus_annual'],req,kk,col)
        robustness.append({"duration_h":duration,"forecast_model":strat,"standalone_floor_gbp_mw_year":fst['floor_gbp_mw_year'],
                           "renewable_backed_floor_gbp_mw_year":fa['floor_gbp_mw_year'],"total_uplift_gbp_mw_year":fa['floor_gbp_mw_year']-fst['floor_gbp_mw_year'],
                           "tail_dependence_effect_gbp_mw_year":fa['floor_gbp_mw_year']-fsh['floor_gbp_mw_year'],
                           "renewable_volatility_effect_gbp_mw_year":fsh['floor_gbp_mw_year']-fco['floor_gbp_mw_year'],"binding_constraint":fa['binding_constraint']})
    pd.DataFrame(robustness).to_csv(out/"duration_forecast_robustness.csv",index=False)

    # Leave-one-year-out stability of the selected finding.
    loo=[]
    for omit in range(2020,2026):
        allowed=[y for y in range(2020,2026) if y!=omit]
        p1=build_bootstrap_plan(dates,5000,CFG.block_days,CFG.random_seed+omit,allowed)
        p2=build_bootstrap_plan(dates,5000,CFG.block_days,CFG.random_seed+omit+50,allowed)
        x=scenario_cash(b_daily,rd,dates,p1); xs=scenario_cash(b_daily,rd,dates,p1,p2); xc=make_constant_scenario(x)
        ff=supportable_floor(x['bess_annual'],x['renewable_surplus_annual'],required,risk,collateral)
        ffs=supportable_floor(xs['bess_annual'],xs['renewable_surplus_annual'],required,risk,collateral)
        ffc=supportable_floor(xc['bess_annual'],xc['renewable_surplus_annual'],required,risk,collateral)
        loo.append({"omitted_year":omit,"floor_aligned_gbp_mw_year":ff['floor_gbp_mw_year'],"tail_dependence_effect_gbp_mw_year":ff['floor_gbp_mw_year']-ffs['floor_gbp_mw_year'],
                    "renewable_volatility_effect_gbp_mw_year":ffs['floor_gbp_mw_year']-ffc['floor_gbp_mw_year'],"tail_support_ratio":float(x['renewable_surplus_annual'][x['bess_annual']<=np.quantile(x['bess_annual'],.05)].mean()/x['renewable_surplus_annual'].mean())})
    pd.DataFrame(loo).to_csv(out/"leave_one_year_out_stability.csv",index=False)

    # Named-BMU wind robustness on 2023-2025.
    bmu=run_named_bmu_robustness(args.data_dir,df_eval,daily_ref,required,risk,collateral,min(args.scenarios,8000),out)
    bmu.to_csv(out/"named_bmu_geographic_robustness.csv",index=False)

    # Year/regime descriptive cash results.
    year_rows=[]
    renew_daily=pd.DataFrame({"date":cash.index.floor('D'),"cash":cash.to_numpy()}).groupby('date').cash.sum()
    for y in range(2020,2026):
        m=daily_ref.date.dt.year==y
        bd=daily_ref.loc[m,'bess_cash_gbp'].sum(); qg=renew_daily.loc[renew_daily.index.year==y].sum()
        year_rows.append({"year":y,"bess_cash_gbp":float(bd),"renewable_gross_cash_gbp":float(qg),"combined_cash_gbp":float(bd+qg),
                          "mean_mid_price_gbp_mwh":float(df_eval.loc[df_eval.index.year==y,'price_gbp_mwh'].mean()),
                          "negative_price_fraction":float((df_eval.loc[df_eval.index.year==y,'price_gbp_mwh']<0).mean())})
    pd.DataFrame(year_rows).to_csv(out/"annual_cash_regimes.csv",index=False)

    # Simple saturation surface: BESS-specific cash compression versus renewable-surplus compression.
    sat=[]
    base_floor=f
    for bf in [1.0,0.8,0.6,0.4]:
        for qf in [1.0,0.8,0.6,0.4]:
            sf=supportable_floor(sc['bess_annual']*bf,sc['renewable_surplus_annual']*qf,required,risk,collateral)
            ssf=supportable_floor(stand['bess_annual']*bf,np.zeros_like(stand['bess_annual']),required,risk,collateral)
            sat.append({"bess_cash_factor":bf,"renewable_surplus_factor":qf,"renewable_backed_floor_gbp_mw_year":sf['floor_gbp_mw_year'],
                        "standalone_floor_gbp_mw_year":ssf['floor_gbp_mw_year'],"renewable_backed_retention":sf['floor_gbp_mw_year']/base_floor['floor_gbp_mw_year'],
                        "standalone_retention":ssf['floor_gbp_mw_year']/stand_floor['floor_gbp_mw_year'],
                        "retention_advantage":sf['floor_gbp_mw_year']/base_floor['floor_gbp_mw_year']-ssf['floor_gbp_mw_year']/stand_floor['floor_gbp_mw_year']})
    pd.DataFrame(sat).to_csv(out/"saturation_surface.csv",index=False)

    # Headline findings.
    headline={
        "sample_start":str(df_eval.index.min()),"sample_end":str(df_eval.index.max()),"half_hours":int(len(df_eval)),"days":int(len(dates)),
        "price_observed_fraction":float(df_eval.price_mid_observed.mean()),"source_row_missing_fraction":float(df_eval.source_row_missing.mean()),
        "reference_dispatch":"2 h BESS, rolling 48 h horizon, yearly rolling ridge price forecast, 60 MW purchase and 70 MW sale access",
        "standalone_bess_mean_annual_cash_gbp":stand_mean,"standalone_floor_gbp_mw_year":stand_floor['floor_gbp_mw_year'],
        "floor_optimal_equal_cash_wind_weight":best_w,"floor_optimal_equal_cash_solar_weight":1-best_w,
        "renewable_backed_floor_gbp_mw_year":float(best.floor_aligned_gbp_mw_year),"total_floor_uplift_gbp_mw_year":float(best.total_uplift_gbp_mw_year),
        "cash_backing_uplift_gbp_mw_year":float(best.cash_backing_uplift_gbp_mw_year),"renewable_volatility_effect_gbp_mw_year":float(best.renewable_volatility_effect_gbp_mw_year),
        "tail_dependence_effect_gbp_mw_year":float(best.tail_dependence_effect_gbp_mw_year),"tail_support_ratio":float(best.tail_support_ratio_q_bottom5_b),
        "corr_bess_renewable_surplus":float(best.corr_bess_renewable_surplus),"conversion_total":float(best.floor_conversion_total_gbp_guarantee_per_gbp_mean_surplus),
        "conversion_cash_only":float(best.floor_conversion_cash_only),"binding_constraint":str(best.binding_constraint),
        "netting_gross_volume_reduction_fraction":net['gross_reduction_fraction'],"netting_access_exceedance_reduction_fraction":net['pooled_exceedance_reduction_fraction'],
        "netting_floor_uplift_gbp_mw_year":float(f_net['floor_gbp_mw_year']-f['floor_gbp_mw_year']),
    }
    with open(out/"headline_findings.json","w") as fh: json.dump(headline,fh,indent=2)
    pd.DataFrame([headline]).to_csv(out/"headline_findings.csv",index=False)

    # Figures.
    plt.figure(figsize=(8,5)); plt.plot(frontier.wind_weight,frontier.floor_aligned_gbp_mw_year,marker='o',label='Aligned renewable cash')
    plt.plot(frontier.wind_weight,frontier.floor_shuffled_gbp_mw_year,marker='o',label='Shuffled dependence')
    plt.plot(frontier.wind_weight,frontier.floor_constant_cash_gbp_mw_year,marker='o',label='Deterministic cash')
    plt.axhline(stand_floor['floor_gbp_mw_year'],linestyle='--',label='Standalone BESS')
    plt.xlabel('Wind weight (solar weight = 1 - wind)'); plt.ylabel('Supportable floor (GBP/MW-year)')
    plt.title('Equal-mean-cash renewable portfolios support different BESS floors'); plt.legend(); plt.tight_layout(); plt.savefig(out/'figure_equal_cash_floor_frontier.png',dpi=220); plt.close()

    plt.figure(figsize=(8,5)); x=np.arange(len(decomp)); plt.bar(x,decomp.increment_gbp_mw_year)
    plt.xticks(x,['Standalone','Cash backing','Renewable volatility','Tail dependence','Netting'],rotation=20,ha='right')
    plt.ylabel('Increment to supportable floor (GBP/MW-year)'); plt.title('What actually raises the renewable-backed BESS floor?')
    plt.tight_layout(); plt.savefig(out/'figure_floor_decomposition.png',dpi=220); plt.close()

    plt.figure(figsize=(8,5)); plt.plot(frontier.wind_weight,frontier.tail_dependence_effect_gbp_mw_year,marker='o')
    plt.axhline(0,linestyle='--'); plt.xlabel('Wind weight'); plt.ylabel('Aligned minus shuffled floor (GBP/MW-year)')
    plt.title('Dependence-only contribution after controlling for renewable cash')
    plt.tight_layout(); plt.savefig(out/'figure_dependence_only_effect.png',dpi=220); plt.close()

    if not bmu.empty:
        plt.figure(figsize=(8,5)); bb=bmu.sort_values('floor_gbp_mw_year'); plt.barh(bb.profile,bb.floor_gbp_mw_year)
        plt.xlabel('Supportable floor (GBP/MW-year)'); plt.title('Named-BMU wind profile robustness, 2023-2025')
        plt.tight_layout(); plt.savefig(out/'figure_named_bmu_robustness.png',dpi=220); plt.close()

    print(json.dumps(headline,indent=2),flush=True)


if __name__=="__main__":
    main()
