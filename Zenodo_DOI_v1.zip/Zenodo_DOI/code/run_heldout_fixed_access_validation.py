#!/usr/bin/env python3
"""Held-out outer-resampling evaluation of preselected fixed access terms.

This script corrects the outer-level data-reuse limitation in the earlier fixed-
term diagnostic. Access percentages are selected from the archived selection
set (outer seed 20260815) and then evaluated unchanged on a completely new
set of outer historical-resampling panels (default seed 20260822).

The entire monetary contract is frozen for evaluation: the twelve full-sample
70% hurdle amounts, the fixed 50/50 equal-mean wind/solar mapping, provider
upside share, expected-margin rule, annual settlement and target floor. No
contract term is re-estimated inside the held-out panels.
"""
from __future__ import annotations

import argparse
import json
import math
import multiprocessing as mp
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))

import phase_model as pm  # noqa: E402
import run_methodological_extensions as rme  # noqa: E402
import run_minimum_access_validation as mav  # noqa: E402
import run_retained_reserve_analysis as rr  # noqa: E402

Q = 0.95
HURDLE = 0.70
TARGET = 30_000.0
WIND_SHARE = 0.50
SELECTION_OUTER_SEED = 20260815
DEFAULT_EVALUATION_SEED = 20260822
DEFAULT_OUT = ROOT / "results" / "retained_reserve"
DEFAULT_VALIDATION = ROOT / "validation"
TOL = 1e-8

_PANEL: pd.DataFrame | None = None
_TERMS: dict[str, dict[str, float]] | None = None
_FROZEN: mav.FrozenResidualConfig | None = None
_N_EVAL = 5_000


@dataclass(frozen=True)
class SelectionMetadata:
    daily_point: float
    monthly_point: float
    daily_upper: float
    monthly_conditional_upper: float
    monthly_training_feasibility: float


def wilson_interval(successes: int, n: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if n <= 0:
        return float("nan"), float("nan")
    phat = successes / n
    denom = 1.0 + z * z / n
    centre = (phat + z * z / (2.0 * n)) / denom
    half = z * math.sqrt(phat * (1.0 - phat) / n + z * z / (4.0 * n * n)) / denom
    return centre - half, centre + half


def load_selection(out: Path) -> tuple[dict[str, dict[str, float]], SelectionMetadata]:
    targets = pd.read_csv(out / "Table_S33_minimum_access_targets.csv")
    historical = pd.read_csv(out / "Table_S36_minimum_access_historical_validation.csv")
    point = targets[targets["target_floor_gbp_per_bess_mw_year"].eq(TARGET)].set_index("settlement_rule")
    upper = historical[historical["calibration_rule"].eq("wilson_lower_bound")].set_index("settlement_rule")
    metadata = SelectionMetadata(
        daily_point=float(point.loc["daily_non_carrying", "alpha_min_mean"]),
        monthly_point=float(point.loc["monthly_netted", "alpha_min_mean"]),
        daily_upper=float(upper.loc["daily_non_carrying", "alpha_min_p975"]),
        monthly_conditional_upper=float(upper.loc["monthly_netted", "alpha_min_p975"]),
        monthly_training_feasibility=float(upper.loc["monthly_netted", "training_target_reachability"]),
    )
    terms = {
        "full_sample_point": {
            "daily_non_carrying": metadata.daily_point,
            "monthly_netted": metadata.monthly_point,
        },
        "higher_resampling_fixed": {
            "daily_non_carrying": metadata.daily_upper,
            "monthly_netted": metadata.monthly_conditional_upper,
        },
    }
    return terms, metadata


def build_master_frozen_config(panel: pd.DataFrame, n_paths: int = 20_000) -> mav.FrozenResidualConfig:
    """Freeze full-sample hurdles and the canonical three-seed scale mapping."""
    hurdle_w, hurdle_s = pm.historical_hurdle(panel, HURDLE)
    configs: list[mav.FrozenResidualConfig] = []
    for seed in rr.SEEDS:
        _, _, cfg = mav.draw_residual_scenarios(panel, n_paths * rr.TENOR_YEARS, seed)
        configs.append(cfg)
    return mav.FrozenResidualConfig(
        hurdle_w=np.asarray(hurdle_w, dtype=float),
        hurdle_s=np.asarray(hurdle_s, dtype=float),
        daily_scale_w=float(np.mean([c.daily_scale_w for c in configs])),
        daily_scale_s=float(np.mean([c.daily_scale_s for c in configs])),
        monthly_scale_w=float(np.mean([c.monthly_scale_w for c in configs])),
        monthly_scale_s=float(np.mean([c.monthly_scale_s for c in configs])),
    )


def target_metrics(bess: np.ndarray, residual: np.ndarray, alpha: float) -> dict[str, float | bool]:
    guarantee = TARGET * rr.P_BESS_MW
    cash = (
        alpha * residual
        + rr.PROVIDER_UPSIDE_SHARE * np.maximum(bess - guarantee, 0.0)
        - np.maximum(guarantee - bess, 0.0)
    )
    cumulative = np.cumsum(cash, axis=1)
    solvent = cumulative.min(axis=1) >= -TOL
    successes = int(solvent.sum())
    n = len(solvent)
    solvency = successes / n
    wilson = rme.wilson_lower(successes, n)
    mean_cash = float(cash.mean())
    required_margin = rr.REQUIRED_MARGIN_FRACTION * float(bess.mean())
    margin_pass = bool(mean_cash >= required_margin - 1e-7)
    return {
        "solvency": solvency,
        "wilson_lower": wilson,
        "margin_pass": margin_pass,
        "empirical_target_attained": bool(solvency >= Q - 1e-12 and margin_pass),
        "wilson_target_attained": bool(wilson >= Q - 1e-12 and margin_pass),
        "mean_provider_cash_gbp_per_bess_mw_year": mean_cash / rr.P_BESS_MW,
    }


def solve_floor_fast(bess: np.ndarray, renewable: np.ndarray, iterations: int = 12) -> float:
    mean_bess = float(bess.mean())
    required_margin = rr.REQUIRED_MARGIN_FRACTION * mean_bess

    def feasible(g: float) -> bool:
        cash = (
            renewable
            + rr.PROVIDER_UPSIDE_SHARE * np.maximum(bess - g, 0.0)
            - np.maximum(g - bess, 0.0)
        )
        solvency = float((np.cumsum(cash, axis=1).min(axis=1) >= -TOL).mean())
        return solvency >= Q - 1e-12 and float(cash.mean()) >= required_margin - 1e-7

    lo = 0.0
    hi = max(1.0, 1.5 * float(mean_bess + max(float(renewable.mean()), 0.0)))
    while feasible(hi):
        hi *= 1.5
    for _ in range(iterations):
        mid = 0.5 * (lo + hi)
        if feasible(mid):
            lo = mid
        else:
            hi = mid
    return lo / rr.P_BESS_MW


def _init_worker(panel: pd.DataFrame, terms: dict[str, dict[str, float]], frozen: mav.FrozenResidualConfig, n_eval: int) -> None:
    global _PANEL, _TERMS, _FROZEN, _N_EVAL
    _PANEL = panel
    _TERMS = terms
    _FROZEN = frozen
    _N_EVAL = n_eval


def _run_rep(task: tuple[int, int, int]) -> list[dict]:
    rep, bootstrap_seed, eval_seed = task
    assert _PANEL is not None and _TERMS is not None and _FROZEN is not None
    boot = rme.bootstrap_panel(_PANEL, np.random.default_rng(bootstrap_seed))
    b_eval_annual, r_eval_annual, _ = mav.draw_residual_scenarios(
        boot, _N_EVAL * rr.TENOR_YEARS, eval_seed, frozen=_FROZEN
    )
    b_eval = b_eval_annual.reshape(_N_EVAL, rr.TENOR_YEARS)
    rows: list[dict] = []
    for settlement in ("daily_non_carrying", "monthly_netted"):
        residual = r_eval_annual[settlement].reshape(_N_EVAL, rr.TENOR_YEARS)
        for term_type, values in _TERMS.items():
            alpha = float(values[settlement])
            metrics = target_metrics(b_eval, residual, alpha)
            achieved_floor = solve_floor_fast(b_eval, alpha * residual)
            rows.append({
                "replication": rep,
                "term_type": term_type,
                "settlement_rule": settlement,
                "access_share": alpha,
                "target_floor_gbp_per_bess_mw_year": TARGET,
                "protected_hurdle": HURDLE,
                "wind_equal_mean_cash_share": WIND_SHARE,
                "renewable_cash_scale_mw_equivalent_per_100mw_bess": rr.RENEWABLE_REFERENCE_MW,
                "evaluation_solvency": metrics["solvency"],
                "evaluation_wilson_lower": metrics["wilson_lower"],
                "evaluation_margin_pass": float(metrics["margin_pass"]),
                "evaluation_empirical_target_attained": float(metrics["empirical_target_attained"]),
                "evaluation_wilson_target_attained": float(metrics["wilson_target_attained"]),
                "evaluation_achieved_q95_floor_gbp_per_bess_mw_year": achieved_floor,
                "evaluation_admitted_cash_gbp_per_bess_mw_year": alpha * float(residual.mean()) / rr.P_BESS_MW,
                "evaluation_mean_provider_cash_gbp_per_bess_mw_year": metrics["mean_provider_cash_gbp_per_bess_mw_year"],
            })
    return rows


def summarize(run: pd.DataFrame, selection: SelectionMetadata) -> pd.DataFrame:
    rows: list[dict] = []
    for (term_type, settlement), g in run.groupby(["term_type", "settlement_rule"], sort=True):
        n = int(len(g))
        empirical = int(g["evaluation_empirical_target_attained"].sum())
        wilson = int(g["evaluation_wilson_target_attained"].sum())
        emp_lo, emp_hi = wilson_interval(empirical, n)
        wil_lo, wil_hi = wilson_interval(wilson, n)
        floor = g["evaluation_achieved_q95_floor_gbp_per_bess_mw_year"]
        cash = g["evaluation_admitted_cash_gbp_per_bess_mw_year"]
        solv = g["evaluation_solvency"]
        selection_interpretation = (
            "full-sample central fixed percentage"
            if term_type == "full_sample_point"
            else (
                "97.5th percentile of Wilson-calibrated training requirements"
                if settlement == "daily_non_carrying"
                else "conditional 97.5th percentile among feasible Wilson-calibrated training panels"
            )
        )
        rows.append({
            "term_type": term_type,
            "settlement_rule": settlement,
            "selection_interpretation": selection_interpretation,
            "access_share": float(g["access_share"].iloc[0]),
            "selection_training_target_feasibility": (
                1.0 if settlement == "daily_non_carrying" else selection.monthly_training_feasibility
            ) if term_type == "higher_resampling_fixed" else np.nan,
            "heldout_replications": n,
            "evaluation_empirical_success_count": empirical,
            "evaluation_empirical_target_attainment": empirical / n,
            "evaluation_empirical_attainment_wilson95_lower": emp_lo,
            "evaluation_empirical_attainment_wilson95_upper": emp_hi,
            "evaluation_wilson_success_count": wilson,
            "evaluation_wilson_target_attainment": wilson / n,
            "evaluation_wilson_attainment_wilson95_lower": wil_lo,
            "evaluation_wilson_attainment_wilson95_upper": wil_hi,
            "evaluation_achieved_floor_median_gbp_per_bess_mw_year": float(floor.median()),
            "evaluation_achieved_floor_p025_gbp_per_bess_mw_year": float(floor.quantile(0.025)),
            "evaluation_achieved_floor_p05_gbp_per_bess_mw_year": float(floor.quantile(0.05)),
            "evaluation_achieved_floor_p975_gbp_per_bess_mw_year": float(floor.quantile(0.975)),
            "evaluation_admitted_cash_median_gbp_per_bess_mw_year": float(cash.median()),
            "evaluation_admitted_cash_p025_gbp_per_bess_mw_year": float(cash.quantile(0.025)),
            "evaluation_admitted_cash_p975_gbp_per_bess_mw_year": float(cash.quantile(0.975)),
            "evaluation_solvency_median": float(solv.median()),
            "evaluation_solvency_p025": float(solv.quantile(0.025)),
            "evaluation_solvency_p975": float(solv.quantile(0.975)),
        })
    return pd.DataFrame(rows)


def run(reps: int, n_eval: int, seed: int, workers: int, out: Path, validation: Path) -> dict:
    out.mkdir(parents=True, exist_ok=True)
    validation.mkdir(parents=True, exist_ok=True)
    terms, selection = load_selection(out)
    duration_daily = rr.prepare_duration_daily(False)
    panel = rr.live_panel_for_duration(2, duration_daily)
    frozen = build_master_frozen_config(panel)

    master = np.random.default_rng(seed)
    tasks = [
        (rep, int(master.integers(0, 2**32 - 1)), int(master.integers(0, 2**32 - 1)))
        for rep in range(reps)
    ]
    start = time.time()
    rows: list[dict] = []
    ctx = mp.get_context("fork")
    with ctx.Pool(
        processes=workers,
        initializer=_init_worker,
        initargs=(panel, terms, frozen, n_eval),
        maxtasksperchild=20,
    ) as pool:
        for done, result in enumerate(pool.imap_unordered(_run_rep, tasks, chunksize=1), start=1):
            rows.extend(result)
            if done % max(1, reps // 10) == 0:
                print(f"held-out fixed-term validation {done}/{reps}", flush=True)

    run_level = pd.DataFrame(rows).sort_values(["replication", "term_type", "settlement_rule"]).reset_index(drop=True)
    summary = summarize(run_level, selection)
    run_level.to_csv(out / "heldout_fixed_access_validation_run_level.csv", index=False)
    summary.to_csv(out / "Table_S44_heldout_fixed_access_validation.csv", index=False)

    audit = {
        "status": "PASS",
        "release": "1.9.1",
        "selection_outer_seed": SELECTION_OUTER_SEED,
        "heldout_outer_seed": seed,
        "selection_and_evaluation_outer_sets_disjoint": bool(seed != SELECTION_OUTER_SEED),
        "heldout_replications": reps,
        "evaluation_paths_per_replication": n_eval,
        "target_floor_gbp_per_bess_mw_year": TARGET,
        "q": Q,
        "protected_hurdle": HURDLE,
        "wind_equal_mean_cash_share": WIND_SHARE,
        "renewable_cash_scale_mw_equivalent_per_100mw_bess": rr.RENEWABLE_REFERENCE_MW,
        "frozen_contract": {
            "hurdle_w": frozen.hurdle_w.tolist(),
            "hurdle_s": frozen.hurdle_s.tolist(),
            "daily_scale_w": frozen.daily_scale_w,
            "daily_scale_s": frozen.daily_scale_s,
            "monthly_scale_w": frozen.monthly_scale_w,
            "monthly_scale_s": frozen.monthly_scale_s,
            "provider_upside_share": rr.PROVIDER_UPSIDE_SHARE,
            "required_margin_fraction": rr.REQUIRED_MARGIN_FRACTION,
            "annual_reserve_settlement": True,
        },
        "selected_terms": terms,
        "monthly_selection_training_feasibility": selection.monthly_training_feasibility,
        "monthly_upper_term_interpretation": "conditional 97.5th percentile among feasible Wilson-calibrated selection panels; infeasible panels require more than 100% access",
        "runtime_seconds": time.time() - start,
    }
    (validation / "heldout_fixed_access_validation_audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    meta = {
        "status": "PASS",
        "release": "1.9.1",
        "heldout_replications": reps,
        "evaluation_paths": n_eval,
        "selection_outer_seed": SELECTION_OUTER_SEED,
        "heldout_outer_seed": seed,
        "workers": workers,
        "runtime_seconds": audit["runtime_seconds"],
        "outputs": [
            "heldout_fixed_access_validation_run_level.csv",
            "Table_S44_heldout_fixed_access_validation.csv",
            "validation/heldout_fixed_access_validation_audit.json",
        ],
    }
    (out / "heldout_fixed_access_validation_metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return meta


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--replications", type=int, default=300)
    ap.add_argument("--evaluation-paths", type=int, default=5_000)
    ap.add_argument("--seed", type=int, default=DEFAULT_EVALUATION_SEED)
    ap.add_argument("--workers", type=int, default=max(1, min(4, (mp.cpu_count() or 2) - 1)))
    ap.add_argument("--output-dir", type=Path, default=DEFAULT_OUT)
    ap.add_argument("--validation-dir", type=Path, default=DEFAULT_VALIDATION)
    args = ap.parse_args()
    meta = run(args.replications, args.evaluation_paths, args.seed, args.workers, args.output_dir, args.validation_dir)
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
