#!/usr/bin/env python3
"""Frozen-contract historical validation of the minimum residual-access decision.

For each outer year-month bootstrap, this script draws independent training and
assessment scenario sets from the same resampled historical panel.  The 70%
protected hurdle and equal-mean wind/solar scale are estimated on training data
and frozen.  It then estimates the minimum daily or monthly residual share needed
to support a £30,000/MW-year BESS floor under either empirical-q or Wilson-lower-
bound calibration, applies that share unchanged to assessment scenarios and
reports realised cash sufficiency.

The exercise validates the paper's central access decision without introducing a
new market, revenue stack or structural forecasting model.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))

import phase_model as pm  # noqa: E402
import run_retained_reserve_analysis as rr  # noqa: E402
import run_methodological_extensions as rme  # noqa: E402

Q = 0.95
HURDLE = 0.70
TARGET = 30_000.0
WIND_SHARE = 0.50
DEFAULT_OUT = ROOT / "results" / "retained_reserve"
TOL = 1e-8


@dataclass(frozen=True)
class FrozenResidualConfig:
    hurdle_w: np.ndarray
    hurdle_s: np.ndarray
    daily_scale_w: float
    daily_scale_s: float
    monthly_scale_w: float
    monthly_scale_s: float


def _pair_scale(wind: np.ndarray, solar: np.ndarray) -> tuple[float, float]:
    target = 0.5 * (float(wind.mean()) + float(solar.mean()))
    return (
        rr.RENEWABLE_REFERENCE_MW * target / float(wind.mean()),
        rr.RENEWABLE_REFERENCE_MW * target / float(solar.mean()),
    )


def draw_residual_scenarios(
    panel: pd.DataFrame,
    n: int,
    seed: int,
    *,
    frozen: FrozenResidualConfig | None = None,
    chunk: int = 25_000,
) -> tuple[np.ndarray, dict[str, np.ndarray], FrozenResidualConfig]:
    blocks = pm.build_blocks(panel)
    if frozen is None:
        hurdle_w, hurdle_s = pm.historical_hurdle(panel, HURDLE)
    else:
        hurdle_w, hurdle_s = frozen.hurdle_w, frozen.hurdle_s

    rng = np.random.default_rng(seed)
    bess = np.zeros(n, dtype=float)
    daily_w = np.zeros(n, dtype=float)
    daily_s = np.zeros(n, dtype=float)
    monthly_w = np.zeros(n, dtype=float)
    monthly_s = np.zeros(n, dtype=float)

    for month in range(1, 13):
        z = blocks[month]
        n_blocks = math.ceil(z.target_days / z.b.shape[1])
        for lo in range(0, n, chunk):
            hi = min(n, lo + chunk)
            rows = hi - lo
            choices = rng.integers(0, len(z.b), size=(rows, n_blocks))
            bdays = z.b[choices].reshape(rows, -1)[:, : z.target_days]
            wdays = z.w[choices].reshape(rows, -1)[:, : z.target_days]
            sdays = z.s[choices].reshape(rows, -1)[:, : z.target_days]
            source_days = np.repeat(z.source_days[choices], z.b.shape[1], axis=1)[:, : z.target_days]

            bess[lo:hi] += bdays.sum(axis=1)
            wr = wdays - hurdle_w[month - 1] / source_days
            sr = sdays - hurdle_s[month - 1] / source_days
            daily_w[lo:hi] += np.maximum(wr, 0.0).sum(axis=1)
            daily_s[lo:hi] += np.maximum(sr, 0.0).sum(axis=1)
            monthly_w[lo:hi] += np.maximum(wdays.sum(axis=1) - hurdle_w[month - 1], 0.0)
            monthly_s[lo:hi] += np.maximum(sdays.sum(axis=1) - hurdle_s[month - 1], 0.0)

    if frozen is None:
        dsw, dss = _pair_scale(daily_w, daily_s)
        msw, mss = _pair_scale(monthly_w, monthly_s)
        frozen = FrozenResidualConfig(
            hurdle_w=np.asarray(hurdle_w, dtype=float),
            hurdle_s=np.asarray(hurdle_s, dtype=float),
            daily_scale_w=dsw,
            daily_scale_s=dss,
            monthly_scale_w=msw,
            monthly_scale_s=mss,
        )

    daily = frozen.daily_scale_w * daily_w * WIND_SHARE + frozen.daily_scale_s * daily_s * (1.0 - WIND_SHARE)
    monthly = frozen.monthly_scale_w * monthly_w * WIND_SHARE + frozen.monthly_scale_s * monthly_s * (1.0 - WIND_SHARE)
    return bess, {"daily_non_carrying": daily, "monthly_netted": monthly}, frozen


def reserve_metrics(bess: np.ndarray, residual: np.ndarray, alpha: float) -> dict[str, float | bool]:
    guarantee = TARGET * rr.P_BESS_MW
    cash = (
        alpha * residual
        + rr.PROVIDER_UPSIDE_SHARE * np.maximum(bess - guarantee, 0.0)
        - np.maximum(guarantee - bess, 0.0)
    )
    solvent = np.cumsum(cash, axis=1).min(axis=1) >= -TOL
    successes = int(solvent.sum())
    n = len(solvent)
    solvency = successes / n
    wilson = rme.wilson_lower(successes, n)
    mean_cash = float(cash.mean())
    required_margin = rr.REQUIRED_MARGIN_FRACTION * float(bess.mean())
    return {
        "solvency": solvency,
        "wilson_lower": wilson,
        "margin_pass": bool(mean_cash >= required_margin - 1e-7),
        "mean_provider_cash_gbp_per_bess_mw_year": mean_cash / rr.P_BESS_MW,
    }


def solve_alpha(bess: np.ndarray, residual: np.ndarray, *, wilson_rule: bool) -> tuple[float, dict]:
    def feasible(a: float) -> tuple[bool, dict]:
        m = reserve_metrics(bess, residual, a)
        solvency_ok = m["wilson_lower"] >= Q - 1e-12 if wilson_rule else m["solvency"] >= Q - 1e-12
        return bool(solvency_ok and m["margin_pass"]), m

    ok, metrics = feasible(1.0)
    if not ok:
        return float("nan"), metrics
    lo, hi = 0.0, 1.0
    for _ in range(25):
        mid = 0.5 * (lo + hi)
        if feasible(mid)[0]:
            hi = mid
        else:
            lo = mid
    return hi, feasible(hi)[1]




def wilson_interval(successes: int, n: int, z: float = 1.959963984540054) -> tuple[float, float]:
    """Two-sided Wilson score interval for a binomial proportion."""
    if n <= 0:
        return float("nan"), float("nan")
    phat = successes / n
    denom = 1.0 + z * z / n
    centre = (phat + z * z / (2.0 * n)) / denom
    half = z * math.sqrt(phat * (1.0 - phat) / n + z * z / (4.0 * n * n)) / denom
    return centre - half, centre + half

def summarize(run: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict] = []
    for (rule, settlement), g in run.groupby(["calibration_rule", "settlement_rule"], sort=True):
        def stat(col: str, p: float) -> float:
            return float(np.nanquantile(g[col].to_numpy(float), p))
        n_rep = int(len(g))
        empirical_successes = int(g["evaluation_empirical_target_attained"].sum())
        empirical_lo, empirical_hi = wilson_interval(empirical_successes, n_rep)
        wilson_successes = int(g["evaluation_wilson_target_attained"].sum())
        wilson_lo, wilson_hi = wilson_interval(wilson_successes, n_rep)
        rows.append({
            "calibration_rule": rule,
            "settlement_rule": settlement,
            "replications": n_rep,
            "training_target_reachability": float(g["training_target_reached"].mean()),
            "alpha_min_median": stat("alpha_min", 0.5),
            "alpha_min_p025": stat("alpha_min", 0.025),
            "alpha_min_p975": stat("alpha_min", 0.975),
            "evaluation_empirical_success_count": empirical_successes,
            "evaluation_empirical_target_attainment": empirical_successes / n_rep,
            "evaluation_empirical_attainment_wilson95_lower": empirical_lo,
            "evaluation_empirical_attainment_wilson95_upper": empirical_hi,
            "evaluation_wilson_success_count": wilson_successes,
            "evaluation_wilson_target_attainment": wilson_successes / n_rep,
            "evaluation_wilson_attainment_wilson95_lower": wilson_lo,
            "evaluation_wilson_attainment_wilson95_upper": wilson_hi,
            "evaluation_admitted_cash_median_gbp_per_bess_mw_year": stat("evaluation_admitted_cash_gbp_per_bess_mw_year", 0.5),
            "evaluation_admitted_cash_p025_gbp_per_bess_mw_year": stat("evaluation_admitted_cash_gbp_per_bess_mw_year", 0.025),
            "evaluation_admitted_cash_p975_gbp_per_bess_mw_year": stat("evaluation_admitted_cash_gbp_per_bess_mw_year", 0.975),
            "evaluation_solvency_median": stat("evaluation_solvency", 0.5),
            "evaluation_solvency_p025": stat("evaluation_solvency", 0.025),
            "evaluation_solvency_p975": stat("evaluation_solvency", 0.975),
        })
    return pd.DataFrame(rows)


def run(reps: int, n_train: int, n_eval: int, seed: int, out: Path) -> dict:
    out.mkdir(parents=True, exist_ok=True)
    duration_daily = rr.prepare_duration_daily(False)
    panel = rr.live_panel_for_duration(2, duration_daily)
    master = np.random.default_rng(seed)
    rows: list[dict] = []
    start = time.time()

    for rep in range(reps):
        bootstrap_seed = int(master.integers(0, 2**32 - 1))
        train_seed = int(master.integers(0, 2**32 - 1))
        eval_seed = int(master.integers(0, 2**32 - 1))
        boot = rme.bootstrap_panel(panel, np.random.default_rng(bootstrap_seed))
        b_train_annual, r_train_annual, cfg = draw_residual_scenarios(boot, n_train * rr.TENOR_YEARS, train_seed)
        b_eval_annual, r_eval_annual, _ = draw_residual_scenarios(boot, n_eval * rr.TENOR_YEARS, eval_seed, frozen=cfg)
        b_train = b_train_annual.reshape(n_train, rr.TENOR_YEARS)
        b_eval = b_eval_annual.reshape(n_eval, rr.TENOR_YEARS)

        for rule, use_wilson in (("empirical_q", False), ("wilson_lower_bound", True)):
            for settlement in ("daily_non_carrying", "monthly_netted"):
                r_train = r_train_annual[settlement].reshape(n_train, rr.TENOR_YEARS)
                r_eval = r_eval_annual[settlement].reshape(n_eval, rr.TENOR_YEARS)
                alpha, train_metrics = solve_alpha(b_train, r_train, wilson_rule=use_wilson)
                reached = bool(np.isfinite(alpha))
                if reached:
                    eval_metrics = reserve_metrics(b_eval, r_eval, alpha)
                    emp_attained = bool(eval_metrics["solvency"] >= Q - 1e-12 and eval_metrics["margin_pass"])
                    wil_attained = bool(eval_metrics["wilson_lower"] >= Q - 1e-12 and eval_metrics["margin_pass"])
                else:
                    eval_metrics = {
                        "solvency": np.nan,
                        "wilson_lower": np.nan,
                        "margin_pass": False,
                        "mean_provider_cash_gbp_per_bess_mw_year": np.nan,
                    }
                    emp_attained = False
                    wil_attained = False
                rows.append({
                    "replication": rep,
                    "calibration_rule": rule,
                    "settlement_rule": settlement,
                    "target_floor_gbp_per_bess_mw_year": TARGET,
                    "protected_hurdle": HURDLE,
                    "wind_equal_mean_cash_share": WIND_SHARE,
                    "renewable_cash_scale_mw_equivalent_per_100mw_bess": rr.RENEWABLE_REFERENCE_MW,
                    "alpha_min": alpha,
                    "training_target_reached": float(reached),
                    "training_solvency": train_metrics["solvency"],
                    "training_wilson_lower": train_metrics["wilson_lower"],
                    "training_admitted_cash_gbp_per_bess_mw_year": alpha * float(r_train.mean()) / rr.P_BESS_MW if reached else np.nan,
                    "evaluation_solvency": eval_metrics["solvency"],
                    "evaluation_wilson_lower": eval_metrics["wilson_lower"],
                    "evaluation_empirical_target_attained": float(emp_attained),
                    "evaluation_wilson_target_attained": float(wil_attained),
                    "evaluation_admitted_cash_gbp_per_bess_mw_year": alpha * float(r_eval.mean()) / rr.P_BESS_MW if reached else np.nan,
                    "evaluation_mean_provider_cash_gbp_per_bess_mw_year": eval_metrics["mean_provider_cash_gbp_per_bess_mw_year"],
                })
        if (rep + 1) % max(1, reps // 10) == 0:
            print(f"minimum-access validation {rep + 1}/{reps}", flush=True)

    run_level = pd.DataFrame(rows)
    summary = summarize(run_level)
    run_level.to_csv(out / "minimum_access_frozen_contract_run_level.csv", index=False)
    summary.to_csv(out / "Table_S36_minimum_access_historical_validation.csv", index=False)
    meta = {
        "status": "PASS",
        "release": "1.9.1",
        "replications": reps,
        "training_paths": n_train,
        "evaluation_paths": n_eval,
        "outer_seed": seed,
        "target_floor_gbp_per_bess_mw_year": TARGET,
        "q": Q,
        "protected_hurdle": HURDLE,
        "wind_equal_mean_cash_share": WIND_SHARE,
        "renewable_cash_scale_mw_equivalent_per_100mw_bess": rr.RENEWABLE_REFERENCE_MW,
        "outer_resampling": "source year-month groups resampled within calendar month; independent training and evaluation scenarios from each outer bootstrap panel",
        "runtime_seconds": time.time() - start,
        "outputs": [
            "minimum_access_frozen_contract_run_level.csv",
            "Table_S36_minimum_access_historical_validation.csv",
        ],
    }
    (out / "minimum_access_validation_metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return meta


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--replications", type=int, default=120)
    ap.add_argument("--training-paths", type=int, default=2_000)
    ap.add_argument("--evaluation-paths", type=int, default=5_000)
    ap.add_argument("--seed", type=int, default=20260818)
    ap.add_argument("--output-dir", type=Path, default=DEFAULT_OUT)
    args = ap.parse_args()
    meta = run(args.replications, args.training_paths, args.evaluation_paths, args.seed, args.output_dir)
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
